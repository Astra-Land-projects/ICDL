-- Car Rental & Fleet Management
-- Vehicles and classes, branches, customers, rental agreements with mileage and late fees, maintenance history.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Branches (
    BranchID COUNTER PRIMARY KEY,
    BranchName TEXT(50) NOT NULL,
    City TEXT(40),
    Phone TEXT(30)
);

CREATE TABLE VehicleClasses (
    ClassID COUNTER PRIMARY KEY,
    ClassName TEXT(30) NOT NULL UNIQUE,
    DailyRate CURRENCY,
    KmAllowancePerDay LONG,
    ExtraKmFee CURRENCY
);

CREATE TABLE Vehicles (
    VehicleID COUNTER PRIMARY KEY,
    PlateNo TEXT(12) NOT NULL UNIQUE,
    Make TEXT(30),
    Model TEXT(30),
    ModelYear INTEGER,
    ClassID LONG,
    BranchID LONG,
    Odometer LONG,
    FuelType TEXT(15),
    VehicleStatus TEXT(20)
);

CREATE TABLE Customers (
    CustomerID COUNTER PRIMARY KEY,
    FullName TEXT(60) NOT NULL,
    LicenseNo TEXT(20) NOT NULL,
    LicenseExpiry DATETIME,
    Phone TEXT(30),
    Email TEXT(100),
    BirthDate DATETIME,
    Blacklisted YESNO
);

CREATE TABLE Rentals (
    RentalID COUNTER PRIMARY KEY,
    AgreementNo TEXT(12) NOT NULL UNIQUE,
    CustomerID LONG NOT NULL,
    VehicleID LONG NOT NULL,
    PickupBranchID LONG,
    PickupDate DATETIME,
    DueDate DATETIME,
    ReturnDate DATETIME,
    StartKm LONG,
    EndKm LONG,
    InsuranceAddOn YESNO
);

CREATE TABLE Maintenance (
    MaintenanceID COUNTER PRIMARY KEY,
    VehicleID LONG NOT NULL,
    ServiceDate DATETIME,
    ServiceType TEXT(40),
    Cost CURRENCY,
    OdometerAtService LONG,
    Garage TEXT(50)
);

ALTER TABLE Vehicles ADD CONSTRAINT FK_Vehicles_ClassID FOREIGN KEY (ClassID) REFERENCES VehicleClasses (ClassID);
ALTER TABLE Vehicles ADD CONSTRAINT FK_Vehicles_BranchID FOREIGN KEY (BranchID) REFERENCES Branches (BranchID);
ALTER TABLE Rentals ADD CONSTRAINT FK_Rentals_CustomerID FOREIGN KEY (CustomerID) REFERENCES Customers (CustomerID);
ALTER TABLE Rentals ADD CONSTRAINT FK_Rentals_VehicleID FOREIGN KEY (VehicleID) REFERENCES Vehicles (VehicleID);
ALTER TABLE Rentals ADD CONSTRAINT FK_Rentals_PickupBranchID FOREIGN KEY (PickupBranchID) REFERENCES Branches (BranchID);
ALTER TABLE Maintenance ADD CONSTRAINT FK_Maintenance_VehicleID FOREIGN KEY (VehicleID) REFERENCES Vehicles (VehicleID) ON DELETE CASCADE;

-- ===== Saved queries =====

-- qryRentalInvoices  [Select]  Completed rentals: base, mileage, late fee, insurance
SELECT r.AgreementNo, c.FullName, v.PlateNo, v.Make & ' ' & v.Model AS Car, vc.ClassName, r.PickupDate, r.ReturnDate, DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate)) AS RentalDays, DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate))*vc.DailyRate AS BaseCharge, Nz(r.EndKm,0) - r.StartKm AS KmDriven, IIf((Nz(r.EndKm,0) - r.StartKm) > vc.KmAllowancePerDay*DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate)), Nz(r.EndKm,0) - r.StartKm - vc.KmAllowancePerDay*DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate)), 0)*vc.ExtraKmFee AS ExtraKmCharge, IIf(r.ReturnDate > r.DueDate, DateDiff('d', r.DueDate, r.ReturnDate), 0)*vc.DailyRate*1.5 AS LateFee, IIf(r.InsuranceAddOn, DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate))*15, 0) AS InsuranceCharge, DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate))*vc.DailyRate + IIf((Nz(r.EndKm,0) - r.StartKm) > vc.KmAllowancePerDay*DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate)), Nz(r.EndKm,0) - r.StartKm - vc.KmAllowancePerDay*DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate)), 0)*vc.ExtraKmFee + IIf(r.ReturnDate > r.DueDate, DateDiff('d', r.DueDate, r.ReturnDate), 0)*vc.DailyRate*1.5 + IIf(r.InsuranceAddOn, DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate))*15, 0) AS TotalCharge FROM ((Rentals AS r INNER JOIN Customers AS c ON r.CustomerID = c.CustomerID) INNER JOIN Vehicles AS v ON r.VehicleID = v.VehicleID) INNER JOIN VehicleClasses AS vc ON v.ClassID = vc.ClassID WHERE r.ReturnDate Is Not Null ORDER BY r.PickupDate DESC;

-- qryActiveRentals  [Select]  Cars currently out and their return status
SELECT r.AgreementNo, c.FullName, c.Phone, v.PlateNo, v.Make & ' ' & v.Model AS Car, r.PickupDate, r.DueDate, IIf(r.DueDate < Date(), 'OVERDUE ' & DateDiff('d', r.DueDate, Date()) & ' days', 'Due in ' & DateDiff('d', Date(), r.DueDate) & ' days') AS ReturnStatus FROM ((Rentals AS r INNER JOIN Customers AS c ON r.CustomerID = c.CustomerID) INNER JOIN Vehicles AS v ON r.VehicleID = v.VehicleID) INNER JOIN VehicleClasses AS vc ON v.ClassID = vc.ClassID WHERE r.ReturnDate Is Null ORDER BY r.DueDate;

-- qryFleetUtilization  [Select]  Days rented and utilization since March
SELECT v.PlateNo, v.Make & ' ' & v.Model AS Car, vc.ClassName, Count(r.RentalID) AS Rentals, Sum(DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, Date(), r.ReturnDate))) AS DaysRented, Round(Sum(DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, Date(), r.ReturnDate)))/DateDiff('d', #2026-03-01#, Date()),3) AS UtilizationPct FROM (Vehicles AS v INNER JOIN VehicleClasses AS vc ON v.ClassID = vc.ClassID) INNER JOIN Rentals AS r ON v.VehicleID = r.VehicleID WHERE r.PickupDate <= Date() GROUP BY v.PlateNo, v.Make, v.Model, vc.ClassName ORDER BY Sum(DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, Date(), r.ReturnDate))) DESC;

-- qryRevenueByClass  [Select]  Revenue by vehicle class
SELECT vc.ClassName, Count(r.RentalID) AS Rentals, Sum(DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate))) AS Days, Sum(DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate))*vc.DailyRate) AS BaseRevenue FROM ((Rentals AS r INNER JOIN Customers AS c ON r.CustomerID = c.CustomerID) INNER JOIN Vehicles AS v ON r.VehicleID = v.VehicleID) INNER JOIN VehicleClasses AS vc ON v.ClassID = vc.ClassID WHERE r.ReturnDate Is Not Null GROUP BY vc.ClassName ORDER BY Sum(DateDiff('d', r.PickupDate, IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate))*vc.DailyRate) DESC;

-- qryMaintenanceCost  [Select]  Maintenance spend and service-due alert
SELECT v.PlateNo, v.Make & ' ' & v.Model AS Car, Count(m.MaintenanceID) AS Services, Sum(m.Cost) AS TotalCost, Max(m.ServiceDate) AS LastService, v.Odometer - Max(m.OdometerAtService) AS KmSinceService, IIf((v.Odometer - Max(m.OdometerAtService)) > 8000, 'SERVICE DUE', 'OK') AS ServiceAlert FROM Vehicles AS v INNER JOIN Maintenance AS m ON v.VehicleID = m.VehicleID GROUP BY v.PlateNo, v.Make, v.Model, v.Odometer ORDER BY Sum(m.Cost) DESC;

-- qryLicenseExpiryCheck  [Select]  Driver license validity and age check
SELECT c.FullName, c.LicenseNo, c.LicenseExpiry, DateDiff('d', Date(), c.LicenseExpiry) AS DaysLeft, DateDiff('yyyy', c.BirthDate, Date()) AS Age, IIf(c.LicenseExpiry < Date(), 'EXPIRED', IIf(DateDiff('yyyy', c.BirthDate, Date()) < 25, 'Young driver surcharge', 'OK')) AS Eligibility, c.Blacklisted FROM Customers AS c ORDER BY c.LicenseExpiry;

-- qryBranchPerformance  [Select]  Rentals per branch
SELECT b.BranchName, Count(r.RentalID) AS Pickups, Sum(IIf(r.ReturnDate Is Null,1,0)) AS CurrentlyOut FROM Branches AS b INNER JOIN Rentals AS r ON b.BranchID = r.PickupBranchID GROUP BY b.BranchName ORDER BY Count(r.RentalID) DESC;

-- qryXT_RentalsClassMonth  [Crosstab]  Crosstab: rentals by class per month
TRANSFORM Count(r.RentalID) AS Rentals SELECT vc.ClassName FROM (Rentals AS r INNER JOIN Vehicles AS v ON r.VehicleID = v.VehicleID) INNER JOIN VehicleClasses AS vc ON v.ClassID = vc.ClassID GROUP BY vc.ClassName PIVOT Format(r.PickupDate,'yyyy-mm');

-- qryAvailableCars  [Parameter]  Parameter: cars free for a date range
PARAMETERS [Pickup date] DateTime, [Return date] DateTime; SELECT v.PlateNo, v.Make, v.Model, vc.ClassName, vc.DailyRate FROM Vehicles AS v INNER JOIN VehicleClasses AS vc ON v.ClassID = vc.ClassID WHERE v.VehicleStatus = 'Available' AND v.VehicleID NOT IN (SELECT r.VehicleID FROM Rentals AS r WHERE r.PickupDate < [Return date] AND IIf(r.ReturnDate Is Null, r.DueDate, r.ReturnDate) > [Pickup date]) ORDER BY vc.DailyRate;

-- qryAction_SyncOdometer  [Action]  Action: update odometer from returned rentals
UPDATE Vehicles AS v INNER JOIN Rentals AS r ON v.VehicleID = r.VehicleID SET v.Odometer = r.EndKm WHERE r.EndKm > v.Odometer;
