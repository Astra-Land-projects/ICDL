# Car Rental & Fleet Management

**سیستم اجاره خودرو و مدیریت ناوگان** — خودروها و کلاس‌ها، شعب، مشتریان و گواهینامه، قراردادهای اجاره با کیلومتر و جریمه تأخیر، سرویس و نگهداری.

> Vehicles and classes, branches, customers, rental agreements with mileage and late fees, maintenance history.

## نحوه راه‌اندازی

1. فایل `14_Car_Rental_Fleet.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Branches | 3 | Rental locations |
| VehicleClasses | 6 | Pricing classes |
| Vehicles | 30 | Fleet |
| Customers | 40 | Renters |
| Rentals | 135 | Rental agreements |
| Maintenance | 62 | Service history |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    VehicleClasses ||--o{ Vehicles : "ClassID"
    Branches ||--o{ Vehicles : "BranchID"
    Customers ||--o{ Rentals : "CustomerID"
    Vehicles ||--o{ Rentals : "VehicleID"
    Branches ||--o{ Rentals : "PickupBranchID"
    Vehicles ||--o{ Maintenance : "VehicleID"
    Branches {
        pk BranchID PK
        text BranchName
        text City
        text Phone
    }
    VehicleClasses {
        pk ClassID PK
        text ClassName
        cur DailyRate
        long KmAllowancePerDay
        cur ExtraKmFee
    }
    Vehicles {
        pk VehicleID PK
        text PlateNo
        text Make
        text Model
        int ModelYear
        long ClassID FK
        long BranchID FK
        long Odometer
        text FuelType
        text VehicleStatus
    }
    Customers {
        pk CustomerID PK
        text FullName
        text LicenseNo
        date LicenseExpiry
        text Phone
        text Email
        date BirthDate
        bool Blacklisted
    }
    Rentals {
        pk RentalID PK
        text AgreementNo
        long CustomerID FK
        long VehicleID FK
        long PickupBranchID FK
        date PickupDate
        date DueDate
        date ReturnDate
        long StartKm
        long EndKm
        bool InsuranceAddOn
    }
    Maintenance {
        pk MaintenanceID PK
        long VehicleID FK
        date ServiceDate
        text ServiceType
        cur Cost
        long OdometerAtService
        text Garage
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryRentalInvoices | Select | Completed rentals: base, mileage, late fee, insurance |
| qryActiveRentals | Select | Cars currently out and their return status |
| qryFleetUtilization | Select | Days rented and utilization since March |
| qryRevenueByClass | Select | Revenue by vehicle class |
| qryMaintenanceCost | Select | Maintenance spend and service-due alert |
| qryLicenseExpiryCheck | Select | Driver license validity and age check |
| qryBranchPerformance | Select | Rentals per branch |
| qryXT_RentalsClassMonth | Crosstab | Crosstab: rentals by class per month |
| qryAvailableCars | Parameter | Parameter: cars free for a date range |
| qryAction_SyncOdometer | Action | Action: update odometer from returned rentals |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmVehicles | Vehicles | Single |
| frmVehicleClasses | VehicleClasses | Continuous |
| frmBranches | Branches | Continuous |
| sfrmRentals | Rentals | Continuous |
| frmCustomers | Customers | Single + subform `sfrmRentals` |
| frmRentals | Rentals | Continuous |
| frmMaintenance | Maintenance | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptRentalInvoices | qryRentalInvoices | ClassName | RentalDays,BaseCharge,ExtraKmCharge,LateFee,TotalCharge |
| rptActiveRentals | qryActiveRentals | - | - |
| rptFleetUtilization | qryFleetUtilization | ClassName | Rentals,DaysRented |
| rptMaintenanceCost | qryMaintenanceCost | ServiceAlert | Services,TotalCost |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
