-- Real Estate Agency Management
-- Property listings for sale/rent, owners, agents, clients, viewings, contracts and commission calculation.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Agents (
    AgentID COUNTER PRIMARY KEY,
    AgentName TEXT(60) NOT NULL,
    Phone TEXT(30),
    Email TEXT(100),
    CommissionRate DOUBLE
);

CREATE TABLE Owners (
    OwnerID COUNTER PRIMARY KEY,
    OwnerName TEXT(60) NOT NULL,
    Phone TEXT(30),
    Email TEXT(100)
);

CREATE TABLE Clients (
    ClientID COUNTER PRIMARY KEY,
    ClientName TEXT(60) NOT NULL,
    Phone TEXT(30),
    Budget CURRENCY,
    LookingFor TEXT(10),
    PreferredArea TEXT(50)
);

CREATE TABLE Properties (
    PropertyID COUNTER PRIMARY KEY,
    ListingCode TEXT(12) NOT NULL UNIQUE,
    Address TEXT(150),
    Area TEXT(50),
    PropertyType TEXT(20),
    Bedrooms INTEGER,
    SizeSqm DOUBLE,
    ListingType TEXT(10),
    AskingPrice CURRENCY,
    OwnerID LONG,
    AgentID LONG,
    ListedDate DATETIME,
    ListingStatus TEXT(20)
);

CREATE TABLE Viewings (
    ViewingID COUNTER PRIMARY KEY,
    PropertyID LONG NOT NULL,
    ClientID LONG NOT NULL,
    ViewingDate DATETIME,
    AgentID LONG,
    Interest INTEGER,
    Feedback TEXT(255)
);

CREATE TABLE Contracts (
    ContractID COUNTER PRIMARY KEY,
    ContractNo TEXT(15) NOT NULL UNIQUE,
    PropertyID LONG NOT NULL,
    ClientID LONG NOT NULL,
    AgentID LONG NOT NULL,
    ContractType TEXT(10),
    SignDate DATETIME,
    FinalPrice CURRENCY,
    LeaseMonths INTEGER
);

ALTER TABLE Properties ADD CONSTRAINT FK_Properties_OwnerID FOREIGN KEY (OwnerID) REFERENCES Owners (OwnerID);
ALTER TABLE Properties ADD CONSTRAINT FK_Properties_AgentID FOREIGN KEY (AgentID) REFERENCES Agents (AgentID);
ALTER TABLE Viewings ADD CONSTRAINT FK_Viewings_PropertyID FOREIGN KEY (PropertyID) REFERENCES Properties (PropertyID) ON DELETE CASCADE;
ALTER TABLE Viewings ADD CONSTRAINT FK_Viewings_ClientID FOREIGN KEY (ClientID) REFERENCES Clients (ClientID);
ALTER TABLE Viewings ADD CONSTRAINT FK_Viewings_AgentID FOREIGN KEY (AgentID) REFERENCES Agents (AgentID);
ALTER TABLE Contracts ADD CONSTRAINT FK_Contracts_PropertyID FOREIGN KEY (PropertyID) REFERENCES Properties (PropertyID);
ALTER TABLE Contracts ADD CONSTRAINT FK_Contracts_ClientID FOREIGN KEY (ClientID) REFERENCES Clients (ClientID);
ALTER TABLE Contracts ADD CONSTRAINT FK_Contracts_AgentID FOREIGN KEY (AgentID) REFERENCES Agents (AgentID);

-- ===== Saved queries =====

-- qryAvailableListings  [Select]  Active listings with price per sqm and days on market
SELECT pr.ListingCode, pr.Address, pr.Area, pr.PropertyType, pr.Bedrooms, pr.SizeSqm, pr.ListingType, pr.AskingPrice, IIf(pr.ListingType='Sale', pr.AskingPrice/pr.SizeSqm, Null) AS PricePerSqm, a.AgentName, DateDiff('d', pr.ListedDate, Date()) AS DaysOnMarket FROM Properties AS pr INNER JOIN Agents AS a ON pr.AgentID = a.AgentID WHERE pr.ListingStatus = 'Available' ORDER BY pr.ListingType, pr.AskingPrice;

-- qryContractsCommission  [Select]  Closed deals and agent commission (rent = 1 month)
SELECT c.ContractNo, c.SignDate, c.ContractType, pr.ListingCode, pr.Address, cl.ClientName, a.AgentName, c.FinalPrice, a.CommissionRate, IIf(c.ContractType='Sale', c.FinalPrice*a.CommissionRate, c.FinalPrice) AS Commission FROM ((Contracts AS c INNER JOIN Properties AS pr ON c.PropertyID = pr.PropertyID) INNER JOIN Clients AS cl ON c.ClientID = cl.ClientID) INNER JOIN Agents AS a ON c.AgentID = a.AgentID ORDER BY c.SignDate;

-- qryAgentLeaderboard  [Select]  Agent ranking by commission
SELECT a.AgentName, Count(c.ContractID) AS Deals, Sum(c.FinalPrice) AS DealVolume, Sum(IIf(c.ContractType='Sale', c.FinalPrice*a.CommissionRate, c.FinalPrice)) AS TotalCommission FROM Agents AS a INNER JOIN Contracts AS c ON a.AgentID = c.AgentID GROUP BY a.AgentName ORDER BY Sum(IIf(c.ContractType='Sale', c.FinalPrice*a.CommissionRate, c.FinalPrice)) DESC;

-- qryViewingFunnel  [Select]  Viewings and interest per listing
SELECT pr.ListingCode, pr.Address, pr.ListingStatus, Count(v.ViewingID) AS Viewings, Round(Avg(v.Interest),1) AS AvgInterest, Sum(IIf(v.Interest>=4,1,0)) AS HotLeads FROM Properties AS pr INNER JOIN Viewings AS v ON pr.PropertyID = v.PropertyID GROUP BY pr.ListingCode, pr.Address, pr.ListingStatus ORDER BY Count(v.ViewingID) DESC;

-- qryClientMatches  [Select]  Matchmaking: listings within client budget and area
SELECT cl.ClientName, cl.LookingFor, cl.Budget, cl.PreferredArea, pr.ListingCode, pr.Address, pr.AskingPrice FROM Clients AS cl INNER JOIN Properties AS pr ON cl.PreferredArea = pr.Area WHERE pr.ListingStatus = 'Available' AND ((cl.LookingFor='Buy' AND pr.ListingType='Sale') OR (cl.LookingFor='Rent' AND pr.ListingType='Rent')) AND pr.AskingPrice <= cl.Budget ORDER BY cl.ClientName, pr.AskingPrice;

-- qryMarketByArea  [Select]  Market statistics by neighbourhood
SELECT pr.Area, pr.ListingType, Count(pr.PropertyID) AS Listings, Avg(pr.AskingPrice) AS AvgPrice, Avg(pr.AskingPrice/pr.SizeSqm) AS AvgPerSqm FROM Properties AS pr GROUP BY pr.Area, pr.ListingType ORDER BY pr.Area, pr.ListingType;

-- qryStaleListings  [Select]  Listings unsold for 120+ days
SELECT pr.ListingCode, pr.Address, pr.AskingPrice, a.AgentName, DateDiff('d', pr.ListedDate, Date()) AS DaysOnMarket FROM Properties AS pr INNER JOIN Agents AS a ON pr.AgentID = a.AgentID WHERE pr.ListingStatus = 'Available' AND DateDiff('d', pr.ListedDate, Date()) > 120 ORDER BY pr.ListedDate;

-- qryXT_ListingsAreaType  [Crosstab]  Crosstab: listings by area and property type
TRANSFORM Count(pr.PropertyID) AS Listings SELECT pr.Area FROM Properties AS pr GROUP BY pr.Area PIVOT pr.PropertyType;

-- qrySearchProperties  [Parameter]  Parameter: search by price and bedrooms
PARAMETERS [Max price] Currency, [Min bedrooms] Short; SELECT pr.ListingCode, pr.Address, pr.Area, pr.Bedrooms, pr.AskingPrice FROM Properties AS pr WHERE pr.ListingStatus = 'Available' AND pr.AskingPrice <= [Max price] AND pr.Bedrooms >= [Min bedrooms] ORDER BY pr.AskingPrice;

-- qryAction_ReducePriceStale  [Action]  Action: 5% price cut for 6-month-old listings
UPDATE Properties SET AskingPrice = Round(AskingPrice*0.95,0) WHERE ListingStatus = 'Available' AND DateDiff('d', ListedDate, Date()) > 180;
