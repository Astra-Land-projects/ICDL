# Real Estate Agency Management

**سیستم مدیریت مشاور املاک** — املاک (فروش/اجاره)، مالکان، مشاوران، مشتریان، بازدیدها، قراردادها و محاسبه کمیسیون.

> Property listings for sale/rent, owners, agents, clients, viewings, contracts and commission calculation.

## نحوه راه‌اندازی

1. فایل `13_Real_Estate_Agency.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Agents | 5 | Agency agents |
| Owners | 20 | Property owners |
| Clients | 30 | Buyers and tenants |
| Properties | 45 | Listings |
| Viewings | 110 | Property visits |
| Contracts | 14 | Sale / lease agreements |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Owners ||--o{ Properties : "OwnerID"
    Agents ||--o{ Properties : "AgentID"
    Properties ||--o{ Viewings : "PropertyID"
    Clients ||--o{ Viewings : "ClientID"
    Agents ||--o{ Viewings : "AgentID"
    Properties ||--o{ Contracts : "PropertyID"
    Clients ||--o{ Contracts : "ClientID"
    Agents ||--o{ Contracts : "AgentID"
    Agents {
        pk AgentID PK
        text AgentName
        text Phone
        text Email
        dbl CommissionRate
    }
    Owners {
        pk OwnerID PK
        text OwnerName
        text Phone
        text Email
    }
    Clients {
        pk ClientID PK
        text ClientName
        text Phone
        cur Budget
        text LookingFor
        text PreferredArea
    }
    Properties {
        pk PropertyID PK
        text ListingCode
        text Address
        text Area
        text PropertyType
        int Bedrooms
        dbl SizeSqm
        text ListingType
        cur AskingPrice
        long OwnerID FK
        long AgentID FK
        date ListedDate
        text ListingStatus
    }
    Viewings {
        pk ViewingID PK
        long PropertyID FK
        long ClientID FK
        date ViewingDate
        long AgentID FK
        int Interest
        text Feedback
    }
    Contracts {
        pk ContractID PK
        text ContractNo
        long PropertyID FK
        long ClientID FK
        long AgentID FK
        text ContractType
        date SignDate
        cur FinalPrice
        int LeaseMonths
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryAvailableListings | Select | Active listings with price per sqm and days on market |
| qryContractsCommission | Select | Closed deals and agent commission (rent = 1 month) |
| qryAgentLeaderboard | Select | Agent ranking by commission |
| qryViewingFunnel | Select | Viewings and interest per listing |
| qryClientMatches | Select | Matchmaking: listings within client budget and area |
| qryMarketByArea | Select | Market statistics by neighbourhood |
| qryStaleListings | Select | Listings unsold for 120+ days |
| qryXT_ListingsAreaType | Crosstab | Crosstab: listings by area and property type |
| qrySearchProperties | Parameter | Parameter: search by price and bedrooms |
| qryAction_ReducePriceStale | Action | Action: 5% price cut for 6-month-old listings |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| sfrmViewings | Viewings | Continuous |
| frmProperties | Properties | Single + subform `sfrmViewings` |
| frmOwners | Owners | Continuous |
| frmAgents | Agents | Continuous |
| frmClients | Clients | Continuous |
| frmContracts | Contracts | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptAvailableListings | qryAvailableListings | ListingType | - |
| rptCommission | qryContractsCommission | AgentName | FinalPrice,Commission |
| rptAgentLeaderboard | qryAgentLeaderboard | - | Deals,DealVolume,TotalCommission |
| rptClientMatches | qryClientMatches | ClientName | - |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
