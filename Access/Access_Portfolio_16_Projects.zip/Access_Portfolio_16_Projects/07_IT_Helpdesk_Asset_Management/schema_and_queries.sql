-- IT Helpdesk & Asset Management
-- Support tickets with SLA tracking, hardware assets, software licenses and renewal alerts.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Departments (
    DeptID COUNTER PRIMARY KEY,
    DeptName TEXT(50) NOT NULL UNIQUE,
    FloorNo INTEGER
);

CREATE TABLE Users (
    UserID COUNTER PRIMARY KEY,
    FullName TEXT(60) NOT NULL,
    Email TEXT(100),
    DeptID LONG,
    IsTechnician YESNO
);

CREATE TABLE Assets (
    AssetID COUNTER PRIMARY KEY,
    AssetTag TEXT(20) NOT NULL UNIQUE,
    AssetType TEXT(30),
    Model TEXT(60),
    SerialNo TEXT(40),
    AssignedTo LONG,
    PurchaseDate DATETIME,
    PurchaseCost CURRENCY,
    WarrantyEnd DATETIME,
    AssetStatus TEXT(20)
);

CREATE TABLE Licenses (
    LicenseID COUNTER PRIMARY KEY,
    SoftwareName TEXT(80) NOT NULL,
    Vendor TEXT(50),
    Seats LONG,
    SeatsUsed LONG,
    AnnualCost CURRENCY,
    RenewalDate DATETIME,
    AutoRenew YESNO
);

CREATE TABLE SLAPolicies (
    SLAID COUNTER PRIMARY KEY,
    Priority TEXT(10) NOT NULL UNIQUE,
    HoursToResolve LONG
);

CREATE TABLE Tickets (
    TicketID COUNTER PRIMARY KEY,
    TicketNo TEXT(15) NOT NULL UNIQUE,
    RequesterID LONG NOT NULL,
    AssetID LONG,
    SLAID LONG,
    TicketCategory TEXT(30),
    Subject TEXT(150),
    OpenedAt DATETIME,
    ResolvedAt DATETIME,
    TechnicianID LONG,
    TicketStatus TEXT(20),
    Satisfaction INTEGER
);

ALTER TABLE Users ADD CONSTRAINT FK_Users_DeptID FOREIGN KEY (DeptID) REFERENCES Departments (DeptID);
ALTER TABLE Assets ADD CONSTRAINT FK_Assets_AssignedTo FOREIGN KEY (AssignedTo) REFERENCES Users (UserID);
ALTER TABLE Tickets ADD CONSTRAINT FK_Tickets_RequesterID FOREIGN KEY (RequesterID) REFERENCES Users (UserID);
ALTER TABLE Tickets ADD CONSTRAINT FK_Tickets_AssetID FOREIGN KEY (AssetID) REFERENCES Assets (AssetID);
ALTER TABLE Tickets ADD CONSTRAINT FK_Tickets_SLAID FOREIGN KEY (SLAID) REFERENCES SLAPolicies (SLAID);
ALTER TABLE Tickets ADD CONSTRAINT FK_Tickets_TechnicianID FOREIGN KEY (TechnicianID) REFERENCES Users (UserID);

-- ===== Saved queries =====

-- qryTicketQueue  [Select]  Open tickets with age and SLA state
SELECT t.TicketNo, t.Subject, t.TicketCategory, s.Priority, u.FullName AS Requester, tech.FullName AS Technician, t.OpenedAt, t.TicketStatus, Round(DateDiff('n', t.OpenedAt, Now())/60,1) AS AgeHours, IIf((DateDiff('n', t.OpenedAt, Now())/60) > s.HoursToResolve, 'SLA BREACHED', 'Within SLA') AS SLAState FROM ((Tickets AS t INNER JOIN SLAPolicies AS s ON t.SLAID = s.SLAID) INNER JOIN Users AS u ON t.RequesterID = u.UserID) INNER JOIN Users AS tech ON t.TechnicianID = tech.UserID WHERE t.ResolvedAt Is Null ORDER BY s.HoursToResolve, t.OpenedAt;

-- qrySLACompliance  [Select]  SLA compliance by priority
SELECT s.Priority, s.HoursToResolve, Count(t.TicketID) AS Resolved, Sum(IIf((DateDiff('n', t.OpenedAt, t.ResolvedAt)/60) <= s.HoursToResolve, 1, 0)) AS MetSLA, Sum(IIf((DateDiff('n', t.OpenedAt, t.ResolvedAt)/60) <= s.HoursToResolve, 1, 0))/Count(t.TicketID) AS CompliancePct, Round(Avg(DateDiff('n', t.OpenedAt, t.ResolvedAt)/60),1) AS AvgHours FROM SLAPolicies AS s INNER JOIN Tickets AS t ON s.SLAID = t.SLAID WHERE t.ResolvedAt Is Not Null GROUP BY s.Priority, s.HoursToResolve ORDER BY s.HoursToResolve;

-- qryTechnicianPerformance  [Select]  Workload and CSAT per technician
SELECT tech.FullName AS Technician, Count(t.TicketID) AS Tickets, Sum(IIf(t.ResolvedAt Is Null,0,1)) AS ResolvedCount, Round(Avg(t.Satisfaction),2) AS AvgSatisfaction FROM Users AS tech INNER JOIN Tickets AS t ON tech.UserID = t.TechnicianID GROUP BY tech.FullName ORDER BY Count(t.TicketID) DESC;

-- qryTicketsByCategory  [Select]  Ticket volume by category
SELECT t.TicketCategory, Count(t.TicketID) AS Tickets, Sum(IIf(t.ResolvedAt Is Null,1,0)) AS StillOpen FROM Tickets AS t GROUP BY t.TicketCategory ORDER BY Count(t.TicketID) DESC;

-- qryAssetRegister  [Select]  Asset register with warranty status
SELECT a.AssetTag, a.AssetType, a.Model, a.SerialNo, Nz(u.FullName,'(unassigned)') AS AssignedUser, a.PurchaseDate, a.PurchaseCost, a.WarrantyEnd, IIf(a.WarrantyEnd < Date(), 'Expired', IIf(a.WarrantyEnd < Date()+90, 'Expiring soon', 'Active')) AS WarrantyState, a.AssetStatus FROM Assets AS a LEFT JOIN Users AS u ON a.AssignedTo = u.UserID ORDER BY a.AssetType, a.AssetTag;

-- qryLicenseRenewals  [Select]  License renewals and seat usage
SELECT l.SoftwareName, l.Vendor, l.Seats, l.SeatsUsed, l.Seats - l.SeatsUsed AS FreeSeats, l.AnnualCost, l.RenewalDate, DateDiff('d', Date(), l.RenewalDate) AS DaysToRenewal, IIf(DateDiff('d', Date(), l.RenewalDate) < 0, 'EXPIRED', IIf(DateDiff('d', Date(), l.RenewalDate) <= 30, 'RENEW NOW', 'OK')) AS RenewalAlert, l.AutoRenew FROM Licenses AS l ORDER BY l.RenewalDate;

-- qryAssetValueByType  [Select]  Cost and straight-line (3-yr) book value
SELECT a.AssetType, Count(a.AssetID) AS Units, Sum(a.PurchaseCost) AS TotalCost, Sum(a.PurchaseCost * IIf(DateDiff('m', a.PurchaseDate, Date()) >= 36, 0, 1 - DateDiff('m', a.PurchaseDate, Date())/36)) AS BookValue FROM Assets AS a WHERE a.AssetStatus <> 'Retired' GROUP BY a.AssetType ORDER BY Sum(a.PurchaseCost) DESC;

-- qryXT_TicketsByMonthCategory  [Crosstab]  Crosstab: monthly tickets by category
TRANSFORM Count(t.TicketID) AS Tickets SELECT Format(t.OpenedAt,'yyyy-mm') AS OpenedMonth FROM Tickets AS t GROUP BY Format(t.OpenedAt,'yyyy-mm') PIVOT t.TicketCategory;

-- qryAction_RetireOldAssets  [Action]  Action: retire 5-year-old spare assets
UPDATE Assets SET AssetStatus = 'Retired' WHERE DateDiff('yyyy', PurchaseDate, Date()) >= 5 AND AssetStatus = 'In Stock';
