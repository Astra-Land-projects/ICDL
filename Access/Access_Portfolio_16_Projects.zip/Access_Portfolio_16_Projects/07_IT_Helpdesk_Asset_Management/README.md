# IT Helpdesk & Asset Management

**سیستم هلپ‌دسک و مدیریت دارایی‌های IT** — ثبت تیکت‌های پشتیبانی با SLA، دارایی‌های سخت‌افزاری، لایسنس‌های نرم‌افزاری و هشدار تمدید.

> Support tickets with SLA tracking, hardware assets, software licenses and renewal alerts.

## نحوه راه‌اندازی

1. فایل `07_IT_Helpdesk_Asset_Management.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Departments | 6 | Departments |
| Users | 26 | Staff and technicians |
| Assets | 40 | Hardware inventory |
| Licenses | 9 | Software subscriptions |
| SLAPolicies | 4 | Resolution targets per priority |
| Tickets | 70 | Support requests |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Departments ||--o{ Users : "DeptID"
    Users ||--o{ Assets : "AssignedTo"
    Users ||--o{ Tickets : "RequesterID"
    Assets ||--o{ Tickets : "AssetID"
    SLAPolicies ||--o{ Tickets : "SLAID"
    Users ||--o{ Tickets : "TechnicianID"
    Departments {
        pk DeptID PK
        text DeptName
        int FloorNo
    }
    Users {
        pk UserID PK
        text FullName
        text Email
        long DeptID FK
        bool IsTechnician
    }
    Assets {
        pk AssetID PK
        text AssetTag
        text AssetType
        text Model
        text SerialNo
        long AssignedTo FK
        date PurchaseDate
        cur PurchaseCost
        date WarrantyEnd
        text AssetStatus
    }
    Licenses {
        pk LicenseID PK
        text SoftwareName
        text Vendor
        long Seats
        long SeatsUsed
        cur AnnualCost
        date RenewalDate
        bool AutoRenew
    }
    SLAPolicies {
        pk SLAID PK
        text Priority
        long HoursToResolve
    }
    Tickets {
        pk TicketID PK
        text TicketNo
        long RequesterID FK
        long AssetID FK
        long SLAID FK
        text TicketCategory
        text Subject
        date OpenedAt
        date ResolvedAt
        long TechnicianID FK
        text TicketStatus
        int Satisfaction
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryTicketQueue | Select | Open tickets with age and SLA state |
| qrySLACompliance | Select | SLA compliance by priority |
| qryTechnicianPerformance | Select | Workload and CSAT per technician |
| qryTicketsByCategory | Select | Ticket volume by category |
| qryAssetRegister | Select | Asset register with warranty status |
| qryLicenseRenewals | Select | License renewals and seat usage |
| qryAssetValueByType | Select | Cost and straight-line (3-yr) book value |
| qryXT_TicketsByMonthCategory | Crosstab | Crosstab: monthly tickets by category |
| qryAction_RetireOldAssets | Action | Action: retire 5-year-old spare assets |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmTickets | Tickets | Single |
| frmAssets | Assets | Single |
| frmLicenses | Licenses | Continuous |
| frmUsers | Users | Continuous |
| frmDepartments | Departments | Continuous |
| frmSLAPolicies | SLAPolicies | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptTicketQueue | qryTicketQueue | Priority | - |
| rptSLACompliance | qrySLACompliance | - | Resolved,MetSLA |
| rptAssetRegister | qryAssetRegister | AssetType | PurchaseCost |
| rptLicenseRenewals | qryLicenseRenewals | RenewalAlert | AnnualCost |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
