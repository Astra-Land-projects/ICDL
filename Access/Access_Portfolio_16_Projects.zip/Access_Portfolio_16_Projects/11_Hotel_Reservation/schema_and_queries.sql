-- Hotel Reservation & Booking System
-- Rooms and room types, guests, reservations with overlap check, extra services, folios, occupancy and revenue.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE RoomTypes (
    RoomTypeID COUNTER PRIMARY KEY,
    TypeName TEXT(30) NOT NULL UNIQUE,
    NightlyRate CURRENCY,
    MaxGuests INTEGER
);

CREATE TABLE Rooms (
    RoomID COUNTER PRIMARY KEY,
    RoomNo TEXT(10) NOT NULL UNIQUE,
    RoomTypeID LONG NOT NULL,
    FloorNo INTEGER,
    SeaView YESNO,
    RoomStatus TEXT(20)
);

CREATE TABLE Guests (
    GuestID COUNTER PRIMARY KEY,
    FullName TEXT(60) NOT NULL,
    Email TEXT(100),
    Phone TEXT(30),
    Nationality TEXT(40),
    PassportNo TEXT(20),
    IsVIP YESNO
);

CREATE TABLE Reservations (
    ReservationID COUNTER PRIMARY KEY,
    BookingRef TEXT(12) NOT NULL UNIQUE,
    GuestID LONG NOT NULL,
    RoomID LONG NOT NULL,
    CheckIn DATETIME,
    CheckOut DATETIME,
    Adults INTEGER,
    Channel TEXT(20),
    BookingStatus TEXT(20),
    DiscountPct DOUBLE
);

CREATE TABLE Services (
    ServiceID COUNTER PRIMARY KEY,
    ServiceName TEXT(50) NOT NULL,
    Price CURRENCY
);

CREATE TABLE ServiceCharges (
    ChargeID COUNTER PRIMARY KEY,
    ReservationID LONG NOT NULL,
    ServiceID LONG NOT NULL,
    ChargeDate DATETIME,
    Quantity INTEGER
);

ALTER TABLE Rooms ADD CONSTRAINT FK_Rooms_RoomTypeID FOREIGN KEY (RoomTypeID) REFERENCES RoomTypes (RoomTypeID);
ALTER TABLE Reservations ADD CONSTRAINT FK_Reservations_GuestID FOREIGN KEY (GuestID) REFERENCES Guests (GuestID);
ALTER TABLE Reservations ADD CONSTRAINT FK_Reservations_RoomID FOREIGN KEY (RoomID) REFERENCES Rooms (RoomID);
ALTER TABLE ServiceCharges ADD CONSTRAINT FK_ServiceCharges_ReservationID FOREIGN KEY (ReservationID) REFERENCES Reservations (ReservationID) ON DELETE CASCADE;
ALTER TABLE ServiceCharges ADD CONSTRAINT FK_ServiceCharges_ServiceID FOREIGN KEY (ServiceID) REFERENCES Services (ServiceID);

-- ===== Saved queries =====

-- qryArrivalsDepartures  [Select]  Arrivals and departures in the next 7 days
SELECT r.BookingRef, g.FullName, g.IsVIP, rm.RoomNo, t.TypeName, r.CheckIn, r.CheckOut, r.Adults, r.BookingStatus FROM ((Reservations AS r INNER JOIN Guests AS g ON r.GuestID = g.GuestID) INNER JOIN Rooms AS rm ON r.RoomID = rm.RoomID) INNER JOIN RoomTypes AS t ON rm.RoomTypeID = t.RoomTypeID WHERE r.CheckIn Between Date() And Date()+7 OR r.CheckOut Between Date() And Date()+7 ORDER BY r.CheckIn;

-- qryGuestFolio  [Select]  Room + extras folio per booking
SELECT r.BookingRef, g.FullName, rm.RoomNo, t.TypeName, r.CheckIn, r.CheckOut, DateDiff('d', r.CheckIn, r.CheckOut) AS Nights, t.NightlyRate, Round(DateDiff('d', r.CheckIn, r.CheckOut)*t.NightlyRate*(1-r.DiscountPct),2) AS RoomCharges, Nz((SELECT Sum(sc.Quantity*s.Price) FROM ServiceCharges AS sc INNER JOIN Services AS s ON sc.ServiceID = s.ServiceID WHERE sc.ReservationID = r.ReservationID),0) AS ExtrasCharges, Round(DateDiff('d', r.CheckIn, r.CheckOut)*t.NightlyRate*(1-r.DiscountPct),2) + Nz((SELECT Sum(sc.Quantity*s.Price) FROM ServiceCharges AS sc INNER JOIN Services AS s ON sc.ServiceID = s.ServiceID WHERE sc.ReservationID = r.ReservationID),0) AS TotalFolio FROM ((Reservations AS r INNER JOIN Guests AS g ON r.GuestID = g.GuestID) INNER JOIN Rooms AS rm ON r.RoomID = rm.RoomID) INNER JOIN RoomTypes AS t ON rm.RoomTypeID = t.RoomTypeID WHERE r.BookingStatus <> 'Cancelled' ORDER BY r.CheckIn;

-- qryMonthlyRevenue  [Select]  Room nights, revenue and ADR (average daily rate)
SELECT Format(r.CheckIn,'yyyy-mm') AS StayMonth, Count(r.ReservationID) AS Bookings, Sum(DateDiff('d', r.CheckIn, r.CheckOut)) AS RoomNights, Sum(Round(DateDiff('d', r.CheckIn, r.CheckOut)*t.NightlyRate*(1-r.DiscountPct),2)) AS RoomRevenue, Sum(Round(DateDiff('d', r.CheckIn, r.CheckOut)*t.NightlyRate*(1-r.DiscountPct),2))/Sum(DateDiff('d', r.CheckIn, r.CheckOut)) AS ADR FROM (Reservations AS r INNER JOIN Rooms AS rm ON r.RoomID = rm.RoomID) INNER JOIN RoomTypes AS t ON rm.RoomTypeID = t.RoomTypeID WHERE r.BookingStatus <> 'Cancelled' GROUP BY Format(r.CheckIn,'yyyy-mm') ORDER BY Format(r.CheckIn,'yyyy-mm');

-- qryOccupancyByRoomType  [Select]  Nights sold per room type
SELECT t.TypeName, Count(rm.RoomID) AS Bookings, Sum(DateDiff('d', r.CheckIn, r.CheckOut)) AS NightsSold, t.NightlyRate FROM (RoomTypes AS t INNER JOIN Rooms AS rm ON t.RoomTypeID = rm.RoomTypeID) INNER JOIN Reservations AS r ON rm.RoomID = r.RoomID WHERE r.BookingStatus <> 'Cancelled' GROUP BY t.TypeName, t.NightlyRate ORDER BY Sum(DateDiff('d', r.CheckIn, r.CheckOut)) DESC;

-- qryChannelMix  [Select]  Booking channels performance
SELECT r.Channel, Count(r.ReservationID) AS Bookings, Sum(Round(DateDiff('d', r.CheckIn, r.CheckOut)*t.NightlyRate*(1-r.DiscountPct),2)) AS Revenue, Avg(DateDiff('d', r.CheckIn, r.CheckOut)) AS AvgStay FROM (Reservations AS r INNER JOIN Rooms AS rm ON r.RoomID = rm.RoomID) INNER JOIN RoomTypes AS t ON rm.RoomTypeID = t.RoomTypeID WHERE r.BookingStatus <> 'Cancelled' GROUP BY r.Channel ORDER BY Count(r.ReservationID) DESC;

-- qryInHouseGuests  [Select]  Guests currently in the hotel
SELECT rm.RoomNo, g.FullName, g.Nationality, g.IsVIP, r.CheckIn, r.CheckOut FROM (Reservations AS r INNER JOIN Guests AS g ON r.GuestID = g.GuestID) INNER JOIN Rooms AS rm ON r.RoomID = rm.RoomID WHERE r.CheckIn <= Date() AND r.CheckOut > Date() AND r.BookingStatus <> 'Cancelled' ORDER BY rm.RoomNo;

-- qryTopGuests  [Select]  Most loyal guests
SELECT TOP 10 g.FullName, g.Nationality, Count(r.ReservationID) AS Stays, Sum(DateDiff('d', r.CheckIn, r.CheckOut)) AS Nights FROM Guests AS g INNER JOIN Reservations AS r ON g.GuestID = r.GuestID WHERE r.BookingStatus <> 'Cancelled' GROUP BY g.FullName, g.Nationality ORDER BY Sum(DateDiff('d', r.CheckIn, r.CheckOut)) DESC;

-- qryXT_NightsByTypeMonth  [Crosstab]  Crosstab: room nights by type per month
TRANSFORM Sum(DateDiff('d', r.CheckIn, r.CheckOut)) AS Nights SELECT t.TypeName FROM (Reservations AS r INNER JOIN Rooms AS rm ON r.RoomID = rm.RoomID) INNER JOIN RoomTypes AS t ON rm.RoomTypeID = t.RoomTypeID WHERE r.BookingStatus <> 'Cancelled' GROUP BY t.TypeName PIVOT Format(r.CheckIn,'yyyy-mm');

-- qryAvailableRooms  [Parameter]  Parameter: free rooms for a date range (overlap check)
PARAMETERS [Check-in date] DateTime, [Check-out date] DateTime; SELECT rm.RoomNo, t.TypeName, t.NightlyRate, rm.SeaView FROM Rooms AS rm INNER JOIN RoomTypes AS t ON rm.RoomTypeID = t.RoomTypeID WHERE rm.RoomID NOT IN (SELECT r.RoomID FROM Reservations AS r WHERE r.BookingStatus <> 'Cancelled' AND r.CheckIn < [Check-out date] AND r.CheckOut > [Check-in date]) ORDER BY t.NightlyRate;

-- qryAction_AutoCheckOut  [Action]  Action: close past stays
UPDATE Reservations SET BookingStatus = 'Checked Out' WHERE CheckOut < Date() AND BookingStatus IN ('Confirmed','Checked In');
