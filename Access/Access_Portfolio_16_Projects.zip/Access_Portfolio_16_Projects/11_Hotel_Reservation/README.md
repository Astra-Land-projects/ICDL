# Hotel Reservation & Booking System

**سیستم رزرو هتل** — اتاق‌ها و انواع اتاق، مهمانان، رزرو با کنترل تداخل، خدمات اضافه، صورتحساب، نرخ اشغال و درآمد.

> Rooms and room types, guests, reservations with overlap check, extra services, folios, occupancy and revenue.

## نحوه راه‌اندازی

1. فایل `11_Hotel_Reservation.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| RoomTypes | 5 | Room categories and rates |
| Rooms | 30 | Physical rooms |
| Guests | 50 | Guest profiles |
| Reservations | 114 | Bookings |
| Services | 7 | Extras: spa, minibar, laundry... |
| ServiceCharges | 130 | Extras charged to a booking |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    RoomTypes ||--o{ Rooms : "RoomTypeID"
    Guests ||--o{ Reservations : "GuestID"
    Rooms ||--o{ Reservations : "RoomID"
    Reservations ||--o{ ServiceCharges : "ReservationID"
    Services ||--o{ ServiceCharges : "ServiceID"
    RoomTypes {
        pk RoomTypeID PK
        text TypeName
        cur NightlyRate
        int MaxGuests
    }
    Rooms {
        pk RoomID PK
        text RoomNo
        long RoomTypeID FK
        int FloorNo
        bool SeaView
        text RoomStatus
    }
    Guests {
        pk GuestID PK
        text FullName
        text Email
        text Phone
        text Nationality
        text PassportNo
        bool IsVIP
    }
    Reservations {
        pk ReservationID PK
        text BookingRef
        long GuestID FK
        long RoomID FK
        date CheckIn
        date CheckOut
        int Adults
        text Channel
        text BookingStatus
        dbl DiscountPct
    }
    Services {
        pk ServiceID PK
        text ServiceName
        cur Price
    }
    ServiceCharges {
        pk ChargeID PK
        long ReservationID FK
        long ServiceID FK
        date ChargeDate
        int Quantity
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryArrivalsDepartures | Select | Arrivals and departures in the next 7 days |
| qryGuestFolio | Select | Room + extras folio per booking |
| qryMonthlyRevenue | Select | Room nights, revenue and ADR (average daily rate) |
| qryOccupancyByRoomType | Select | Nights sold per room type |
| qryChannelMix | Select | Booking channels performance |
| qryInHouseGuests | Select | Guests currently in the hotel |
| qryTopGuests | Select | Most loyal guests |
| qryXT_NightsByTypeMonth | Crosstab | Crosstab: room nights by type per month |
| qryAvailableRooms | Parameter | Parameter: free rooms for a date range (overlap check) |
| qryAction_AutoCheckOut | Action | Action: close past stays |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmGuests | Guests | Single |
| frmRoomTypes | RoomTypes | Continuous |
| frmRooms | Rooms | Continuous |
| sfrmServiceCharges | ServiceCharges | Continuous |
| frmReservations | Reservations | Single + subform `sfrmServiceCharges` |
| frmServices | Services | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptArrivals | qryArrivalsDepartures | - | Adults |
| rptGuestFolios | qryGuestFolio | TypeName | Nights,RoomCharges,ExtrasCharges,TotalFolio |
| rptMonthlyRevenue | qryMonthlyRevenue | - | Bookings,RoomNights,RoomRevenue |
| rptChannelMix | qryChannelMix | - | Bookings,Revenue |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
