# Career, Immigration & Portfolio Tracker

**سیستم پیگیری شغل، مهاجرت و پورتفولیو** — اپلای‌های شغلی بین‌المللی و مصاحبه‌ها، مدارک مهاجرت با مهلت، کشورهای هدف، پروژه‌ها (Astra، AG9، Mahomeh، کهکشان، Zenix) و ماتریس مهارت‌ها.

> International job applications and interviews, immigration documents and deadlines, target countries, portfolio projects and skills matrix.

## نحوه راه‌اندازی

1. فایل `16_Career_Immigration_Portfolio.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Countries | 8 | Target countries |
| Companies | 15 | Employers |
| Applications | 32 | Job applications |
| Interviews | 43 | Interview rounds |
| ImmigrationDocs | 15 | Visa / immigration checklist |
| Skills | 17 | Skills matrix |
| PortfolioProjects | 7 | Brands and projects |
| ProjectSkills | 21 | Junction: projects <-> skills |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Countries ||--o{ Companies : "CountryID"
    Companies ||--o{ Applications : "CompanyID"
    Applications ||--o{ Interviews : "ApplicationID"
    Countries ||--o{ ImmigrationDocs : "CountryID"
    PortfolioProjects ||--o{ ProjectSkills : "ProjectID"
    Skills ||--o{ ProjectSkills : "SkillID"
    Countries {
        pk CountryID PK
        text CountryName
        text VisaPathway
        text CurrencyCode
        dbl FxToUSD
        int PriorityRank
    }
    Companies {
        pk CompanyID PK
        text CompanyName
        long CountryID FK
        text City
        text Industry
        bool SponsorsVisa
        text CareersURL
    }
    Applications {
        pk ApplicationID PK
        long CompanyID FK
        text JobTitle
        text TechStack
        date AppliedOn
        cur SalaryLocal
        text AppStatus
        text Source
        bool Remote
    }
    Interviews {
        pk InterviewID PK
        long ApplicationID FK
        int RoundNo
        text InterviewType
        date InterviewDate
        text Interviewer
        int SelfRating
        text Outcome
    }
    ImmigrationDocs {
        pk DocID PK
        long CountryID FK
        text DocName
        text Category
        date DueDate
        text DocStatus
        cur Cost
        text Notes
    }
    Skills {
        pk SkillID PK
        text SkillName
        text SkillCategory
        int SkillLevel
        dbl YearsExp
    }
    PortfolioProjects {
        pk ProjectID PK
        text ProjectName
        text Summary
        text ProjectType
        text RepoURL
        text LiveURL
        text ProjectStatus
        int StartYear
    }
    ProjectSkills {
        pk ProjectSkillID PK
        long ProjectID FK
        long SkillID FK
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryApplicationTracker | Select | All applications with salary in USD and follow-up flag |
| qryPipelineByStatus | Select | Job search funnel |
| qryCountryComparison | Select | Compare target countries |
| qryUpcomingInterviews | Select | Interview calendar |
| qryInterviewPerformance | Select | Pass rate per interview type |
| qryImmigrationChecklist | Select | Document deadlines with urgency alerts |
| qryImmigrationBudget | Select | Progress and cost per country |
| qryPortfolioShowcase | Select | Projects with the skills they demonstrate |
| qrySkillEvidence | Select | Which skills are proven by portfolio projects |
| qryXT_StatusByCountry | Crosstab | Crosstab: application status per country |
| qryJobsUsingSkill | Parameter | Parameter: applications mentioning a technology |
| qryAction_WithdrawStale | Action | Action: close applications with no reply for 60 days |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| sfrmInterviews | Interviews | Continuous |
| frmApplications | Applications | Single + subform `sfrmInterviews` |
| frmCompanies | Companies | Continuous |
| frmCountries | Countries | Continuous |
| frmImmigrationDocs | ImmigrationDocs | Continuous |
| sfrmProjectSkills | ProjectSkills | Continuous |
| frmPortfolioProjects | PortfolioProjects | Single + subform `sfrmProjectSkills` |
| frmSkills | Skills | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptApplicationTracker | qryApplicationTracker | AppStatus | - |
| rptCountryComparison | qryCountryComparison | - | Applications,ActiveProcesses,Offers |
| rptImmigrationChecklist | qryImmigrationChecklist | Country | Cost |
| rptPortfolio | qryPortfolioShowcase | ProjectName | - |
| rptUpcomingInterviews | qryUpcomingInterviews | - | - |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
