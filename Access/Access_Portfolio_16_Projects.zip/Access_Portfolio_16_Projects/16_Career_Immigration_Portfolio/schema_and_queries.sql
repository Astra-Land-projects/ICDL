-- Career, Immigration & Portfolio Tracker
-- International job applications and interviews, immigration documents and deadlines, target countries, portfolio projects and skills matrix.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Countries (
    CountryID COUNTER PRIMARY KEY,
    CountryName TEXT(50) NOT NULL UNIQUE,
    VisaPathway TEXT(80),
    CurrencyCode TEXT(3),
    FxToUSD DOUBLE,
    PriorityRank INTEGER
);

CREATE TABLE Companies (
    CompanyID COUNTER PRIMARY KEY,
    CompanyName TEXT(80) NOT NULL,
    CountryID LONG,
    City TEXT(40),
    Industry TEXT(40),
    SponsorsVisa YESNO,
    CareersURL TEXT(150)
);

CREATE TABLE Applications (
    ApplicationID COUNTER PRIMARY KEY,
    CompanyID LONG NOT NULL,
    JobTitle TEXT(80) NOT NULL,
    TechStack TEXT(150),
    AppliedOn DATETIME,
    SalaryLocal CURRENCY,
    AppStatus TEXT(20),
    Source TEXT(30),
    Remote YESNO
);

CREATE TABLE Interviews (
    InterviewID COUNTER PRIMARY KEY,
    ApplicationID LONG NOT NULL,
    RoundNo INTEGER,
    InterviewType TEXT(30),
    InterviewDate DATETIME,
    Interviewer TEXT(60),
    SelfRating INTEGER,
    Outcome TEXT(20)
);

CREATE TABLE ImmigrationDocs (
    DocID COUNTER PRIMARY KEY,
    CountryID LONG,
    DocName TEXT(80) NOT NULL,
    Category TEXT(30),
    DueDate DATETIME,
    DocStatus TEXT(20),
    Cost CURRENCY,
    Notes TEXT(255)
);

CREATE TABLE Skills (
    SkillID COUNTER PRIMARY KEY,
    SkillName TEXT(40) NOT NULL UNIQUE,
    SkillCategory TEXT(30),
    SkillLevel INTEGER,
    YearsExp DOUBLE
);

CREATE TABLE PortfolioProjects (
    ProjectID COUNTER PRIMARY KEY,
    ProjectName TEXT(60) NOT NULL,
    Summary TEXT(255),
    ProjectType TEXT(30),
    RepoURL TEXT(150),
    LiveURL TEXT(150),
    ProjectStatus TEXT(20),
    StartYear INTEGER
);

CREATE TABLE ProjectSkills (
    ProjectSkillID COUNTER PRIMARY KEY,
    ProjectID LONG NOT NULL,
    SkillID LONG NOT NULL
);

ALTER TABLE Companies ADD CONSTRAINT FK_Companies_CountryID FOREIGN KEY (CountryID) REFERENCES Countries (CountryID);
ALTER TABLE Applications ADD CONSTRAINT FK_Applications_CompanyID FOREIGN KEY (CompanyID) REFERENCES Companies (CompanyID);
ALTER TABLE Interviews ADD CONSTRAINT FK_Interviews_ApplicationID FOREIGN KEY (ApplicationID) REFERENCES Applications (ApplicationID) ON DELETE CASCADE;
ALTER TABLE ImmigrationDocs ADD CONSTRAINT FK_ImmigrationDocs_CountryID FOREIGN KEY (CountryID) REFERENCES Countries (CountryID);
ALTER TABLE ProjectSkills ADD CONSTRAINT FK_ProjectSkills_ProjectID FOREIGN KEY (ProjectID) REFERENCES PortfolioProjects (ProjectID) ON DELETE CASCADE;
ALTER TABLE ProjectSkills ADD CONSTRAINT FK_ProjectSkills_SkillID FOREIGN KEY (SkillID) REFERENCES Skills (SkillID);

-- ===== Saved queries =====

-- qryApplicationTracker  [Select]  All applications with salary in USD and follow-up flag
SELECT co.CompanyName, ct.CountryName, co.City, a.JobTitle, a.TechStack, a.AppliedOn, a.AppStatus, a.SalaryLocal, ct.CurrencyCode, Round(a.SalaryLocal*ct.FxToUSD,0) AS SalaryUSD, co.SponsorsVisa, IIf(a.AppliedOn Is Null, Null, DateDiff('d', a.AppliedOn, Date())) AS DaysSinceApplied, IIf(a.AppStatus='Applied' AND DateDiff('d', a.AppliedOn, Date()) > 14, 'Send follow-up', '') AS NextAction FROM (Applications AS a INNER JOIN Companies AS co ON a.CompanyID = co.CompanyID) INNER JOIN Countries AS ct ON co.CountryID = ct.CountryID ORDER BY a.AppliedOn DESC;

-- qryPipelineByStatus  [Select]  Job search funnel
SELECT a.AppStatus, Count(a.ApplicationID) AS Applications, Round(Avg(a.SalaryLocal*ct.FxToUSD),0) AS AvgSalaryUSD, Round(Max(a.SalaryLocal*ct.FxToUSD),0) AS MaxSalaryUSD FROM (Applications AS a INNER JOIN Companies AS co ON a.CompanyID = co.CompanyID) INNER JOIN Countries AS ct ON co.CountryID = ct.CountryID GROUP BY a.AppStatus ORDER BY Count(a.ApplicationID) DESC;

-- qryCountryComparison  [Select]  Compare target countries
SELECT ct.PriorityRank, ct.CountryName, ct.VisaPathway, Count(a.ApplicationID) AS Applications, Sum(IIf(a.AppStatus IN ('Screening','Technical','Interview','Offer'),1,0)) AS ActiveProcesses, Sum(IIf(a.AppStatus='Offer',1,0)) AS Offers, Round(Avg(a.SalaryLocal*ct.FxToUSD),0) AS AvgSalaryUSD FROM (Applications AS a INNER JOIN Companies AS co ON a.CompanyID = co.CompanyID) INNER JOIN Countries AS ct ON co.CountryID = ct.CountryID GROUP BY ct.PriorityRank, ct.CountryName, ct.VisaPathway ORDER BY ct.PriorityRank;

-- qryUpcomingInterviews  [Select]  Interview calendar
SELECT i.InterviewDate, co.CompanyName, a.JobTitle, i.RoundNo, i.InterviewType, i.Interviewer FROM (Interviews AS i INNER JOIN Applications AS a ON i.ApplicationID = a.ApplicationID) INNER JOIN Companies AS co ON a.CompanyID = co.CompanyID WHERE i.InterviewDate >= Date() ORDER BY i.InterviewDate;

-- qryInterviewPerformance  [Select]  Pass rate per interview type
SELECT i.InterviewType, Count(i.InterviewID) AS Rounds, Sum(IIf(i.Outcome='Passed',1,0)) AS Passed, Round(Avg(i.SelfRating),2) AS AvgSelfRating FROM Interviews AS i WHERE i.Outcome <> 'Scheduled' GROUP BY i.InterviewType ORDER BY Count(i.InterviewID) DESC;

-- qryImmigrationChecklist  [Select]  Document deadlines with urgency alerts
SELECT Nz(ct.CountryName,'All countries') AS Country, d.DocName, d.Category, d.DueDate, DateDiff('d', Date(), d.DueDate) AS DaysLeft, d.DocStatus, d.Cost, IIf(d.DocStatus <> 'Completed' AND d.DueDate < Date(), 'OVERDUE', IIf(d.DocStatus <> 'Completed' AND DateDiff('d', Date(), d.DueDate) <= 30, 'URGENT', '')) AS Alert FROM ImmigrationDocs AS d LEFT JOIN Countries AS ct ON d.CountryID = ct.CountryID ORDER BY d.DueDate;

-- qryImmigrationBudget  [Select]  Progress and cost per country
SELECT Nz(ct.CountryName,'All countries') AS Country, Count(d.DocID) AS Documents, Sum(IIf(d.DocStatus='Completed',1,0)) AS Completed, Sum(d.Cost) AS TotalCost FROM ImmigrationDocs AS d LEFT JOIN Countries AS ct ON d.CountryID = ct.CountryID GROUP BY ct.CountryName ORDER BY Sum(d.Cost) DESC;

-- qryPortfolioShowcase  [Select]  Projects with the skills they demonstrate
SELECT pp.ProjectName, pp.ProjectType, pp.ProjectStatus, pp.StartYear, s.SkillName, s.SkillCategory, pp.RepoURL FROM (PortfolioProjects AS pp INNER JOIN ProjectSkills AS ps ON pp.ProjectID = ps.ProjectID) INNER JOIN Skills AS s ON ps.SkillID = s.SkillID ORDER BY pp.StartYear DESC, pp.ProjectName;

-- qrySkillEvidence  [Select]  Which skills are proven by portfolio projects
SELECT s.SkillName, s.SkillCategory, s.SkillLevel, s.YearsExp, Count(ps.ProjectID) AS ProjectsUsingSkill, IIf(Count(ps.ProjectID)=0, 'Build a project to prove this', 'Backed by projects') AS EvidenceNote FROM Skills AS s LEFT JOIN ProjectSkills AS ps ON s.SkillID = ps.SkillID GROUP BY s.SkillName, s.SkillCategory, s.SkillLevel, s.YearsExp ORDER BY s.SkillLevel DESC, Count(ps.ProjectID) DESC;

-- qryXT_StatusByCountry  [Crosstab]  Crosstab: application status per country
TRANSFORM Count(a.ApplicationID) AS Apps SELECT ct.CountryName FROM (Applications AS a INNER JOIN Companies AS co ON a.CompanyID = co.CompanyID) INNER JOIN Countries AS ct ON co.CountryID = ct.CountryID GROUP BY ct.CountryName PIVOT a.AppStatus;

-- qryJobsUsingSkill  [Parameter]  Parameter: applications mentioning a technology
PARAMETERS [Skill keyword] Text ( 255 ); SELECT co.CompanyName, a.JobTitle, a.TechStack, a.AppStatus FROM Applications AS a INNER JOIN Companies AS co ON a.CompanyID = co.CompanyID WHERE a.TechStack Like '*' & [Skill keyword] & '*';

-- qryAction_WithdrawStale  [Action]  Action: close applications with no reply for 60 days
UPDATE Applications SET AppStatus = 'Withdrawn' WHERE AppStatus = 'Applied' AND DateDiff('d', AppliedOn, Date()) > 60;
