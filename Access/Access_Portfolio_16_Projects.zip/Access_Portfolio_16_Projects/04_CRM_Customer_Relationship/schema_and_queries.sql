-- CRM - Customer Relationship Management
-- Companies, contacts, sales opportunities with stage probabilities, activities and weighted revenue forecast.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Companies (
    CompanyID COUNTER PRIMARY KEY,
    CompanyName TEXT(100) NOT NULL,
    Industry TEXT(50),
    Website TEXT(100),
    Country TEXT(50),
    Employees LONG,
    LeadSource TEXT(30)
);

CREATE TABLE Contacts (
    ContactID COUNTER PRIMARY KEY,
    CompanyID LONG,
    FirstName TEXT(40) NOT NULL,
    LastName TEXT(40) NOT NULL,
    JobTitle TEXT(60),
    Email TEXT(100),
    Phone TEXT(30),
    IsDecisionMaker YESNO
);

CREATE TABLE Stages (
    StageID COUNTER PRIMARY KEY,
    StageName TEXT(30) NOT NULL UNIQUE,
    StageOrder INTEGER,
    Probability DOUBLE
);

CREATE TABLE Opportunities (
    OppID COUNTER PRIMARY KEY,
    OppName TEXT(100) NOT NULL,
    CompanyID LONG NOT NULL,
    StageID LONG NOT NULL,
    Owner TEXT(40),
    Amount CURRENCY,
    CreatedDate DATETIME,
    ExpectedClose DATETIME
);

CREATE TABLE Activities (
    ActivityID COUNTER PRIMARY KEY,
    OppID LONG,
    ContactID LONG,
    ActivityType TEXT(20),
    ActivityDate DATETIME,
    Subject TEXT(150),
    Completed YESNO
);

ALTER TABLE Contacts ADD CONSTRAINT FK_Contacts_CompanyID FOREIGN KEY (CompanyID) REFERENCES Companies (CompanyID) ON DELETE CASCADE;
ALTER TABLE Opportunities ADD CONSTRAINT FK_Opportunities_CompanyID FOREIGN KEY (CompanyID) REFERENCES Companies (CompanyID);
ALTER TABLE Opportunities ADD CONSTRAINT FK_Opportunities_StageID FOREIGN KEY (StageID) REFERENCES Stages (StageID);
ALTER TABLE Activities ADD CONSTRAINT FK_Activities_OppID FOREIGN KEY (OppID) REFERENCES Opportunities (OppID) ON DELETE CASCADE;
ALTER TABLE Activities ADD CONSTRAINT FK_Activities_ContactID FOREIGN KEY (ContactID) REFERENCES Contacts (ContactID);

-- ===== Saved queries =====

-- qryPipeline  [Select]  Open pipeline with weighted value
SELECT o.OppName, c.CompanyName, s.StageName, s.StageOrder, o.Owner, o.Amount, s.Probability, o.Amount*s.Probability AS WeightedAmount, o.ExpectedClose, DateDiff('d', Date(), o.ExpectedClose) AS DaysToClose FROM (Opportunities AS o INNER JOIN Companies AS c ON o.CompanyID = c.CompanyID) INNER JOIN Stages AS s ON o.StageID = s.StageID WHERE s.StageName NOT IN ('Closed Won','Closed Lost') ORDER BY s.StageOrder, o.ExpectedClose;

-- qryPipelineByStage  [Select]  Funnel summary by stage
SELECT s.StageOrder, s.StageName, Count(o.OppID) AS Deals, Sum(o.Amount) AS TotalAmount, Sum(o.Amount*s.Probability) AS WeightedAmount FROM Stages AS s LEFT JOIN Opportunities AS o ON s.StageID = o.StageID GROUP BY s.StageOrder, s.StageName ORDER BY s.StageOrder;

-- qryWinRateByOwner  [Select]  Sales rep performance
SELECT o.Owner, Sum(IIf(s.StageName='Closed Won',1,0)) AS Won, Sum(IIf(s.StageName='Closed Lost',1,0)) AS Lost, Sum(IIf(s.StageName='Closed Won',o.Amount,0)) AS WonAmount, IIf(Sum(IIf(s.StageName IN ('Closed Won','Closed Lost'),1,0))=0, 0, Sum(IIf(s.StageName='Closed Won',1,0))/Sum(IIf(s.StageName IN ('Closed Won','Closed Lost'),1,0))) AS WinRate FROM Opportunities AS o INNER JOIN Stages AS s ON o.StageID = s.StageID GROUP BY o.Owner;

-- qryForecastByMonth  [Select]  Weighted revenue forecast by close month
SELECT Format(o.ExpectedClose,'yyyy-mm') AS CloseMonth, Count(o.OppID) AS Deals, Sum(o.Amount) AS Pipeline, Sum(o.Amount*s.Probability) AS Forecast FROM Opportunities AS o INNER JOIN Stages AS s ON o.StageID = s.StageID WHERE s.StageName <> 'Closed Lost' GROUP BY Format(o.ExpectedClose,'yyyy-mm') ORDER BY Format(o.ExpectedClose,'yyyy-mm');

-- qryUpcomingActivities  [Select]  Open to-do activities
SELECT a.ActivityDate, a.ActivityType, a.Subject, ct.FirstName & ' ' & ct.LastName AS ContactName, o.OppName FROM (Activities AS a INNER JOIN Contacts AS ct ON a.ContactID = ct.ContactID) INNER JOIN Opportunities AS o ON a.OppID = o.OppID WHERE a.Completed = False ORDER BY a.ActivityDate;

-- qryStaleDeals  [Select]  Open deals with no contact for 30+ days
SELECT o.OppName, s.StageName, o.Owner, o.Amount, Max(a.ActivityDate) AS LastActivity, DateDiff('d', Max(a.ActivityDate), Date()) AS DaysSinceContact FROM (Opportunities AS o INNER JOIN Stages AS s ON o.StageID = s.StageID) INNER JOIN Activities AS a ON o.OppID = a.OppID WHERE s.StageName NOT IN ('Closed Won','Closed Lost') GROUP BY o.OppName, s.StageName, o.Owner, o.Amount HAVING DateDiff('d', Max(a.ActivityDate), Date()) > 30 ORDER BY DateDiff('d', Max(a.ActivityDate), Date()) DESC;

-- qryContactList  [Select]  All contacts by company
SELECT c.CompanyName, c.Industry, ct.FirstName & ' ' & ct.LastName AS ContactName, ct.JobTitle, ct.Email, ct.Phone, ct.IsDecisionMaker FROM Companies AS c INNER JOIN Contacts AS ct ON c.CompanyID = ct.CompanyID ORDER BY c.CompanyName;

-- qryXT_IndustryByStage  [Crosstab]  Crosstab: deal value by industry and stage
TRANSFORM Sum(o.Amount) AS Amount SELECT c.Industry FROM (Opportunities AS o INNER JOIN Companies AS c ON o.CompanyID = c.CompanyID) INNER JOIN Stages AS s ON o.StageID = s.StageID GROUP BY c.Industry PIVOT s.StageName;

-- qryAction_MarkPastActivitiesDone  [Action]  Action: complete activities older than a week
UPDATE Activities SET Completed = True WHERE ActivityDate < Date() - 7;
