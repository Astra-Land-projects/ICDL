# CRM - Customer Relationship Management

**سیستم مدیریت ارتباط با مشتری (CRM)** — شرکت‌ها، مخاطبین، فرصت‌های فروش با مراحل و احتمال موفقیت، فعالیت‌ها (تماس، جلسه، ایمیل) و پیش‌بینی درآمد.

> Companies, contacts, sales opportunities with stage probabilities, activities and weighted revenue forecast.

## نحوه راه‌اندازی

1. فایل `04_CRM_Customer_Relationship.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Companies | 18 | Accounts / organisations |
| Contacts | 40 | People at each company |
| Stages | 6 | Pipeline stages and win probability |
| Opportunities | 36 | Sales deals |
| Activities | 87 | Calls, meetings, emails, demos |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Companies ||--o{ Contacts : "CompanyID"
    Companies ||--o{ Opportunities : "CompanyID"
    Stages ||--o{ Opportunities : "StageID"
    Opportunities ||--o{ Activities : "OppID"
    Contacts ||--o{ Activities : "ContactID"
    Companies {
        pk CompanyID PK
        text CompanyName
        text Industry
        text Website
        text Country
        long Employees
        text LeadSource
    }
    Contacts {
        pk ContactID PK
        long CompanyID FK
        text FirstName
        text LastName
        text JobTitle
        text Email
        text Phone
        bool IsDecisionMaker
    }
    Stages {
        pk StageID PK
        text StageName
        int StageOrder
        dbl Probability
    }
    Opportunities {
        pk OppID PK
        text OppName
        long CompanyID FK
        long StageID FK
        text Owner
        cur Amount
        date CreatedDate
        date ExpectedClose
    }
    Activities {
        pk ActivityID PK
        long OppID FK
        long ContactID FK
        text ActivityType
        date ActivityDate
        text Subject
        bool Completed
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryPipeline | Select | Open pipeline with weighted value |
| qryPipelineByStage | Select | Funnel summary by stage |
| qryWinRateByOwner | Select | Sales rep performance |
| qryForecastByMonth | Select | Weighted revenue forecast by close month |
| qryUpcomingActivities | Select | Open to-do activities |
| qryStaleDeals | Select | Open deals with no contact for 30+ days |
| qryContactList | Select | All contacts by company |
| qryXT_IndustryByStage | Crosstab | Crosstab: deal value by industry and stage |
| qryAction_MarkPastActivitiesDone | Action | Action: complete activities older than a week |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmCompanies | Companies | Single |
| frmContacts | Contacts | Continuous |
| frmStages | Stages | Continuous |
| sfrmActivities | Activities | Continuous |
| frmOpportunities | Opportunities | Single + subform `sfrmActivities` |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptPipeline | qryPipeline | StageName | Amount,WeightedAmount |
| rptPipelineByStage | qryPipelineByStage | - | Deals,TotalAmount,WeightedAmount |
| rptForecast | qryForecastByMonth | - | Pipeline,Forecast |
| rptContactList | qryContactList | CompanyName | - |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
