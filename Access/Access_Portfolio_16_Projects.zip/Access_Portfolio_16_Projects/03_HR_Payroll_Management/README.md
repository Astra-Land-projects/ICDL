# HR & Payroll Management System

**سیستم منابع انسانی و حقوق و دستمزد** — پرونده کارکنان، دپارتمان‌ها، حضور و غیاب، مرخصی، محاسبه حقوق با اضافه‌کار، مالیات و بیمه.

> Employee records, departments, attendance, leave requests and monthly payroll with overtime, tax and insurance.

## نحوه راه‌اندازی

1. فایل `03_HR_Payroll_Management.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Departments | 6 | Company departments |
| JobTitles | 9 | Job titles and salary bands |
| Employees | 24 | Employee master |
| Attendance | 480 | Daily attendance |
| LeaveRequests | 13 | Vacation / sick leave |
| PayrollRuns | 96 | Monthly payslips |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Departments ||--o{ Employees : "DeptID"
    JobTitles ||--o{ Employees : "JobTitleID"
    Employees ||--o{ Attendance : "EmployeeID"
    Employees ||--o{ LeaveRequests : "EmployeeID"
    Employees ||--o{ PayrollRuns : "EmployeeID"
    Departments {
        pk DeptID PK
        text DeptName
        text Manager
        cur Budget
    }
    JobTitles {
        pk JobTitleID PK
        text TitleName
        int Grade
        cur MinSalary
        cur MaxSalary
    }
    Employees {
        pk EmployeeID PK
        text EmpCode
        text FirstName
        text LastName
        text Email
        long DeptID FK
        long JobTitleID FK
        date HireDate
        cur BaseSalary
        bool IsActive
    }
    Attendance {
        pk AttendanceID PK
        long EmployeeID FK
        date WorkDate
        dbl HoursWorked
        dbl OvertimeHours
        text AttendanceStatus
    }
    LeaveRequests {
        pk LeaveID PK
        long EmployeeID FK
        text LeaveType
        date StartDate
        date EndDate
        bool Approved
        text Reason
    }
    PayrollRuns {
        pk PayrollID PK
        long EmployeeID FK
        text PayMonth
        cur BaseSalary
        cur OvertimePay
        cur Bonus
        dbl TaxRate
        dbl InsuranceRate
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryEmployeeDirectory | Select | Employee directory with tenure |
| qryPayslips | Select | Payslips: gross, tax, insurance and net pay |
| qryPayrollByDepartment | Select | Payroll cost by department and month |
| qryAttendanceSummary | Select | Hours, overtime and absences per employee |
| qryLeaveCalendar | Select | Leave requests with day count |
| qrySalaryBandCheck | Select | Compare salaries with job bands |
| qryWorkAnniversaries | Select | Work anniversaries this month and next |
| qryXT_HeadcountByTitle | Crosstab | Crosstab: headcount by department and title |
| qryPayslipForMonth | Parameter | Parameter: payroll for one month |
| qryAction_ApproveShortLeave | Action | Action: auto-approve leaves of 3 days or less |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmDepartments | Departments | Continuous |
| frmJobTitles | JobTitles | Continuous |
| frmEmployees | Employees | Single |
| frmAttendance | Attendance | Continuous |
| frmLeaveRequests | LeaveRequests | Continuous |
| frmPayrollRuns | PayrollRuns | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptEmployeeDirectory | qryEmployeeDirectory | DeptName | BaseSalary |
| rptPayslips | qryPayslips | PayMonth | GrossPay,IncomeTax,Insurance,NetPay |
| rptPayrollByDepartment | qryPayrollByDepartment | PayMonth | TotalGross,TotalNet |
| rptAttendanceSummary | qryAttendanceSummary | - | TotalHours,Overtime,Absences |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
