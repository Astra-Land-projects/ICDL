-- HR & Payroll Management System
-- Employee records, departments, attendance, leave requests and monthly payroll with overtime, tax and insurance.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Departments (
    DeptID COUNTER PRIMARY KEY,
    DeptName TEXT(50) NOT NULL UNIQUE,
    Manager TEXT(60),
    Budget CURRENCY
);

CREATE TABLE JobTitles (
    JobTitleID COUNTER PRIMARY KEY,
    TitleName TEXT(60) NOT NULL,
    Grade INTEGER,
    MinSalary CURRENCY,
    MaxSalary CURRENCY
);

CREATE TABLE Employees (
    EmployeeID COUNTER PRIMARY KEY,
    EmpCode TEXT(10) NOT NULL UNIQUE,
    FirstName TEXT(40) NOT NULL,
    LastName TEXT(40) NOT NULL,
    Email TEXT(100),
    DeptID LONG,
    JobTitleID LONG,
    HireDate DATETIME,
    BaseSalary CURRENCY,
    IsActive YESNO
);

CREATE TABLE Attendance (
    AttendanceID COUNTER PRIMARY KEY,
    EmployeeID LONG NOT NULL,
    WorkDate DATETIME,
    HoursWorked DOUBLE,
    OvertimeHours DOUBLE,
    AttendanceStatus TEXT(20)
);

CREATE TABLE LeaveRequests (
    LeaveID COUNTER PRIMARY KEY,
    EmployeeID LONG NOT NULL,
    LeaveType TEXT(20),
    StartDate DATETIME,
    EndDate DATETIME,
    Approved YESNO,
    Reason TEXT(255)
);

CREATE TABLE PayrollRuns (
    PayrollID COUNTER PRIMARY KEY,
    EmployeeID LONG NOT NULL,
    PayMonth TEXT(7),
    BaseSalary CURRENCY,
    OvertimePay CURRENCY,
    Bonus CURRENCY,
    TaxRate DOUBLE,
    InsuranceRate DOUBLE
);

ALTER TABLE Employees ADD CONSTRAINT FK_Employees_DeptID FOREIGN KEY (DeptID) REFERENCES Departments (DeptID);
ALTER TABLE Employees ADD CONSTRAINT FK_Employees_JobTitleID FOREIGN KEY (JobTitleID) REFERENCES JobTitles (JobTitleID);
ALTER TABLE Attendance ADD CONSTRAINT FK_Attendance_EmployeeID FOREIGN KEY (EmployeeID) REFERENCES Employees (EmployeeID) ON DELETE CASCADE;
ALTER TABLE LeaveRequests ADD CONSTRAINT FK_LeaveRequests_EmployeeID FOREIGN KEY (EmployeeID) REFERENCES Employees (EmployeeID) ON DELETE CASCADE;
ALTER TABLE PayrollRuns ADD CONSTRAINT FK_PayrollRuns_EmployeeID FOREIGN KEY (EmployeeID) REFERENCES Employees (EmployeeID) ON DELETE CASCADE;

-- ===== Saved queries =====

-- qryEmployeeDirectory  [Select]  Employee directory with tenure
SELECT e.EmpCode, e.FirstName & ' ' & e.LastName AS FullName, d.DeptName, j.TitleName, e.Email, e.HireDate, DateDiff('yyyy', e.HireDate, Date()) AS TenureYears, e.BaseSalary, e.IsActive FROM (Employees AS e INNER JOIN Departments AS d ON e.DeptID = d.DeptID) INNER JOIN JobTitles AS j ON e.JobTitleID = j.JobTitleID ORDER BY d.DeptName, e.LastName;

-- qryPayslips  [Select]  Payslips: gross, tax, insurance and net pay
SELECT pr.PayMonth, e.EmpCode, e.FirstName & ' ' & e.LastName AS FullName, d.DeptName, pr.BaseSalary, pr.OvertimePay, pr.Bonus, (pr.BaseSalary + pr.OvertimePay + pr.Bonus) AS GrossPay, Round((pr.BaseSalary + pr.OvertimePay + pr.Bonus)*pr.TaxRate,2) AS IncomeTax, Round((pr.BaseSalary + pr.OvertimePay + pr.Bonus)*pr.InsuranceRate,2) AS Insurance, (pr.BaseSalary + pr.OvertimePay + pr.Bonus) - Round((pr.BaseSalary + pr.OvertimePay + pr.Bonus)*pr.TaxRate,2) - Round((pr.BaseSalary + pr.OvertimePay + pr.Bonus)*pr.InsuranceRate,2) AS NetPay FROM (PayrollRuns AS pr INNER JOIN Employees AS e ON pr.EmployeeID = e.EmployeeID) INNER JOIN Departments AS d ON e.DeptID = d.DeptID ORDER BY pr.PayMonth, e.EmpCode;

-- qryPayrollByDepartment  [Select]  Payroll cost by department and month
SELECT pr.PayMonth, d.DeptName, Count(pr.PayrollID) AS Headcount, Sum((pr.BaseSalary + pr.OvertimePay + pr.Bonus)) AS TotalGross, Sum((pr.BaseSalary + pr.OvertimePay + pr.Bonus) - Round((pr.BaseSalary + pr.OvertimePay + pr.Bonus)*pr.TaxRate,2) - Round((pr.BaseSalary + pr.OvertimePay + pr.Bonus)*pr.InsuranceRate,2)) AS TotalNet FROM (PayrollRuns AS pr INNER JOIN Employees AS e ON pr.EmployeeID = e.EmployeeID) INNER JOIN Departments AS d ON e.DeptID = d.DeptID GROUP BY pr.PayMonth, d.DeptName ORDER BY pr.PayMonth, d.DeptName;

-- qryAttendanceSummary  [Select]  Hours, overtime and absences per employee
SELECT e.EmpCode, e.FirstName & ' ' & e.LastName AS FullName, Count(a.AttendanceID) AS DaysRecorded, Sum(a.HoursWorked) AS TotalHours, Sum(a.OvertimeHours) AS Overtime, Sum(IIf(a.AttendanceStatus='Absent',1,0)) AS Absences, Sum(IIf(a.AttendanceStatus='Remote',1,0)) AS RemoteDays FROM Employees AS e INNER JOIN Attendance AS a ON e.EmployeeID = a.EmployeeID GROUP BY e.EmpCode, e.FirstName, e.LastName ORDER BY Sum(a.HoursWorked) DESC;

-- qryLeaveCalendar  [Select]  Leave requests with day count
SELECT e.FirstName & ' ' & e.LastName AS FullName, l.LeaveType, l.StartDate, l.EndDate, DateDiff('d', l.StartDate, l.EndDate) + 1 AS LeaveDays, IIf(l.Approved, 'Approved', 'Pending') AS Approval FROM Employees AS e INNER JOIN LeaveRequests AS l ON e.EmployeeID = l.EmployeeID ORDER BY l.StartDate;

-- qrySalaryBandCheck  [Select]  Compare salaries with job bands
SELECT e.EmpCode, e.FirstName & ' ' & e.LastName AS FullName, j.TitleName, e.BaseSalary, j.MinSalary, j.MaxSalary, IIf(e.BaseSalary < j.MinSalary, 'Below band', IIf(e.BaseSalary > j.MaxSalary, 'Above band', 'Within band')) AS BandStatus FROM Employees AS e INNER JOIN JobTitles AS j ON e.JobTitleID = j.JobTitleID ORDER BY j.TitleName;

-- qryWorkAnniversaries  [Select]  Work anniversaries this month and next
SELECT e.FirstName & ' ' & e.LastName AS FullName, e.HireDate, DateDiff('yyyy', e.HireDate, Date()) AS YearsOfService FROM Employees AS e WHERE Month(e.HireDate) IN (Month(Date()), Month(DateAdd('m',1,Date()))) ORDER BY Month(e.HireDate), Day(e.HireDate);

-- qryXT_HeadcountByTitle  [Crosstab]  Crosstab: headcount by department and title
TRANSFORM Count(e.EmployeeID) AS Headcount SELECT d.DeptName FROM (Employees AS e INNER JOIN Departments AS d ON e.DeptID = d.DeptID) INNER JOIN JobTitles AS j ON e.JobTitleID = j.JobTitleID GROUP BY d.DeptName PIVOT j.TitleName;

-- qryPayslipForMonth  [Parameter]  Parameter: payroll for one month
PARAMETERS [Pay month (yyyy-mm)] Text ( 255 ); SELECT e.EmpCode, e.FirstName & ' ' & e.LastName AS FullName, pr.BaseSalary, pr.OvertimePay, pr.Bonus FROM PayrollRuns AS pr INNER JOIN Employees AS e ON pr.EmployeeID = e.EmployeeID WHERE pr.PayMonth = [Pay month (yyyy-mm)];

-- qryAction_ApproveShortLeave  [Action]  Action: auto-approve leaves of 3 days or less
UPDATE LeaveRequests SET Approved = True WHERE DateDiff('d', StartDate, EndDate) <= 2 AND Approved = False;
