# Gym Membership & Fitness Club

**سیستم مدیریت باشگاه ورزشی و عضویت** — اعضا و پلن‌های عضویت، تمدید، مربیان، کلاس‌های گروهی و رزرو، ورود و خروج (Check-in)، تمدیدهای نزدیک و درآمد.

> Members, membership plans and renewals, trainers, group classes and bookings, check-ins, expiring memberships and revenue.

## نحوه راه‌اندازی

1. فایل `15_Gym_Membership_Fitness.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Plans | 5 | Membership plans |
| Trainers | 5 | Coaches |
| Members | 60 | Club members |
| Subscriptions | 163 | Plan purchases and renewals |
| GroupClasses | 114 | Scheduled group classes |
| ClassBookings | 1054 | Who booked which class |
| CheckIns | 946 | Door access log |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Trainers ||--o{ Members : "PersonalTrainerID"
    Members ||--o{ Subscriptions : "MemberID"
    Plans ||--o{ Subscriptions : "PlanID"
    Trainers ||--o{ GroupClasses : "TrainerID"
    GroupClasses ||--o{ ClassBookings : "ClassID"
    Members ||--o{ ClassBookings : "MemberID"
    Members ||--o{ CheckIns : "MemberID"
    Plans {
        pk PlanID PK
        text PlanName
        int DurationMonths
        cur MonthlyFee
        bool IncludesClasses
    }
    Trainers {
        pk TrainerID PK
        text TrainerName
        text Specialty
        cur HourlyRate
        bool Certified
    }
    Members {
        pk MemberID PK
        text MemberNo
        text FullName
        text Gender
        date BirthDate
        text Phone
        text Email
        date JoinDate
        long PersonalTrainerID FK
    }
    Subscriptions {
        pk SubscriptionID PK
        long MemberID FK
        long PlanID FK
        date StartDate
        date EndDate
        cur AmountPaid
        text PaymentMethod
    }
    GroupClasses {
        pk ClassID PK
        text ClassTitle
        long TrainerID FK
        date ClassDateTime
        int DurationMin
        int Capacity
        text Studio
    }
    ClassBookings {
        pk BookingID PK
        long ClassID FK
        long MemberID FK
        bool Attended
    }
    CheckIns {
        pk CheckInID PK
        long MemberID FK
        date CheckInTime
        date CheckOutTime
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryMembershipStatus | Select | Current membership per member (latest subscription) |
| qryRenewalReminders | Select | Call list: expired in last 30 days or expiring in 3 weeks |
| qryMonthlyRevenue | Select | Subscription sales per month |
| qryPlanPopularity | Select | Plan mix |
| qryClassAttendance | Select | Bookings vs attendance per class type |
| qryUpcomingClasses | Select | Class schedule with free spots |
| qryVisitFrequency | Select | Engagement and churn risk from check-ins |
| qryPeakHours | Select | Busiest hours |
| qryXT_CheckInsWeekday | Crosstab | Crosstab: check-ins by hour and weekday |
| qryMemberCard | Parameter | Parameter: subscription history of a member |
| qryAction_RemovePastNoShows | Action | Action: purge no-show bookings older than 90 days |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| sfrmSubscriptions | Subscriptions | Continuous |
| frmMembers | Members | Single + subform `sfrmSubscriptions` |
| frmPlans | Plans | Continuous |
| frmTrainers | Trainers | Continuous |
| sfrmClassBookings | ClassBookings | Continuous |
| frmGroupClasses | GroupClasses | Single + subform `sfrmClassBookings` |
| frmCheckIns | CheckIns | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptMembershipStatus | qryMembershipStatus | MembershipStatus | - |
| rptRenewalReminders | qryRenewalReminders | - | - |
| rptMonthlyRevenue | qryMonthlyRevenue | - | SubscriptionsSold,Revenue,LongTermRevenue |
| rptUpcomingClasses | qryUpcomingClasses | ClassTitle | Booked,SpotsLeft |
| rptEngagement | qryVisitFrequency | Engagement | Visits60Days |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
