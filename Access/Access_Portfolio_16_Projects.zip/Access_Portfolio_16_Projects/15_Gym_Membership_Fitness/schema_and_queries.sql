-- Gym Membership & Fitness Club
-- Members, membership plans and renewals, trainers, group classes and bookings, check-ins, expiring memberships and revenue.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Plans (
    PlanID COUNTER PRIMARY KEY,
    PlanName TEXT(40) NOT NULL UNIQUE,
    DurationMonths INTEGER,
    MonthlyFee CURRENCY,
    IncludesClasses YESNO
);

CREATE TABLE Trainers (
    TrainerID COUNTER PRIMARY KEY,
    TrainerName TEXT(60) NOT NULL,
    Specialty TEXT(40),
    HourlyRate CURRENCY,
    Certified YESNO
);

CREATE TABLE Members (
    MemberID COUNTER PRIMARY KEY,
    MemberNo TEXT(10) NOT NULL UNIQUE,
    FullName TEXT(60) NOT NULL,
    Gender TEXT(1),
    BirthDate DATETIME,
    Phone TEXT(30),
    Email TEXT(100),
    JoinDate DATETIME,
    PersonalTrainerID LONG
);

CREATE TABLE Subscriptions (
    SubscriptionID COUNTER PRIMARY KEY,
    MemberID LONG NOT NULL,
    PlanID LONG NOT NULL,
    StartDate DATETIME,
    EndDate DATETIME,
    AmountPaid CURRENCY,
    PaymentMethod TEXT(15)
);

CREATE TABLE GroupClasses (
    ClassID COUNTER PRIMARY KEY,
    ClassTitle TEXT(40) NOT NULL,
    TrainerID LONG,
    ClassDateTime DATETIME,
    DurationMin INTEGER,
    Capacity INTEGER,
    Studio TEXT(20)
);

CREATE TABLE ClassBookings (
    BookingID COUNTER PRIMARY KEY,
    ClassID LONG NOT NULL,
    MemberID LONG NOT NULL,
    Attended YESNO
);

CREATE TABLE CheckIns (
    CheckInID COUNTER PRIMARY KEY,
    MemberID LONG NOT NULL,
    CheckInTime DATETIME,
    CheckOutTime DATETIME
);

ALTER TABLE Members ADD CONSTRAINT FK_Members_PersonalTrainerID FOREIGN KEY (PersonalTrainerID) REFERENCES Trainers (TrainerID);
ALTER TABLE Subscriptions ADD CONSTRAINT FK_Subscriptions_MemberID FOREIGN KEY (MemberID) REFERENCES Members (MemberID) ON DELETE CASCADE;
ALTER TABLE Subscriptions ADD CONSTRAINT FK_Subscriptions_PlanID FOREIGN KEY (PlanID) REFERENCES Plans (PlanID);
ALTER TABLE GroupClasses ADD CONSTRAINT FK_GroupClasses_TrainerID FOREIGN KEY (TrainerID) REFERENCES Trainers (TrainerID);
ALTER TABLE ClassBookings ADD CONSTRAINT FK_ClassBookings_ClassID FOREIGN KEY (ClassID) REFERENCES GroupClasses (ClassID) ON DELETE CASCADE;
ALTER TABLE ClassBookings ADD CONSTRAINT FK_ClassBookings_MemberID FOREIGN KEY (MemberID) REFERENCES Members (MemberID) ON DELETE CASCADE;
ALTER TABLE CheckIns ADD CONSTRAINT FK_CheckIns_MemberID FOREIGN KEY (MemberID) REFERENCES Members (MemberID) ON DELETE CASCADE;

-- ===== Saved queries =====

-- qryMembershipStatus  [Select]  Current membership per member (latest subscription)
SELECT m.MemberNo, m.FullName, m.Phone, pl.PlanName, s.StartDate, s.EndDate, DateDiff('d', Date(), s.EndDate) AS DaysLeft, IIf(s.EndDate < Date(), 'Expired', IIf(DateDiff('d', Date(), s.EndDate) <= 14, 'Expiring Soon', 'Active')) AS MembershipStatus FROM (Members AS m INNER JOIN Subscriptions AS s ON m.MemberID = s.MemberID) INNER JOIN Plans AS pl ON s.PlanID = pl.PlanID WHERE s.EndDate = (SELECT Max(x.EndDate) FROM Subscriptions AS x WHERE x.MemberID = m.MemberID) ORDER BY s.EndDate;

-- qryRenewalReminders  [Select]  Call list: expired in last 30 days or expiring in 3 weeks
SELECT m.MemberNo, m.FullName, m.Phone, m.Email, pl.PlanName, s.EndDate, DateDiff('d', Date(), s.EndDate) AS DaysLeft FROM (Members AS m INNER JOIN Subscriptions AS s ON m.MemberID = s.MemberID) INNER JOIN Plans AS pl ON s.PlanID = pl.PlanID WHERE s.EndDate Between Date()-30 And Date()+21 AND s.EndDate = (SELECT Max(x.EndDate) FROM Subscriptions AS x WHERE x.MemberID = m.MemberID) ORDER BY s.EndDate;

-- qryMonthlyRevenue  [Select]  Subscription sales per month
SELECT Format(s.StartDate,'yyyy-mm') AS SaleMonth, Count(s.SubscriptionID) AS SubscriptionsSold, Sum(s.AmountPaid) AS Revenue, Sum(IIf(pl.DurationMonths>=6, s.AmountPaid, 0)) AS LongTermRevenue FROM Subscriptions AS s INNER JOIN Plans AS pl ON s.PlanID = pl.PlanID GROUP BY Format(s.StartDate,'yyyy-mm') ORDER BY Format(s.StartDate,'yyyy-mm');

-- qryPlanPopularity  [Select]  Plan mix
SELECT pl.PlanName, pl.MonthlyFee, Count(s.SubscriptionID) AS TimesSold, Sum(s.AmountPaid) AS Revenue FROM Plans AS pl LEFT JOIN Subscriptions AS s ON pl.PlanID = s.PlanID GROUP BY pl.PlanName, pl.MonthlyFee ORDER BY Count(s.SubscriptionID) DESC;

-- qryClassAttendance  [Select]  Bookings vs attendance per class type
SELECT gc.ClassTitle, t.TrainerName, Count(gc.ClassID) AS Bookings, Sum(IIf(b.Attended,1,0)) AS Attended, Sum(IIf(b.Attended,1,0))/Count(gc.ClassID) AS ShowRate FROM (GroupClasses AS gc INNER JOIN Trainers AS t ON gc.TrainerID = t.TrainerID) INNER JOIN ClassBookings AS b ON gc.ClassID = b.ClassID WHERE gc.ClassDateTime < Date() GROUP BY gc.ClassTitle, t.TrainerName ORDER BY Count(gc.ClassID) DESC;

-- qryUpcomingClasses  [Select]  Class schedule with free spots
SELECT gc.ClassDateTime, gc.ClassTitle, t.TrainerName, gc.Studio, gc.Capacity, Count(b.BookingID) AS Booked, gc.Capacity - Count(b.BookingID) AS SpotsLeft FROM (GroupClasses AS gc INNER JOIN Trainers AS t ON gc.TrainerID = t.TrainerID) LEFT JOIN ClassBookings AS b ON gc.ClassID = b.ClassID WHERE gc.ClassDateTime >= Date() GROUP BY gc.ClassDateTime, gc.ClassTitle, t.TrainerName, gc.Studio, gc.Capacity ORDER BY gc.ClassDateTime;

-- qryVisitFrequency  [Select]  Engagement and churn risk from check-ins
SELECT m.MemberNo, m.FullName, Count(c.CheckInID) AS Visits60Days, Round(Avg(DateDiff('n', c.CheckInTime, c.CheckOutTime)),0) AS AvgMinutes, Max(c.CheckInTime) AS LastVisit, IIf(Count(c.CheckInID) < 4, 'At risk of churn', IIf(Count(c.CheckInID) >= 20, 'Super member', 'Regular')) AS Engagement FROM Members AS m INNER JOIN CheckIns AS c ON m.MemberID = c.MemberID GROUP BY m.MemberNo, m.FullName ORDER BY Count(c.CheckInID);

-- qryPeakHours  [Select]  Busiest hours
SELECT Hour(c.CheckInTime) AS HourOfDay, Count(c.CheckInID) AS CheckIns FROM CheckIns AS c GROUP BY Hour(c.CheckInTime) ORDER BY Hour(c.CheckInTime);

-- qryXT_CheckInsWeekday  [Crosstab]  Crosstab: check-ins by hour and weekday
TRANSFORM Count(c.CheckInID) AS Visits SELECT Hour(c.CheckInTime) AS HourOfDay FROM CheckIns AS c GROUP BY Hour(c.CheckInTime) PIVOT Format(c.CheckInTime,'ddd');

-- qryMemberCard  [Parameter]  Parameter: subscription history of a member
PARAMETERS [Member number] Text ( 255 ); SELECT m.FullName, pl.PlanName, s.StartDate, s.EndDate, s.AmountPaid FROM (Members AS m INNER JOIN Subscriptions AS s ON m.MemberID = s.MemberID) INNER JOIN Plans AS pl ON s.PlanID = pl.PlanID WHERE m.MemberNo = [Member number] ORDER BY s.StartDate;

-- qryAction_RemovePastNoShows  [Action]  Action: purge no-show bookings older than 90 days
DELETE FROM ClassBookings WHERE Attended = False AND ClassID IN (SELECT ClassID FROM GroupClasses WHERE ClassDateTime < Date()-90);
