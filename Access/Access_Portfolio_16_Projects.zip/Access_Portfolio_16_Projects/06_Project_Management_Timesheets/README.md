# Project Management & Timesheets

**سیستم مدیریت پروژه و تایم‌شیت** — پروژه‌ها، وظایف با اولویت و وضعیت، اعضای تیم، ثبت ساعت کار، ریسک‌ها، بودجه در برابر هزینه واقعی.

> Projects, tasks, team members, timesheets, risks, budget vs. actual cost and overdue task tracking.

## نحوه راه‌اندازی

1. فایل `06_Project_Management_Timesheets.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Clients | 5 | Project clients |
| TeamMembers | 8 | People who log time |
| Projects | 6 | Projects |
| Tasks | 37 | Work breakdown |
| TimeLogs | 133 | Timesheet entries |
| ProjectRisks | 18 | Risk register |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Clients ||--o{ Projects : "ClientID"
    TeamMembers ||--o{ Projects : "ManagerID"
    Projects ||--o{ Tasks : "ProjectID"
    TeamMembers ||--o{ Tasks : "AssignedTo"
    Tasks ||--o{ TimeLogs : "TaskID"
    TeamMembers ||--o{ TimeLogs : "MemberID"
    Projects ||--o{ ProjectRisks : "ProjectID"
    Clients {
        pk ClientID PK
        text ClientName
        text Country
        text ContactEmail
    }
    TeamMembers {
        pk MemberID PK
        text FullName
        text JobRole
        cur HourlyRate
        text Email
    }
    Projects {
        pk ProjectID PK
        text ProjectCode
        text ProjectName
        long ClientID FK
        long ManagerID FK
        date StartDate
        date TargetEndDate
        cur Budget
        text ProjectStatus
    }
    Tasks {
        pk TaskID PK
        long ProjectID FK
        text TaskName
        long AssignedTo FK
        text Priority
        date StartDate
        date DueDate
        dbl EstimatedHours
        dbl PercentComplete
        text TaskStatus
    }
    TimeLogs {
        pk TimeLogID PK
        long TaskID FK
        long MemberID FK
        date LogDate
        dbl HoursSpent
        text WorkNote
        bool Billable
    }
    ProjectRisks {
        pk RiskID PK
        long ProjectID FK
        text RiskTitle
        int Likelihood
        int Impact
        text Mitigation
        bool IsOpen
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryProjectDashboard | Select | Budget vs actual cost per project |
| qryProjectProgress | Select | Weighted % complete and days left |
| qryOverdueTasks | Select | Tasks past due and not done |
| qryTimesheetDetail | Select | Timesheet detail with cost |
| qryUtilizationByMember | Select | Billable utilization per person |
| qryRiskRegister | Select | Risks scored by likelihood x impact |
| qryXT_HoursByMemberProject | Crosstab | Crosstab: hours per member per project |
| qryTasksForMember | Parameter | Parameter: my tasks |
| qryAction_SyncTaskStatus | Action | Action: recalculate task status from % complete |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmClients | Clients | Continuous |
| frmTeamMembers | TeamMembers | Continuous |
| sfrmTasks | Tasks | Continuous |
| frmProjects | Projects | Single + subform `sfrmTasks` |
| frmTimeLogs | TimeLogs | Continuous |
| frmProjectRisks | ProjectRisks | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptProjectDashboard | qryProjectDashboard | - | Budget,HoursLogged,ActualCost,BudgetRemaining |
| rptOverdueTasks | qryOverdueTasks | ProjectCode | - |
| rptTimesheet | qryTimesheetDetail | FullName | HoursSpent,Cost |
| rptRiskRegister | qryRiskRegister | RiskLevel | - |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
