-- Project Management & Timesheets
-- Projects, tasks, team members, timesheets, risks, budget vs. actual cost and overdue task tracking.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Clients (
    ClientID COUNTER PRIMARY KEY,
    ClientName TEXT(100) NOT NULL,
    Country TEXT(50),
    ContactEmail TEXT(100)
);

CREATE TABLE TeamMembers (
    MemberID COUNTER PRIMARY KEY,
    FullName TEXT(60) NOT NULL,
    JobRole TEXT(40),
    HourlyRate CURRENCY,
    Email TEXT(100)
);

CREATE TABLE Projects (
    ProjectID COUNTER PRIMARY KEY,
    ProjectCode TEXT(10) NOT NULL UNIQUE,
    ProjectName TEXT(100) NOT NULL,
    ClientID LONG,
    ManagerID LONG,
    StartDate DATETIME,
    TargetEndDate DATETIME,
    Budget CURRENCY,
    ProjectStatus TEXT(20)
);

CREATE TABLE Tasks (
    TaskID COUNTER PRIMARY KEY,
    ProjectID LONG NOT NULL,
    TaskName TEXT(150) NOT NULL,
    AssignedTo LONG,
    Priority TEXT(10),
    StartDate DATETIME,
    DueDate DATETIME,
    EstimatedHours DOUBLE,
    PercentComplete DOUBLE,
    TaskStatus TEXT(20)
);

CREATE TABLE TimeLogs (
    TimeLogID COUNTER PRIMARY KEY,
    TaskID LONG NOT NULL,
    MemberID LONG NOT NULL,
    LogDate DATETIME,
    HoursSpent DOUBLE,
    WorkNote TEXT(255),
    Billable YESNO
);

CREATE TABLE ProjectRisks (
    RiskID COUNTER PRIMARY KEY,
    ProjectID LONG NOT NULL,
    RiskTitle TEXT(150),
    Likelihood INTEGER,
    Impact INTEGER,
    Mitigation TEXT(255),
    IsOpen YESNO
);

ALTER TABLE Projects ADD CONSTRAINT FK_Projects_ClientID FOREIGN KEY (ClientID) REFERENCES Clients (ClientID);
ALTER TABLE Projects ADD CONSTRAINT FK_Projects_ManagerID FOREIGN KEY (ManagerID) REFERENCES TeamMembers (MemberID);
ALTER TABLE Tasks ADD CONSTRAINT FK_Tasks_ProjectID FOREIGN KEY (ProjectID) REFERENCES Projects (ProjectID) ON DELETE CASCADE;
ALTER TABLE Tasks ADD CONSTRAINT FK_Tasks_AssignedTo FOREIGN KEY (AssignedTo) REFERENCES TeamMembers (MemberID);
ALTER TABLE TimeLogs ADD CONSTRAINT FK_TimeLogs_TaskID FOREIGN KEY (TaskID) REFERENCES Tasks (TaskID) ON DELETE CASCADE;
ALTER TABLE TimeLogs ADD CONSTRAINT FK_TimeLogs_MemberID FOREIGN KEY (MemberID) REFERENCES TeamMembers (MemberID);
ALTER TABLE ProjectRisks ADD CONSTRAINT FK_ProjectRisks_ProjectID FOREIGN KEY (ProjectID) REFERENCES Projects (ProjectID) ON DELETE CASCADE;

-- ===== Saved queries =====

-- qryProjectDashboard  [Select]  Budget vs actual cost per project
SELECT pj.ProjectCode, pj.ProjectName, cl.ClientName, pj.ProjectStatus, pj.Budget, Sum(tl.HoursSpent) AS HoursLogged, Sum(tl.HoursSpent*tm.HourlyRate) AS ActualCost, pj.Budget - Sum(tl.HoursSpent*tm.HourlyRate) AS BudgetRemaining, Sum(tl.HoursSpent*tm.HourlyRate)/pj.Budget AS BudgetUsedPct FROM (((Projects AS pj INNER JOIN Clients AS cl ON pj.ClientID = cl.ClientID) INNER JOIN Tasks AS t ON pj.ProjectID = t.ProjectID) INNER JOIN TimeLogs AS tl ON t.TaskID = tl.TaskID) INNER JOIN TeamMembers AS tm ON tl.MemberID = tm.MemberID GROUP BY pj.ProjectCode, pj.ProjectName, cl.ClientName, pj.ProjectStatus, pj.Budget ORDER BY pj.ProjectCode;

-- qryProjectProgress  [Select]  Weighted % complete and days left
SELECT pj.ProjectCode, pj.ProjectName, Count(t.TaskID) AS TotalTasks, Sum(IIf(t.TaskStatus='Done',1,0)) AS DoneTasks, Sum(t.EstimatedHours*t.PercentComplete)/Sum(t.EstimatedHours) AS WeightedProgress, pj.TargetEndDate, DateDiff('d', Date(), pj.TargetEndDate) AS DaysLeft FROM Projects AS pj INNER JOIN Tasks AS t ON pj.ProjectID = t.ProjectID GROUP BY pj.ProjectCode, pj.ProjectName, pj.TargetEndDate ORDER BY pj.ProjectCode;

-- qryOverdueTasks  [Select]  Tasks past due and not done
SELECT pj.ProjectCode, t.TaskName, tm.FullName AS Owner, t.Priority, t.DueDate, t.PercentComplete, DateDiff('d', t.DueDate, Date()) AS DaysOverdue FROM (Tasks AS t INNER JOIN Projects AS pj ON t.ProjectID = pj.ProjectID) INNER JOIN TeamMembers AS tm ON t.AssignedTo = tm.MemberID WHERE t.DueDate < Date() AND t.TaskStatus <> 'Done' ORDER BY t.DueDate;

-- qryTimesheetDetail  [Select]  Timesheet detail with cost
SELECT tl.LogDate, tm.FullName, pj.ProjectCode, t.TaskName, tl.HoursSpent, tl.Billable, tl.HoursSpent*tm.HourlyRate AS Cost, tl.WorkNote FROM ((TimeLogs AS tl INNER JOIN TeamMembers AS tm ON tl.MemberID = tm.MemberID) INNER JOIN Tasks AS t ON tl.TaskID = t.TaskID) INNER JOIN Projects AS pj ON t.ProjectID = pj.ProjectID ORDER BY tl.LogDate DESC;

-- qryUtilizationByMember  [Select]  Billable utilization per person
SELECT tm.FullName, tm.JobRole, Sum(tl.HoursSpent) AS TotalHours, Sum(IIf(tl.Billable, tl.HoursSpent, 0)) AS BillableHours, Sum(IIf(tl.Billable, tl.HoursSpent, 0))/Sum(tl.HoursSpent) AS BillablePct, Sum(IIf(tl.Billable, tl.HoursSpent*tm.HourlyRate, 0)) AS BillableAmount FROM TeamMembers AS tm INNER JOIN TimeLogs AS tl ON tm.MemberID = tl.MemberID GROUP BY tm.FullName, tm.JobRole ORDER BY Sum(tl.HoursSpent) DESC;

-- qryRiskRegister  [Select]  Risks scored by likelihood x impact
SELECT pj.ProjectCode, r.RiskTitle, r.Likelihood, r.Impact, r.Likelihood*r.Impact AS RiskScore, IIf((r.Likelihood*r.Impact)>=15,'High',IIf((r.Likelihood*r.Impact)>=8,'Medium','Low')) AS RiskLevel, r.Mitigation, r.IsOpen FROM ProjectRisks AS r INNER JOIN Projects AS pj ON r.ProjectID = pj.ProjectID ORDER BY r.Likelihood*r.Impact DESC;

-- qryXT_HoursByMemberProject  [Crosstab]  Crosstab: hours per member per project
TRANSFORM Sum(tl.HoursSpent) AS Hours SELECT tm.FullName FROM ((TimeLogs AS tl INNER JOIN TeamMembers AS tm ON tl.MemberID = tm.MemberID) INNER JOIN Tasks AS t ON tl.TaskID = t.TaskID) INNER JOIN Projects AS pj ON t.ProjectID = pj.ProjectID GROUP BY tm.FullName PIVOT pj.ProjectCode;

-- qryTasksForMember  [Parameter]  Parameter: my tasks
PARAMETERS [Team member name] Text ( 255 ); SELECT pj.ProjectCode, t.TaskName, t.Priority, t.DueDate, t.TaskStatus FROM (Tasks AS t INNER JOIN Projects AS pj ON t.ProjectID = pj.ProjectID) INNER JOIN TeamMembers AS tm ON t.AssignedTo = tm.MemberID WHERE tm.FullName = [Team member name] ORDER BY t.DueDate;

-- qryAction_SyncTaskStatus  [Action]  Action: recalculate task status from % complete
UPDATE Tasks SET TaskStatus = IIf(PercentComplete >= 1, 'Done', IIf(PercentComplete > 0, 'In Progress', 'Not Started'));
