-- Restaurant POS & Kitchen Management
-- Menu, tables, orders and items, staff and tips, ingredients and recipes, best sellers and hourly sales.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE MenuCategories (
    CategoryID COUNTER PRIMARY KEY,
    CategoryName TEXT(40) NOT NULL UNIQUE
);

CREATE TABLE MenuItems (
    MenuItemID COUNTER PRIMARY KEY,
    ItemName TEXT(80) NOT NULL,
    CategoryID LONG,
    Price CURRENCY,
    IsVegetarian YESNO,
    IsAvailable YESNO
);

CREATE TABLE Ingredients (
    IngredientID COUNTER PRIMARY KEY,
    IngredientName TEXT(60) NOT NULL,
    UnitOfMeasure TEXT(10),
    CostPerUnit CURRENCY,
    StockQty DOUBLE,
    ReorderLevel DOUBLE
);

CREATE TABLE Recipes (
    RecipeID COUNTER PRIMARY KEY,
    MenuItemID LONG NOT NULL,
    IngredientID LONG NOT NULL,
    QtyPerServing DOUBLE
);

CREATE TABLE Staff (
    StaffID COUNTER PRIMARY KEY,
    StaffName TEXT(60) NOT NULL,
    StaffRole TEXT(20),
    HourlyWage CURRENCY
);

CREATE TABLE DiningTables (
    TableID COUNTER PRIMARY KEY,
    TableLabel TEXT(10) NOT NULL UNIQUE,
    Seats INTEGER,
    Zone TEXT(20)
);

CREATE TABLE Orders (
    OrderID COUNTER PRIMARY KEY,
    OrderNo TEXT(12) NOT NULL UNIQUE,
    TableID LONG,
    StaffID LONG,
    OrderTime DATETIME,
    OrderType TEXT(15),
    Tip CURRENCY,
    PaymentMethod TEXT(15),
    IsPaid YESNO
);

CREATE TABLE OrderItems (
    OrderItemID COUNTER PRIMARY KEY,
    OrderID LONG NOT NULL,
    MenuItemID LONG NOT NULL,
    Quantity INTEGER,
    UnitPrice CURRENCY,
    KitchenNote TEXT(100)
);

ALTER TABLE MenuItems ADD CONSTRAINT FK_MenuItems_CategoryID FOREIGN KEY (CategoryID) REFERENCES MenuCategories (CategoryID);
ALTER TABLE Recipes ADD CONSTRAINT FK_Recipes_MenuItemID FOREIGN KEY (MenuItemID) REFERENCES MenuItems (MenuItemID) ON DELETE CASCADE;
ALTER TABLE Recipes ADD CONSTRAINT FK_Recipes_IngredientID FOREIGN KEY (IngredientID) REFERENCES Ingredients (IngredientID);
ALTER TABLE Orders ADD CONSTRAINT FK_Orders_TableID FOREIGN KEY (TableID) REFERENCES DiningTables (TableID);
ALTER TABLE Orders ADD CONSTRAINT FK_Orders_StaffID FOREIGN KEY (StaffID) REFERENCES Staff (StaffID);
ALTER TABLE OrderItems ADD CONSTRAINT FK_OrderItems_OrderID FOREIGN KEY (OrderID) REFERENCES Orders (OrderID) ON DELETE CASCADE;
ALTER TABLE OrderItems ADD CONSTRAINT FK_OrderItems_MenuItemID FOREIGN KEY (MenuItemID) REFERENCES MenuItems (MenuItemID);

-- ===== Saved queries =====

-- qryOrderTotals  [Select]  Check totals with 9% service tax and tip
SELECT o.OrderNo, o.OrderTime, o.OrderType, Nz(t.TableLabel,'-') AS TableNo, s.StaffName, Sum(oi.Quantity*oi.UnitPrice) AS Subtotal, Round(Sum(oi.Quantity*oi.UnitPrice)*0.09,2) AS ServiceTax, o.Tip, Round(Sum(oi.Quantity*oi.UnitPrice)*1.09,2) + o.Tip AS GrandTotal, o.PaymentMethod, o.IsPaid FROM ((Orders AS o LEFT JOIN DiningTables AS t ON o.TableID = t.TableID) INNER JOIN Staff AS s ON o.StaffID = s.StaffID) INNER JOIN OrderItems AS oi ON o.OrderID = oi.OrderID GROUP BY o.OrderNo, o.OrderTime, o.OrderType, t.TableLabel, s.StaffName, o.Tip, o.PaymentMethod, o.IsPaid ORDER BY o.OrderTime DESC;

-- qryDailySales  [Select]  Sales per day
SELECT DateValue(o.OrderTime) AS SalesDay, Count(oi.OrderItemID) AS ItemsSold, Sum(oi.Quantity*oi.UnitPrice) AS NetSales, Sum(IIf(o.OrderType='Delivery', oi.Quantity*oi.UnitPrice, 0)) AS DeliverySales FROM Orders AS o INNER JOIN OrderItems AS oi ON o.OrderID = oi.OrderID GROUP BY DateValue(o.OrderTime) ORDER BY DateValue(o.OrderTime) DESC;

-- qryBestSellers  [Select]  Top 10 dishes
SELECT TOP 10 m.ItemName, c.CategoryName, Sum(oi.Quantity) AS UnitsSold, Sum(oi.Quantity*oi.UnitPrice) AS Revenue FROM (MenuItems AS m INNER JOIN MenuCategories AS c ON m.CategoryID = c.CategoryID) INNER JOIN OrderItems AS oi ON m.MenuItemID = oi.MenuItemID GROUP BY m.ItemName, c.CategoryName ORDER BY Sum(oi.Quantity) DESC;

-- qryMenuProfitability  [Select]  Recipe cost vs price (menu engineering)
SELECT m.ItemName, m.Price, Round(Sum(r.QtyPerServing*i.CostPerUnit),2) AS FoodCost, m.Price - Round(Sum(r.QtyPerServing*i.CostPerUnit),2) AS GrossMargin, Round(Sum(r.QtyPerServing*i.CostPerUnit),2)/m.Price AS FoodCostPct FROM (MenuItems AS m INNER JOIN Recipes AS r ON m.MenuItemID = r.MenuItemID) INNER JOIN Ingredients AS i ON r.IngredientID = i.IngredientID GROUP BY m.ItemName, m.Price ORDER BY m.Price - Round(Sum(r.QtyPerServing*i.CostPerUnit),2) DESC;

-- qrySalesByHour  [Select]  Peak hours analysis
SELECT Hour(o.OrderTime) AS HourOfDay, Count(o.OrderID) AS OrderLines, Sum(oi.Quantity*oi.UnitPrice) AS Revenue FROM Orders AS o INNER JOIN OrderItems AS oi ON o.OrderID = oi.OrderID GROUP BY Hour(o.OrderTime) ORDER BY Hour(o.OrderTime);

-- qryStaffPerformance  [Select]  Checks and tips per staff member
SELECT s.StaffName, s.StaffRole, Count(o.OrderID) AS Checks, Sum(o.Tip) AS TotalTips, Avg(o.Tip) AS AvgTip FROM Staff AS s INNER JOIN Orders AS o ON s.StaffID = o.StaffID GROUP BY s.StaffName, s.StaffRole ORDER BY Sum(o.Tip) DESC;

-- qryIngredientUsage  [Select]  Ingredient consumption from sales (recipe explosion)
SELECT i.IngredientName, i.UnitOfMeasure, i.StockQty, Sum(oi.Quantity*r.QtyPerServing) AS UsedQty, i.StockQty - Sum(oi.Quantity*r.QtyPerServing) AS ProjectedBalance, IIf((i.StockQty - Sum(oi.Quantity*r.QtyPerServing)) <= i.ReorderLevel, 'ORDER', 'OK') AS PurchaseAlert FROM (Ingredients AS i INNER JOIN Recipes AS r ON i.IngredientID = r.IngredientID) INNER JOIN OrderItems AS oi ON r.MenuItemID = oi.MenuItemID GROUP BY i.IngredientName, i.UnitOfMeasure, i.StockQty, i.ReorderLevel ORDER BY i.IngredientName;

-- qryXT_CategoryByOrderType  [Crosstab]  Crosstab: category revenue by dine-in / takeaway / delivery
TRANSFORM Sum(oi.Quantity*oi.UnitPrice) AS Revenue SELECT c.CategoryName FROM ((OrderItems AS oi INNER JOIN MenuItems AS m ON oi.MenuItemID = m.MenuItemID) INNER JOIN MenuCategories AS c ON m.CategoryID = c.CategoryID) INNER JOIN Orders AS o ON oi.OrderID = o.OrderID GROUP BY c.CategoryName PIVOT o.OrderType;

-- qrySalesBetweenDates  [Parameter]  Parameter: orders in a date range
PARAMETERS [From date] DateTime, [To date] DateTime; SELECT o.OrderNo, o.OrderTime, o.OrderType, o.PaymentMethod FROM Orders AS o WHERE o.OrderTime Between [From date] And [To date] ORDER BY o.OrderTime;

-- qryAction_HideNonSellers  [Action]  Action: hide menu items that never sold
UPDATE MenuItems SET IsAvailable = False WHERE MenuItemID NOT IN (SELECT MenuItemID FROM OrderItems);
