# Restaurant POS & Kitchen Management

**سیستم فروش رستوران (POS) و آشپزخانه** — منو و دسته‌بندی، میزها، سفارش‌ها با آیتم‌ها، پرسنل، انعام، مواد اولیه و دستور پخت، پرفروش‌ترین غذاها.

> Menu, tables, orders and items, staff and tips, ingredients and recipes, best sellers and hourly sales.

## نحوه راه‌اندازی

1. فایل `12_Restaurant_POS.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| MenuCategories | 6 | Menu sections |
| MenuItems | 18 | Dishes and drinks |
| Ingredients | 14 | Kitchen inventory |
| Recipes | 29 | Bill of materials per dish |
| Staff | 6 | Waiters, chefs, cashiers |
| DiningTables | 16 | Tables |
| Orders | 220 | Customer orders / checks |
| OrderItems | 660 | Items on an order |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    MenuCategories ||--o{ MenuItems : "CategoryID"
    MenuItems ||--o{ Recipes : "MenuItemID"
    Ingredients ||--o{ Recipes : "IngredientID"
    DiningTables ||--o{ Orders : "TableID"
    Staff ||--o{ Orders : "StaffID"
    Orders ||--o{ OrderItems : "OrderID"
    MenuItems ||--o{ OrderItems : "MenuItemID"
    MenuCategories {
        pk CategoryID PK
        text CategoryName
    }
    MenuItems {
        pk MenuItemID PK
        text ItemName
        long CategoryID FK
        cur Price
        bool IsVegetarian
        bool IsAvailable
    }
    Ingredients {
        pk IngredientID PK
        text IngredientName
        text UnitOfMeasure
        cur CostPerUnit
        dbl StockQty
        dbl ReorderLevel
    }
    Recipes {
        pk RecipeID PK
        long MenuItemID FK
        long IngredientID FK
        dbl QtyPerServing
    }
    Staff {
        pk StaffID PK
        text StaffName
        text StaffRole
        cur HourlyWage
    }
    DiningTables {
        pk TableID PK
        text TableLabel
        int Seats
        text Zone
    }
    Orders {
        pk OrderID PK
        text OrderNo
        long TableID FK
        long StaffID FK
        date OrderTime
        text OrderType
        cur Tip
        text PaymentMethod
        bool IsPaid
    }
    OrderItems {
        pk OrderItemID PK
        long OrderID FK
        long MenuItemID FK
        int Quantity
        cur UnitPrice
        text KitchenNote
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryOrderTotals | Select | Check totals with 9% service tax and tip |
| qryDailySales | Select | Sales per day |
| qryBestSellers | Select | Top 10 dishes |
| qryMenuProfitability | Select | Recipe cost vs price (menu engineering) |
| qrySalesByHour | Select | Peak hours analysis |
| qryStaffPerformance | Select | Checks and tips per staff member |
| qryIngredientUsage | Select | Ingredient consumption from sales (recipe explosion) |
| qryXT_CategoryByOrderType | Crosstab | Crosstab: category revenue by dine-in / takeaway / delivery |
| qrySalesBetweenDates | Parameter | Parameter: orders in a date range |
| qryAction_HideNonSellers | Action | Action: hide menu items that never sold |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmMenuItems | MenuItems | Continuous |
| frmMenuCategories | MenuCategories | Continuous |
| sfrmOrderItems | OrderItems | Continuous |
| frmOrders | Orders | Single + subform `sfrmOrderItems` |
| frmIngredients | Ingredients | Continuous |
| frmRecipes | Recipes | Continuous |
| frmStaff | Staff | Continuous |
| frmDiningTables | DiningTables | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptOrderTotals | qryOrderTotals | OrderType | Subtotal,ServiceTax,Tip,GrandTotal |
| rptBestSellers | qryBestSellers | - | UnitsSold,Revenue |
| rptMenuProfitability | qryMenuProfitability | - | - |
| rptStaffPerformance | qryStaffPerformance | - | Checks,TotalTips |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
