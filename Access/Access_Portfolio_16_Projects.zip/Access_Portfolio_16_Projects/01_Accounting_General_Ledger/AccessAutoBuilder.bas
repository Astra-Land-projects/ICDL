Attribute VB_Name = "AccessAutoBuilder"
Option Compare Database
Option Explicit

' =====================================================================
'  Access Auto Builder  -  v1.0
'  ---------------------------------------------------------------
'  Import this module into any of the portfolio databases, then run
'  BuildApplication (cursor inside the Sub, press F5).
'
'  It reads the hidden USys* metadata tables and creates:
'    * Saved queries  (Select, Aggregate, Crosstab, Parameter, Action)
'    * Data-entry forms (combo-box lookups for foreign keys, subforms)
'    * Formatted reports (grouping, group/grand totals, page numbers)
'    * A main menu (switchboard) that opens automatically on startup
'
'  Safe to run again at any time: objects are deleted and rebuilt.
' =====================================================================

Private Const TW As Long = 1440          ' twips per inch
Private mLog As String                   ' build problems (if any)

' ---------------------------------------------------------------------
Public Sub BuildApplication()
    Dim t As Single
    t = Timer
    mLog = ""
    DoCmd.SetWarnings False
    DoCmd.Hourglass True

    BuildQueries
    BuildForms
    BuildReports
    BuildMainMenu
    SetStartup

    DoCmd.Hourglass False
    DoCmd.SetWarnings True
    If mLog = "" Then
        MsgBox "Application built successfully in " & Format(Timer - t, "0.0") & " seconds." & vbCrLf & vbCrLf & _
               "The Main Menu will now open, and it will also open automatically next time.", vbInformation, AppTitle()
    Else
        MsgBox "Build finished with some warnings:" & vbCrLf & vbCrLf & mLog, vbExclamation, AppTitle()
    End If
    DoCmd.OpenForm "frmMainMenu"
End Sub

' Opens forms, reports and queries from menu buttons
Public Function OpenItem(ByVal objName As String, ByVal kind As String) As Boolean
    On Error GoTo EH
    Select Case kind
        Case "F": DoCmd.OpenForm objName
        Case "R": DoCmd.OpenReport objName, acViewReport
        Case "Q": DoCmd.OpenQuery objName, acViewNormal, acReadOnly
    End Select
    OpenItem = True
    Exit Function
EH:
    If Err.Number <> 2501 Then MsgBox Err.Description, vbExclamation, AppTitle()
End Function

' ---------------------------------------------------------------------
'  QUERIES
' ---------------------------------------------------------------------
Private Sub BuildQueries()
    Dim db As DAO.Database, rs As DAO.Recordset, nm As String
    Set db = CurrentDb
    Set rs = db.OpenRecordset("SELECT QueryName, SQLText FROM USysQueries ORDER BY SortOrder", dbOpenSnapshot)
    Do While Not rs.EOF
        nm = rs!QueryName
        On Error Resume Next
        db.QueryDefs.Delete nm
        Err.Clear
        db.CreateQueryDef nm, rs!SQLText
        If Err.Number <> 0 Then mLog = mLog & "Query " & nm & ": " & Err.Description & vbCrLf
        Err.Clear
        On Error GoTo 0
        rs.MoveNext
    Loop
    rs.Close
    db.QueryDefs.Refresh
End Sub

' ---------------------------------------------------------------------
'  FORMS
' ---------------------------------------------------------------------
Private Sub BuildForms()
    Dim rs As DAO.Recordset
    Set rs = CurrentDb.OpenRecordset("SELECT * FROM USysForms ORDER BY SortOrder", dbOpenSnapshot)
    Do While Not rs.EOF
        CreateDataForm rs!FormName, rs!RecordSource, rs!Caption, Nz(rs!ViewType, "Single"), _
                       Nz(rs!SubformName, ""), Nz(rs!LinkField, "")
        rs.MoveNext
    Loop
    rs.Close
End Sub

Private Sub CreateDataForm(ByVal formName As String, ByVal src As String, ByVal cap As String, _
                           ByVal viewType As String, ByVal subName As String, ByVal linkField As String)
    Dim frm As Form, ctl As Control, lbl As Control
    Dim rs As DAO.Recordset, fld As DAO.Field
    Dim tmpName As String, x As Long, y As Long, w As Long, h As Long
    Dim rowSrc As String, ctype As Integer, isTab As Boolean

    On Error GoTo EH
    DeleteIfExists acForm, formName
    isTab = (viewType = "Continuous" Or viewType = "Datasheet")

    Set frm = CreateForm()
    tmpName = frm.Name
    frm.RecordSource = src
    frm.Caption = cap
    Select Case viewType
        Case "Continuous": frm.DefaultView = 1
        Case "Datasheet": frm.DefaultView = 2
        Case Else: frm.DefaultView = 0
    End Select
    frm.NavigationButtons = True
    frm.RecordSelectors = isTab
    frm.AutoCenter = True
    frm.AllowDatasheetView = True

    If Not HasSection(frm, acHeader) Then DoCmd.RunCommand acCmdFormHdrFtr
    frm.Section(acHeader).BackColor = RGB(31, 56, 100)
    frm.Section(acHeader).Height = IIf(isTab, 1# * TW, 0.75 * TW)
    frm.Section(acDetail).BackColor = RGB(255, 255, 255)
    If HasSection(frm, acFooter) Then frm.Section(acFooter).Height = 0

    Set lbl = CreateControl(tmpName, acLabel, acHeader, , , 0.2 * TW, 0.12 * TW, 6 * TW, 0.45 * TW)
    lbl.Caption = cap
    StyleTitle lbl

    Set rs = CurrentDb.OpenRecordset("SELECT * FROM [" & src & "] WHERE 1=0", dbOpenSnapshot)
    x = 0.2 * TW
    y = 0.2 * TW
    For Each fld In rs.Fields
        rowSrc = LookupRowSource(fld.Name, src)
        w = FieldWidth(fld, isTab)
        If fld.Type = dbBoolean Then
            ctype = acCheckBox
        ElseIf rowSrc <> "" Then
            ctype = acComboBox
            w = IIf(isTab, 1.8 * TW, 2.6 * TW)
        Else
            ctype = acTextBox
        End If
        h = IIf(fld.Type = dbMemo And Not isTab, 0.9 * TW, 0.3 * TW)

        If isTab Then
            Set lbl = CreateControl(tmpName, acLabel, acHeader, , , x, 0.66 * TW, w, 0.3 * TW)
            lbl.Caption = PrettyName(fld.Name)
            StyleHeaderLabel lbl
            If ctype = acCheckBox Then
                Set ctl = CreateControl(tmpName, ctype, acDetail, , fld.Name, x + w / 2 - 100, 0.08 * TW)
            Else
                Set ctl = CreateControl(tmpName, ctype, acDetail, , fld.Name, x, 0.04 * TW, w, h)
            End If
            x = x + w + 0.06 * TW
        Else
            If ctype = acCheckBox Then
                Set ctl = CreateControl(tmpName, ctype, acDetail, , fld.Name, 2.3 * TW, y + 0.05 * TW)
            Else
                Set ctl = CreateControl(tmpName, ctype, acDetail, , fld.Name, 2.3 * TW, y, w, h)
            End If
            Set lbl = CreateControl(tmpName, acLabel, acDetail, ctl.Name, , 0.2 * TW, y, 2 * TW, 0.3 * TW)
            lbl.Caption = PrettyName(fld.Name) & ":"
            lbl.FontName = "Segoe UI": lbl.FontSize = 9: lbl.FontBold = True
            lbl.ForeColor = RGB(64, 64, 64)
            y = y + h + 0.1 * TW
        End If

        If ctype <> acCheckBox Then
            ctl.FontName = "Segoe UI"
            ctl.FontSize = 9
            ctl.BorderColor = RGB(191, 191, 191)
        End If
        If ctype = acComboBox Then
            ctl.RowSourceType = "Table/Query"
            ctl.RowSource = rowSrc
            ctl.ColumnCount = 2
            ctl.BoundColumn = 1
            ctl.ColumnWidths = "0;" & CStr(w)
            ctl.ListWidth = w
            ctl.LimitToList = True
        End If
        If (fld.Attributes And dbAutoIncrField) <> 0 Then
            ctl.Locked = True
            ctl.TabStop = False
            ctl.BackColor = RGB(242, 242, 242)
        End If
    Next fld
    rs.Close
    If isTab Then frm.Section(acDetail).Height = 0.4 * TW

    ' Optional master/detail subform
    If subName <> "" And Not isTab Then
        Set lbl = CreateControl(tmpName, acLabel, acDetail, , , 0.2 * TW, y + 0.1 * TW, 5 * TW, 0.3 * TW)
        lbl.Caption = "Details"
        lbl.FontName = "Segoe UI": lbl.FontSize = 11: lbl.FontBold = True
        lbl.ForeColor = RGB(31, 56, 100)
        Set ctl = CreateControl(tmpName, acSubform, acDetail, , , 0.2 * TW, y + 0.45 * TW, 9.5 * TW, 3 * TW)
        ctl.SourceObject = "Form." & subName
        ctl.LinkMasterFields = linkField
        ctl.LinkChildFields = linkField
    End If

    DoCmd.Close acForm, tmpName, acSaveYes
    DoCmd.Rename formName, acForm, tmpName
    Exit Sub
EH:
    mLog = mLog & "Form " & formName & ": " & Err.Description & vbCrLf
    On Error Resume Next
    If tmpName <> "" Then DoCmd.Close acForm, tmpName, acSaveNo
End Sub

' ---------------------------------------------------------------------
'  REPORTS
' ---------------------------------------------------------------------
Private Sub BuildReports()
    Dim rs As DAO.Recordset
    Set rs = CurrentDb.OpenRecordset("SELECT * FROM USysReports ORDER BY SortOrder", dbOpenSnapshot)
    Do While Not rs.EOF
        CreateListReport rs!ReportName, rs!RecordSource, rs!Caption, Nz(rs!GroupField, ""), Nz(rs!SumFields, "")
        rs.MoveNext
    Loop
    rs.Close
End Sub

Private Sub CreateListReport(ByVal rptName As String, ByVal src As String, ByVal cap As String, _
                             ByVal grp As String, ByVal sums As String)
    Dim rpt As Report, ctl As Control, lbl As Control
    Dim rs As DAO.Recordset, fld As DAO.Field
    Dim tmpName As String, x As Long, w As Long, total As Long, avail As Long
    Dim scaleF As Double, i As Long, arr() As String, fName As String
    Dim colX As Object, colW As Object, colFmt As Object

    On Error GoTo EH
    DeleteIfExists acReport, rptName
    Set colX = CreateObject("Scripting.Dictionary")
    Set colW = CreateObject("Scripting.Dictionary")
    Set colFmt = CreateObject("Scripting.Dictionary")

    Set rpt = CreateReport()
    tmpName = rpt.Name
    rpt.RecordSource = src
    rpt.Caption = cap

    Set rs = CurrentDb.OpenRecordset("SELECT * FROM [" & src & "] WHERE 1=0", dbOpenSnapshot)
    total = 0
    For Each fld In rs.Fields
        If fld.Name <> grp Then total = total + RptWidth(fld) + 0.06 * TW
    Next fld
    If total > 7.4 * TW Then
        rpt.Printer.Orientation = acPRORLandscape
        avail = 9.9 * TW
    Else
        avail = 7.4 * TW
    End If
    scaleF = 1
    If total > avail Then scaleF = avail / total

    If Not HasSection(rpt, acHeader) Then DoCmd.RunCommand acCmdReportHdrFtr

    ' Report header: title
    rpt.Section(acHeader).Height = 0.75 * TW
    Set lbl = CreateControl(tmpName, acLabel, acHeader, , , 0, 0.1 * TW, 7 * TW, 0.45 * TW)
    lbl.Caption = cap
    lbl.FontName = "Segoe UI": lbl.FontSize = 16: lbl.FontBold = True
    lbl.ForeColor = RGB(31, 56, 100)
    Set ctl = CreateControl(tmpName, acTextBox, acHeader, , , 0, 0.5 * TW, 5 * TW, 0.22 * TW)
    ctl.ControlSource = "=""" & Replace(AppTitle(), """", "") & "  |  "" & Format(Date(),""yyyy-mm-dd"")"
    ctl.FontName = "Segoe UI": ctl.FontSize = 8: ctl.ForeColor = RGB(118, 118, 118)
    ctl.BorderStyle = 0

    ' Page header: column titles
    rpt.Section(acPageHeader).Height = 0.34 * TW
    rpt.Section(acPageHeader).BackColor = RGB(31, 56, 100)
    x = 0
    For Each fld In rs.Fields
        If fld.Name <> grp Then
            w = RptWidth(fld) * scaleF
            colX(fld.Name) = x: colW(fld.Name) = w: colFmt(fld.Name) = NumFormat(fld)
            Set lbl = CreateControl(tmpName, acLabel, acPageHeader, , , x, 0.05 * TW, w, 0.25 * TW)
            lbl.Caption = PrettyName(fld.Name)
            lbl.FontName = "Segoe UI": lbl.FontSize = 8: lbl.FontBold = True
            lbl.ForeColor = RGB(255, 255, 255)
            If IsNumericField(fld) Then lbl.TextAlign = 3
            ' Detail
            If fld.Type = dbBoolean Then
                Set ctl = CreateControl(tmpName, acCheckBox, acDetail, , fld.Name, x + w / 2 - 100, 0.04 * TW)
            Else
                Set ctl = CreateControl(tmpName, acTextBox, acDetail, , fld.Name, x, 0.02 * TW, w, 0.24 * TW)
                ctl.FontName = "Segoe UI": ctl.FontSize = 8
                ctl.BorderStyle = 0
                If fld.Type = dbMemo Then ctl.CanGrow = True
            End If
            x = x + w + 0.06 * TW * scaleF
        End If
    Next fld
    rs.Close
    rpt.Section(acDetail).Height = 0.28 * TW
    rpt.Section(acDetail).AlternateBackColor = RGB(242, 242, 242)

    ' Grouping
    If grp <> "" Then
        CreateGroupLevel tmpName, grp, True, True
        rpt.Section(acGroupLevel1Header).Height = 0.38 * TW
        rpt.Section(acGroupLevel1Header).BackColor = RGB(217, 226, 243)
        Set ctl = CreateControl(tmpName, acTextBox, acGroupLevel1Header, , grp, 0, 0.05 * TW, 5 * TW, 0.28 * TW)
        ctl.FontName = "Segoe UI": ctl.FontSize = 10: ctl.FontBold = True
        ctl.ForeColor = RGB(31, 56, 100): ctl.BorderStyle = 0: ctl.BackStyle = 0
        rpt.Section(acGroupLevel1Footer).Height = 0.32 * TW
        Set ctl = CreateControl(tmpName, acTextBox, acGroupLevel1Footer, , , 0, 0.04 * TW, 2.5 * TW, 0.24 * TW)
        ctl.ControlSource = "=""Subtotal ("" & Count(*) & "" records)"""
        ctl.FontName = "Segoe UI": ctl.FontSize = 8: ctl.FontItalic = True: ctl.BorderStyle = 0
    End If

    ' Report footer: grand totals
    rpt.Section(acFooter).Height = 0.4 * TW
    Set ctl = CreateControl(tmpName, acTextBox, acFooter, , , 0, 0.08 * TW, 2.5 * TW, 0.26 * TW)
    ctl.ControlSource = "=""Total records: "" & Count(*)"
    ctl.FontName = "Segoe UI": ctl.FontSize = 9: ctl.FontBold = True: ctl.BorderStyle = 0

    If sums <> "" Then
        arr = Split(sums, ",")
        For i = LBound(arr) To UBound(arr)
            fName = Trim(arr(i))
            If colX.Exists(fName) Then
                AddSum tmpName, acFooter, fName, colX(fName), colW(fName), colFmt(fName), True
                If grp <> "" Then AddSum tmpName, acGroupLevel1Footer, fName, colX(fName), colW(fName), colFmt(fName), False
            End If
        Next i
    End If

    ' Page footer
    rpt.Section(acPageFooter).Height = 0.3 * TW
    Set ctl = CreateControl(tmpName, acTextBox, acPageFooter, , , 0, 0.05 * TW, 3 * TW, 0.22 * TW)
    ctl.ControlSource = "=""Printed "" & Format(Now(),""yyyy-mm-dd hh:nn"")"
    ctl.FontName = "Segoe UI": ctl.FontSize = 7: ctl.BorderStyle = 0: ctl.ForeColor = RGB(118, 118, 118)
    Set ctl = CreateControl(tmpName, acTextBox, acPageFooter, , , avail - 2 * TW, 0.05 * TW, 2 * TW, 0.22 * TW)
    ctl.ControlSource = "=""Page "" & [Page] & "" of "" & [Pages]"
    ctl.FontName = "Segoe UI": ctl.FontSize = 7: ctl.BorderStyle = 0: ctl.TextAlign = 3
    ctl.ForeColor = RGB(118, 118, 118)

    DoCmd.Close acReport, tmpName, acSaveYes
    DoCmd.Rename rptName, acReport, tmpName
    Exit Sub
EH:
    mLog = mLog & "Report " & rptName & ": " & Err.Description & vbCrLf
    On Error Resume Next
    If tmpName <> "" Then DoCmd.Close acReport, tmpName, acSaveNo
End Sub

Private Sub AddSum(ByVal rptName As String, ByVal sec As Integer, ByVal fName As String, _
                   ByVal x As Long, ByVal w As Long, ByVal fmt As String, ByVal grand As Boolean)
    Dim ctl As Control
    Set ctl = CreateControl(rptName, acTextBox, sec, , , x, 0.06 * TW, w, 0.26 * TW)
    ctl.ControlSource = "=Sum([" & fName & "])"
    If fmt <> "" Then ctl.Format = fmt
    ctl.FontName = "Segoe UI": ctl.FontSize = IIf(grand, 9, 8): ctl.FontBold = True
    ctl.TextAlign = 3
    ctl.BorderStyle = 0
    If grand Then
        ctl.BorderStyle = 1
        ctl.BorderColor = RGB(31, 56, 100)
    End If
End Sub

' ---------------------------------------------------------------------
'  MAIN MENU (switchboard)
' ---------------------------------------------------------------------
Private Sub BuildMainMenu()
    Dim frm As Form, ctl As Control, tmpName As String, rs As DAO.Recordset
    Dim y(2) As Long, xs(2) As Long, i As Integer, bw As Long, maxY As Long
    Dim heads As Variant

    On Error GoTo EH
    DeleteIfExists acForm, "frmMainMenu"
    Set frm = CreateForm()
    tmpName = frm.Name
    frm.Caption = AppTitle()
    frm.RecordSelectors = False
    frm.NavigationButtons = False
    frm.DividingLines = False
    frm.ScrollBars = 2
    frm.AutoCenter = True
    frm.AllowDatasheetView = False

    If Not HasSection(frm, acHeader) Then DoCmd.RunCommand acCmdFormHdrFtr
    frm.Section(acHeader).Height = 1.15 * TW
    frm.Section(acHeader).BackColor = RGB(31, 56, 100)
    frm.Section(acDetail).BackColor = RGB(242, 242, 242)
    frm.Section(acFooter).Height = 0.35 * TW
    frm.Section(acFooter).BackColor = RGB(31, 56, 100)

    Set ctl = CreateControl(tmpName, acLabel, acHeader, , , 0.3 * TW, 0.15 * TW, 9 * TW, 0.5 * TW)
    ctl.Caption = AppTitle()
    ctl.FontName = "Segoe UI": ctl.FontSize = 20: ctl.FontBold = True: ctl.ForeColor = RGB(255, 255, 255)
    Set ctl = CreateControl(tmpName, acLabel, acHeader, , , 0.3 * TW, 0.7 * TW, 9.3 * TW, 0.3 * TW)
    ctl.Caption = Setting("AppSubtitle")
    ctl.FontName = "Segoe UI": ctl.FontSize = 10: ctl.ForeColor = RGB(217, 226, 243)
    Set ctl = CreateControl(tmpName, acLabel, acFooter, , , 0.3 * TW, 0.06 * TW, 9 * TW, 0.24 * TW)
    ctl.Caption = "Microsoft Access portfolio project  |  Version " & Setting("Version")
    ctl.FontName = "Segoe UI": ctl.FontSize = 8: ctl.ForeColor = RGB(217, 226, 243)

    bw = 3 * TW
    heads = Array("DATA ENTRY", "REPORTS", "ANALYSIS")
    For i = 0 To 2
        xs(i) = (0.3 + i * 3.2) * TW
        y(i) = 0.25 * TW
        Set ctl = CreateControl(tmpName, acLabel, acDetail, , , xs(i), y(i), bw, 0.3 * TW)
        ctl.Caption = heads(i)
        ctl.FontName = "Segoe UI": ctl.FontSize = 10: ctl.FontBold = True: ctl.ForeColor = RGB(31, 56, 100)
        y(i) = y(i) + 0.4 * TW
    Next i

    Set rs = CurrentDb.OpenRecordset("SELECT FormName, Caption FROM USysForms WHERE ShowInMenu=True ORDER BY SortOrder", dbOpenSnapshot)
    Do While Not rs.EOF
        AddMenuButton tmpName, xs(0), y(0), bw, rs!Caption, rs!FormName, "F"
        rs.MoveNext
    Loop
    rs.Close
    Set rs = CurrentDb.OpenRecordset("SELECT ReportName, Caption FROM USysReports ORDER BY SortOrder", dbOpenSnapshot)
    Do While Not rs.EOF
        AddMenuButton tmpName, xs(1), y(1), bw, rs!Caption, rs!ReportName, "R"
        rs.MoveNext
    Loop
    rs.Close
    Set rs = CurrentDb.OpenRecordset("SELECT QueryName, Description FROM USysQueries WHERE ShowInMenu=True " & _
                                     "AND QueryType<>'Action' ORDER BY SortOrder", dbOpenSnapshot)
    Do While Not rs.EOF
        AddMenuButton tmpName, xs(2), y(2), bw, PrettyName(Mid$(rs!QueryName, 4)), rs!QueryName, "Q"
        rs.MoveNext
    Loop
    rs.Close

    DoCmd.Close acForm, tmpName, acSaveYes
    DoCmd.Rename "frmMainMenu", acForm, tmpName
    Exit Sub
EH:
    mLog = mLog & "Main menu: " & Err.Description & vbCrLf
    On Error Resume Next
    If tmpName <> "" Then DoCmd.Close acForm, tmpName, acSaveNo
End Sub

Private Sub AddMenuButton(ByVal frmName As String, ByVal x As Long, ByRef y As Long, ByVal w As Long, _
                          ByVal cap As String, ByVal objName As String, ByVal kind As String)
    Dim ctl As Control
    Set ctl = CreateControl(frmName, acCommandButton, acDetail, , , x, y, w, 0.36 * TW)
    ctl.Caption = Replace(cap, "&", "and")
    ctl.OnClick = "=OpenItem(""" & objName & """,""" & kind & """)"
    ctl.FontName = "Segoe UI"
    ctl.FontSize = 9
    ctl.ControlTipText = "Open " & objName
    y = y + 0.44 * TW
End Sub

' ---------------------------------------------------------------------
'  STARTUP + HELPERS
' ---------------------------------------------------------------------
Private Sub SetStartup()
    SetDbProp "StartupForm", dbText, "frmMainMenu"
    SetDbProp "AppTitle", dbText, AppTitle()
    On Error Resume Next
    Application.RefreshTitleBar
End Sub

Private Sub SetDbProp(ByVal pName As String, ByVal pType As Integer, ByVal pValue As Variant)
    Dim db As DAO.Database, p As DAO.Property
    Set db = CurrentDb
    On Error Resume Next
    db.Properties(pName) = pValue
    If Err.Number <> 0 Then
        Err.Clear
        Set p = db.CreateProperty(pName, pType, pValue)
        db.Properties.Append p
    End If
End Sub

Private Function Setting(ByVal key As String) As String
    Setting = Nz(DLookup("SettingValue", "USysAppInfo", "SettingKey='" & key & "'"), "")
End Function

Private Function AppTitle() As String
    AppTitle = Setting("AppTitle")
    If AppTitle = "" Then AppTitle = CurrentProject.Name
End Function

Private Function LookupRowSource(ByVal fieldName As String, ByVal src As String) As String
    LookupRowSource = Nz(DLookup("RowSource", "USysLookups", _
        "FieldName='" & fieldName & "' AND ParentTable<>'" & Replace(src, "'", "''") & "'"), "")
End Function

Private Function HasSection(obj As Object, ByVal idx As Integer) As Boolean
    Dim h As Long
    On Error Resume Next
    h = obj.Section(idx).Height
    HasSection = (Err.Number = 0)
    Err.Clear
End Function

Private Sub DeleteIfExists(ByVal objType As Integer, ByVal objName As String)
    On Error Resume Next
    If objType = acForm Then
        If CurrentProject.AllForms(objName).IsLoaded Then DoCmd.Close acForm, objName, acSaveNo
    ElseIf objType = acReport Then
        If CurrentProject.AllReports(objName).IsLoaded Then DoCmd.Close acReport, objName, acSaveNo
    End If
    DoCmd.DeleteObject objType, objName
    Err.Clear
End Sub

Private Function IsNumericField(fld As DAO.Field) As Boolean
    Select Case fld.Type
        Case dbByte, dbInteger, dbLong, dbCurrency, dbSingle, dbDouble, dbDecimal
            IsNumericField = True
    End Select
End Function

Private Function NumFormat(fld As DAO.Field) As String
    Select Case fld.Type
        Case dbCurrency: NumFormat = "Currency"
        Case dbDouble, dbSingle, dbDecimal: NumFormat = "#,##0.00"
        Case dbByte, dbInteger, dbLong: NumFormat = "#,##0"
        Case Else: NumFormat = ""
    End Select
End Function

Private Function FieldWidth(fld As DAO.Field, ByVal tabular As Boolean) As Long
    Dim inch As Double
    Select Case fld.Type
        Case dbBoolean: inch = 0.8
        Case dbDate: inch = 1.1
        Case dbCurrency, dbDouble, dbSingle, dbDecimal: inch = 1.1
        Case dbByte, dbInteger, dbLong: inch = 0.85
        Case dbMemo: inch = IIf(tabular, 2.4, 4.6)
        Case Else
            inch = fld.Size * 0.045
            If inch < 1 Then inch = 1
            If inch > IIf(tabular, 2.4, 4) Then inch = IIf(tabular, 2.4, 4)
    End Select
    FieldWidth = inch * TW
End Function

Private Function RptWidth(fld As DAO.Field) As Long
    Dim inch As Double
    Select Case fld.Type
        Case dbBoolean: inch = 0.6
        Case dbDate: inch = 0.95
        Case dbCurrency, dbDouble, dbSingle, dbDecimal: inch = 1
        Case dbByte, dbInteger, dbLong: inch = 0.75
        Case dbMemo: inch = 2.4
        Case Else
            inch = fld.Size * 0.035
            If inch < 0.9 Then inch = 0.9
            If inch > 2.2 Then inch = 2.2
    End Select
    RptWidth = inch * TW
End Function

' "CustomerID" -> "Customer ID", "TotalAmountUSD" -> "Total Amount USD"
Private Function PrettyName(ByVal s As String) As String
    Dim i As Long, c As Integer, p As Integer, n As Integer, out As String
    s = Replace(s, "_", " ")
    For i = 1 To Len(s)
        c = Asc(Mid$(s, i, 1))
        If i > 1 Then
            p = Asc(Mid$(s, i - 1, 1))
            If i < Len(s) Then n = Asc(Mid$(s, i + 1, 1)) Else n = 0
            If c >= 65 And c <= 90 Then
                If (p >= 97 And p <= 122) Or (p >= 65 And p <= 90 And n >= 97 And n <= 122) Then out = out & " "
            End If
        End If
        out = out & Chr$(c)
    Next i
    PrettyName = Trim$(out)
End Function

Private Sub StyleTitle(lbl As Control)
    lbl.FontName = "Segoe UI"
    lbl.FontSize = 16
    lbl.FontBold = True
    lbl.ForeColor = RGB(255, 255, 255)
End Sub

Private Sub StyleHeaderLabel(lbl As Control)
    lbl.FontName = "Segoe UI"
    lbl.FontSize = 8
    lbl.FontBold = True
    lbl.ForeColor = RGB(217, 226, 243)
End Sub
