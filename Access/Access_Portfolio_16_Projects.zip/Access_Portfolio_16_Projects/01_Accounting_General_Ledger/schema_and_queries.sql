-- Accounting & General Ledger System
-- Double-entry bookkeeping: chart of accounts, journal entries, trial balance, P&L and balance sheet.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE AccountTypes (
    AccountTypeID COUNTER PRIMARY KEY,
    TypeName TEXT(30) NOT NULL UNIQUE,
    NormalBalance TEXT(10) NOT NULL,
    StatementType TEXT(30) NOT NULL
);

CREATE TABLE Accounts (
    AccountID COUNTER PRIMARY KEY,
    AccountCode TEXT(10) NOT NULL UNIQUE,
    AccountName TEXT(100) NOT NULL,
    AccountTypeID LONG NOT NULL,
    IsActive YESNO
);

CREATE TABLE FiscalPeriods (
    PeriodID COUNTER PRIMARY KEY,
    PeriodName TEXT(20) NOT NULL,
    StartDate DATETIME NOT NULL,
    EndDate DATETIME NOT NULL,
    IsClosed YESNO
);

CREATE TABLE JournalEntries (
    EntryID COUNTER PRIMARY KEY,
    EntryDate DATETIME NOT NULL,
    PeriodID LONG,
    Reference TEXT(30) NOT NULL,
    Memo TEXT(255),
    PostedBy TEXT(50),
    IsPosted YESNO
);

CREATE TABLE JournalLines (
    LineID COUNTER PRIMARY KEY,
    EntryID LONG NOT NULL,
    AccountID LONG NOT NULL,
    Debit CURRENCY,
    Credit CURRENCY,
    LineMemo TEXT(255)
);

ALTER TABLE Accounts ADD CONSTRAINT FK_Accounts_AccountTypeID FOREIGN KEY (AccountTypeID) REFERENCES AccountTypes (AccountTypeID);
ALTER TABLE JournalEntries ADD CONSTRAINT FK_JournalEntries_PeriodID FOREIGN KEY (PeriodID) REFERENCES FiscalPeriods (PeriodID);
ALTER TABLE JournalLines ADD CONSTRAINT FK_JournalLines_EntryID FOREIGN KEY (EntryID) REFERENCES JournalEntries (EntryID) ON DELETE CASCADE;
ALTER TABLE JournalLines ADD CONSTRAINT FK_JournalLines_AccountID FOREIGN KEY (AccountID) REFERENCES Accounts (AccountID);

-- ===== Saved queries =====

-- qryJournalDetail  [Select]  Full journal with account names
SELECT e.EntryID, e.EntryDate, e.Reference, e.Memo, a.AccountCode, a.AccountName, l.Debit, l.Credit, e.IsPosted FROM ((JournalEntries AS e INNER JOIN JournalLines AS l ON e.EntryID = l.EntryID) INNER JOIN Accounts AS a ON l.AccountID = a.AccountID) INNER JOIN AccountTypes AS t ON a.AccountTypeID = t.AccountTypeID ORDER BY e.EntryDate, e.EntryID, l.LineID;

-- qryTrialBalance  [Select]  Trial balance of posted entries
SELECT a.AccountCode, a.AccountName, t.TypeName, Sum(l.Debit) AS TotalDebit, Sum(l.Credit) AS TotalCredit, IIf(t.NormalBalance='Debit', Sum(l.Debit)-Sum(l.Credit), Sum(l.Credit)-Sum(l.Debit)) AS Balance FROM ((JournalEntries AS e INNER JOIN JournalLines AS l ON e.EntryID = l.EntryID) INNER JOIN Accounts AS a ON l.AccountID = a.AccountID) INNER JOIN AccountTypes AS t ON a.AccountTypeID = t.AccountTypeID WHERE e.IsPosted = True GROUP BY a.AccountCode, a.AccountName, t.TypeName, t.NormalBalance ORDER BY a.AccountCode;

-- qryIncomeStatement  [Select]  Revenue and expense by account
SELECT t.TypeName, a.AccountCode, a.AccountName, IIf(t.TypeName='Revenue', Sum(l.Credit)-Sum(l.Debit), Sum(l.Debit)-Sum(l.Credit)) AS Amount FROM ((JournalEntries AS e INNER JOIN JournalLines AS l ON e.EntryID = l.EntryID) INNER JOIN Accounts AS a ON l.AccountID = a.AccountID) INNER JOIN AccountTypes AS t ON a.AccountTypeID = t.AccountTypeID WHERE t.StatementType='Income Statement' AND e.IsPosted = True GROUP BY t.TypeName, a.AccountCode, a.AccountName ORDER BY t.TypeName DESC, a.AccountCode;

-- qryBalanceSheet  [Select]  Assets, liabilities and equity balances
SELECT t.TypeName, a.AccountCode, a.AccountName, IIf(t.NormalBalance='Debit', Sum(l.Debit)-Sum(l.Credit), Sum(l.Credit)-Sum(l.Debit)) AS Balance FROM ((JournalEntries AS e INNER JOIN JournalLines AS l ON e.EntryID = l.EntryID) INNER JOIN Accounts AS a ON l.AccountID = a.AccountID) INNER JOIN AccountTypes AS t ON a.AccountTypeID = t.AccountTypeID WHERE t.StatementType='Balance Sheet' AND e.IsPosted = True GROUP BY t.TypeName, t.NormalBalance, a.AccountCode, a.AccountName ORDER BY a.AccountCode;

-- qryMonthlyProfitLoss  [Select]  Monthly revenue, expenses and net income
SELECT Format(e.EntryDate,'yyyy-mm') AS PeriodMonth, Sum(IIf(t.TypeName='Revenue', l.Credit-l.Debit, 0)) AS Revenue, Sum(IIf(t.TypeName='Expense', l.Debit-l.Credit, 0)) AS Expenses, Sum(IIf(t.TypeName='Revenue', l.Credit-l.Debit, 0)) - Sum(IIf(t.TypeName='Expense', l.Debit-l.Credit, 0)) AS NetIncome FROM ((JournalEntries AS e INNER JOIN JournalLines AS l ON e.EntryID = l.EntryID) INNER JOIN Accounts AS a ON l.AccountID = a.AccountID) INNER JOIN AccountTypes AS t ON a.AccountTypeID = t.AccountTypeID WHERE e.IsPosted = True GROUP BY Format(e.EntryDate,'yyyy-mm') ORDER BY Format(e.EntryDate,'yyyy-mm');

-- qryUnbalancedEntries  [Select]  Audit: entries where debits do not equal credits
SELECT e.EntryID, e.Reference, e.EntryDate, e.Memo, Sum(l.Debit) AS TotalDebit, Sum(l.Credit) AS TotalCredit, Sum(l.Debit)-Sum(l.Credit) AS Difference FROM JournalEntries AS e INNER JOIN JournalLines AS l ON e.EntryID = l.EntryID GROUP BY e.EntryID, e.Reference, e.EntryDate, e.Memo HAVING Sum(l.Debit) <> Sum(l.Credit);

-- qryCashPosition  [Select]  Cash and bank balance
SELECT a.AccountName, Sum(l.Debit) AS CashIn, Sum(l.Credit) AS CashOut, Sum(l.Debit)-Sum(l.Credit) AS NetCash FROM Accounts AS a INNER JOIN JournalLines AS l ON a.AccountID = l.AccountID WHERE a.AccountCode IN ('1000','1100') GROUP BY a.AccountName;

-- qryXT_ExpensesByMonth  [Crosstab]  Crosstab: expense accounts by month
TRANSFORM Sum(l.Debit-l.Credit) AS Amount SELECT a.AccountName FROM (JournalLines AS l INNER JOIN Accounts AS a ON l.AccountID = a.AccountID) INNER JOIN JournalEntries AS e ON l.EntryID = e.EntryID WHERE a.AccountTypeID = 5 GROUP BY a.AccountName PIVOT Format(e.EntryDate,'yyyy-mm');

-- qryAccountLedger  [Parameter]  Parameter: ledger for one account
PARAMETERS [Enter account code] Text ( 255 ); SELECT e.EntryDate, e.Reference, e.Memo, l.Debit, l.Credit FROM (JournalEntries AS e INNER JOIN JournalLines AS l ON e.EntryID = l.EntryID) INNER JOIN Accounts AS a ON l.AccountID = a.AccountID WHERE a.AccountCode = [Enter account code] ORDER BY e.EntryDate;

-- qryAction_CloseEndedPeriods  [Action]  Action: close all periods that have ended
UPDATE FiscalPeriods SET IsClosed = True WHERE EndDate < Date();
