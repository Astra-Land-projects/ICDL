# Accounting & General Ledger System

**سیستم حسابداری و دفتر کل** — ثبت اسناد حسابداری دوطرفه، تراز آزمایشی، صورت سود و زیان ماهانه، ترازنامه و کنترل اسناد نامتوازن.

> Double-entry bookkeeping: chart of accounts, journal entries, trial balance, P&L and balance sheet.

## نحوه راه‌اندازی

1. فایل `01_Accounting_General_Ledger.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| AccountTypes | 5 | Asset, Liability, Equity, Revenue, Expense |
| Accounts | 18 | Chart of accounts |
| FiscalPeriods | 11 | Monthly accounting periods |
| JournalEntries | 73 | Journal entry headers |
| JournalLines | 186 | Debit/credit lines (must balance per entry) |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    AccountTypes ||--o{ Accounts : "AccountTypeID"
    FiscalPeriods ||--o{ JournalEntries : "PeriodID"
    JournalEntries ||--o{ JournalLines : "EntryID"
    Accounts ||--o{ JournalLines : "AccountID"
    AccountTypes {
        pk AccountTypeID PK
        text TypeName
        text NormalBalance
        text StatementType
    }
    Accounts {
        pk AccountID PK
        text AccountCode
        text AccountName
        long AccountTypeID FK
        bool IsActive
    }
    FiscalPeriods {
        pk PeriodID PK
        text PeriodName
        date StartDate
        date EndDate
        bool IsClosed
    }
    JournalEntries {
        pk EntryID PK
        date EntryDate
        long PeriodID FK
        text Reference
        text Memo
        text PostedBy
        bool IsPosted
    }
    JournalLines {
        pk LineID PK
        long EntryID FK
        long AccountID FK
        cur Debit
        cur Credit
        text LineMemo
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryJournalDetail | Select | Full journal with account names |
| qryTrialBalance | Select | Trial balance of posted entries |
| qryIncomeStatement | Select | Revenue and expense by account |
| qryBalanceSheet | Select | Assets, liabilities and equity balances |
| qryMonthlyProfitLoss | Select | Monthly revenue, expenses and net income |
| qryUnbalancedEntries | Select | Audit: entries where debits do not equal credits |
| qryCashPosition | Select | Cash and bank balance |
| qryXT_ExpensesByMonth | Crosstab | Crosstab: expense accounts by month |
| qryAccountLedger | Parameter | Parameter: ledger for one account |
| qryAction_CloseEndedPeriods | Action | Action: close all periods that have ended |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmAccountTypes | AccountTypes | Continuous |
| frmAccounts | Accounts | Continuous |
| frmFiscalPeriods | FiscalPeriods | Continuous |
| sfrmJournalLines | JournalLines | Continuous |
| frmJournalEntries | JournalEntries | Single + subform `sfrmJournalLines` |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptTrialBalance | qryTrialBalance | TypeName | TotalDebit,TotalCredit |
| rptIncomeStatement | qryIncomeStatement | TypeName | Amount |
| rptBalanceSheet | qryBalanceSheet | TypeName | Balance |
| rptMonthlyProfitLoss | qryMonthlyProfitLoss | - | Revenue,Expenses,NetIncome |
| rptGeneralJournal | qryJournalDetail | Reference | Debit,Credit |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
