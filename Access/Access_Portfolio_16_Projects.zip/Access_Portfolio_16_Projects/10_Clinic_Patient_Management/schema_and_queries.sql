-- Clinic & Patient Management System
-- Patients, doctors, appointments, visits and diagnoses, prescriptions, medicine stock, billing and insurance share.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Specialties (
    SpecialtyID COUNTER PRIMARY KEY,
    SpecialtyName TEXT(50) NOT NULL UNIQUE,
    VisitFee CURRENCY
);

CREATE TABLE Doctors (
    DoctorID COUNTER PRIMARY KEY,
    DoctorName TEXT(60) NOT NULL,
    SpecialtyID LONG,
    LicenseNo TEXT(20),
    Phone TEXT(30)
);

CREATE TABLE InsurancePlans (
    InsuranceID COUNTER PRIMARY KEY,
    PlanName TEXT(60) NOT NULL,
    CoveragePct DOUBLE
);

CREATE TABLE Patients (
    PatientID COUNTER PRIMARY KEY,
    FileNo TEXT(12) NOT NULL UNIQUE,
    FullName TEXT(60) NOT NULL,
    BirthDate DATETIME,
    Gender TEXT(1),
    BloodType TEXT(3),
    Phone TEXT(30),
    InsuranceID LONG,
    Allergies TEXT(255)
);

CREATE TABLE Appointments (
    AppointmentID COUNTER PRIMARY KEY,
    PatientID LONG NOT NULL,
    DoctorID LONG NOT NULL,
    ApptDateTime DATETIME,
    ApptStatus TEXT(20),
    Reason TEXT(150)
);

CREATE TABLE Visits (
    VisitID COUNTER PRIMARY KEY,
    AppointmentID LONG NOT NULL,
    Diagnosis TEXT(150),
    BloodPressure TEXT(10),
    WeightKg DOUBLE,
    DoctorNotes MEMO,
    FollowUpDate DATETIME
);

CREATE TABLE Medicines (
    MedicineID COUNTER PRIMARY KEY,
    MedicineName TEXT(80) NOT NULL,
    DosageForm TEXT(20),
    UnitPrice CURRENCY,
    StockQty LONG,
    ReorderLevel LONG
);

CREATE TABLE Prescriptions (
    PrescriptionID COUNTER PRIMARY KEY,
    VisitID LONG NOT NULL,
    MedicineID LONG NOT NULL,
    Dosage TEXT(50),
    Quantity LONG,
    Days INTEGER
);

ALTER TABLE Doctors ADD CONSTRAINT FK_Doctors_SpecialtyID FOREIGN KEY (SpecialtyID) REFERENCES Specialties (SpecialtyID);
ALTER TABLE Patients ADD CONSTRAINT FK_Patients_InsuranceID FOREIGN KEY (InsuranceID) REFERENCES InsurancePlans (InsuranceID);
ALTER TABLE Appointments ADD CONSTRAINT FK_Appointments_PatientID FOREIGN KEY (PatientID) REFERENCES Patients (PatientID);
ALTER TABLE Appointments ADD CONSTRAINT FK_Appointments_DoctorID FOREIGN KEY (DoctorID) REFERENCES Doctors (DoctorID);
ALTER TABLE Visits ADD CONSTRAINT FK_Visits_AppointmentID FOREIGN KEY (AppointmentID) REFERENCES Appointments (AppointmentID) ON DELETE CASCADE;
ALTER TABLE Prescriptions ADD CONSTRAINT FK_Prescriptions_VisitID FOREIGN KEY (VisitID) REFERENCES Visits (VisitID) ON DELETE CASCADE;
ALTER TABLE Prescriptions ADD CONSTRAINT FK_Prescriptions_MedicineID FOREIGN KEY (MedicineID) REFERENCES Medicines (MedicineID);

-- ===== Saved queries =====

-- qryTodaySchedule  [Select]  Upcoming scheduled appointments
SELECT a.ApptDateTime, d.DoctorName, pt.FileNo, pt.FullName, a.Reason, a.ApptStatus FROM (Appointments AS a INNER JOIN Doctors AS d ON a.DoctorID = d.DoctorID) INNER JOIN Patients AS pt ON a.PatientID = pt.PatientID WHERE a.ApptDateTime >= Date() AND a.ApptStatus = 'Scheduled' ORDER BY a.ApptDateTime;

-- qryVisitBilling  [Select]  Visit bill split between insurance and patient
SELECT v.VisitID, a.ApptDateTime, pt.FileNo, pt.FullName, d.DoctorName, sp.SpecialtyName, v.Diagnosis, ins.PlanName, (sp.VisitFee + Nz((SELECT Sum(r.Quantity*m.UnitPrice) FROM Prescriptions AS r INNER JOIN Medicines AS m ON r.MedicineID = m.MedicineID WHERE r.VisitID = v.VisitID),0)) AS TotalBill, Round((sp.VisitFee + Nz((SELECT Sum(r.Quantity*m.UnitPrice) FROM Prescriptions AS r INNER JOIN Medicines AS m ON r.MedicineID = m.MedicineID WHERE r.VisitID = v.VisitID),0))*ins.CoveragePct,2) AS InsurancePays, (sp.VisitFee + Nz((SELECT Sum(r.Quantity*m.UnitPrice) FROM Prescriptions AS r INNER JOIN Medicines AS m ON r.MedicineID = m.MedicineID WHERE r.VisitID = v.VisitID),0)) - Round((sp.VisitFee + Nz((SELECT Sum(r.Quantity*m.UnitPrice) FROM Prescriptions AS r INNER JOIN Medicines AS m ON r.MedicineID = m.MedicineID WHERE r.VisitID = v.VisitID),0))*ins.CoveragePct,2) AS PatientPays FROM ((((Visits AS v INNER JOIN Appointments AS a ON v.AppointmentID = a.AppointmentID) INNER JOIN Patients AS pt ON a.PatientID = pt.PatientID) INNER JOIN Doctors AS d ON a.DoctorID = d.DoctorID) INNER JOIN Specialties AS sp ON d.SpecialtyID = sp.SpecialtyID) INNER JOIN InsurancePlans AS ins ON pt.InsuranceID = ins.InsuranceID ORDER BY a.ApptDateTime;

-- qryDoctorWorkload  [Select]  Appointments and revenue per doctor
SELECT d.DoctorName, sp.SpecialtyName, Count(a.AppointmentID) AS Appointments, Sum(IIf(a.ApptStatus='Completed',1,0)) AS Completed, Sum(IIf(a.ApptStatus='No-Show',1,0)) AS NoShows, Sum(IIf(a.ApptStatus='Completed', sp.VisitFee, 0)) AS FeeRevenue FROM (Doctors AS d INNER JOIN Specialties AS sp ON d.SpecialtyID = sp.SpecialtyID) INNER JOIN Appointments AS a ON d.DoctorID = a.DoctorID GROUP BY d.DoctorName, sp.SpecialtyName ORDER BY Count(a.AppointmentID) DESC;

-- qryPatientHistory  [Select]  Medical history per patient
SELECT pt.FileNo, pt.FullName, a.ApptDateTime, d.DoctorName, v.Diagnosis, v.BloodPressure, v.WeightKg, v.FollowUpDate FROM ((Patients AS pt INNER JOIN Appointments AS a ON pt.PatientID = a.PatientID) INNER JOIN Doctors AS d ON a.DoctorID = d.DoctorID) INNER JOIN Visits AS v ON a.AppointmentID = v.AppointmentID ORDER BY pt.FullName, a.ApptDateTime;

-- qryPatientDemographics  [Select]  Patients by gender and age group
SELECT pt.Gender, IIf(DateDiff('yyyy', pt.BirthDate, Date()) < 18, '0-17', IIf(DateDiff('yyyy', pt.BirthDate, Date()) < 40, '18-39', IIf(DateDiff('yyyy', pt.BirthDate, Date()) < 65, '40-64', '65+'))) AS AgeGroup, Count(pt.PatientID) AS Patients FROM Patients AS pt GROUP BY pt.Gender, IIf(DateDiff('yyyy', pt.BirthDate, Date()) < 18, '0-17', IIf(DateDiff('yyyy', pt.BirthDate, Date()) < 40, '18-39', IIf(DateDiff('yyyy', pt.BirthDate, Date()) < 65, '40-64', '65+')));

-- qryMedicineStockAlert  [Select]  Pharmacy stock with reorder alert
SELECT m.MedicineName, m.DosageForm, m.StockQty, m.ReorderLevel, Nz((SELECT Sum(r.Quantity) FROM Prescriptions AS r WHERE r.MedicineID = m.MedicineID),0) AS Prescribed, IIf(m.StockQty <= m.ReorderLevel, 'REORDER', 'OK') AS StockAlert FROM Medicines AS m ORDER BY m.StockQty;

-- qryFollowUpsDue  [Select]  Patients needing follow-up
SELECT pt.FullName, pt.Phone, d.DoctorName, v.Diagnosis, v.FollowUpDate FROM ((Visits AS v INNER JOIN Appointments AS a ON v.AppointmentID = a.AppointmentID) INNER JOIN Patients AS pt ON a.PatientID = pt.PatientID) INNER JOIN Doctors AS d ON a.DoctorID = d.DoctorID WHERE v.FollowUpDate Is Not Null ORDER BY v.FollowUpDate;

-- qryXT_VisitsBySpecialtyMonth  [Crosstab]  Crosstab: completed visits by specialty per month
TRANSFORM Count(a.AppointmentID) AS Visits SELECT sp.SpecialtyName FROM (Appointments AS a INNER JOIN Doctors AS d ON a.DoctorID = d.DoctorID) INNER JOIN Specialties AS sp ON d.SpecialtyID = sp.SpecialtyID WHERE a.ApptStatus = 'Completed' GROUP BY sp.SpecialtyName PIVOT Format(a.ApptDateTime,'yyyy-mm');

-- qryPatientLookup  [Parameter]  Parameter: open a patient file
PARAMETERS [File number] Text ( 255 ); SELECT pt.FullName, pt.BirthDate, pt.BloodType, pt.Allergies, pt.Phone FROM Patients AS pt WHERE pt.FileNo = [File number];

-- qryAction_MarkNoShows  [Action]  Action: past scheduled appointments become No-Show
UPDATE Appointments SET ApptStatus = 'No-Show' WHERE ApptStatus = 'Scheduled' AND ApptDateTime < Date();
