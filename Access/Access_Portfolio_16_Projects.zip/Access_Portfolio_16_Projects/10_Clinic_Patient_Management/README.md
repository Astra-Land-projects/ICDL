# Clinic & Patient Management System

**سیستم مدیریت مطب و بیماران** — بیماران، پزشکان و تخصص‌ها، نوبت‌دهی، ویزیت و تشخیص، نسخه و دارو، صورتحساب و سهم بیمه.

> Patients, doctors, appointments, visits and diagnoses, prescriptions, medicine stock, billing and insurance share.

## نحوه راه‌اندازی

1. فایل `10_Clinic_Patient_Management.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Specialties | 6 | Medical specialties |
| Doctors | 7 | Physicians |
| InsurancePlans | 4 | Insurance coverage |
| Patients | 45 | Patient files |
| Appointments | 120 | Bookings |
| Visits | 91 | Clinical visit record |
| Medicines | 9 | Pharmacy stock |
| Prescriptions | 89 | Medicines prescribed per visit |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Specialties ||--o{ Doctors : "SpecialtyID"
    InsurancePlans ||--o{ Patients : "InsuranceID"
    Patients ||--o{ Appointments : "PatientID"
    Doctors ||--o{ Appointments : "DoctorID"
    Appointments ||--o{ Visits : "AppointmentID"
    Visits ||--o{ Prescriptions : "VisitID"
    Medicines ||--o{ Prescriptions : "MedicineID"
    Specialties {
        pk SpecialtyID PK
        text SpecialtyName
        cur VisitFee
    }
    Doctors {
        pk DoctorID PK
        text DoctorName
        long SpecialtyID FK
        text LicenseNo
        text Phone
    }
    InsurancePlans {
        pk InsuranceID PK
        text PlanName
        dbl CoveragePct
    }
    Patients {
        pk PatientID PK
        text FileNo
        text FullName
        date BirthDate
        text Gender
        text BloodType
        text Phone
        long InsuranceID FK
        text Allergies
    }
    Appointments {
        pk AppointmentID PK
        long PatientID FK
        long DoctorID FK
        date ApptDateTime
        text ApptStatus
        text Reason
    }
    Visits {
        pk VisitID PK
        long AppointmentID FK
        text Diagnosis
        text BloodPressure
        dbl WeightKg
        memo DoctorNotes
        date FollowUpDate
    }
    Medicines {
        pk MedicineID PK
        text MedicineName
        text DosageForm
        cur UnitPrice
        long StockQty
        long ReorderLevel
    }
    Prescriptions {
        pk PrescriptionID PK
        long VisitID FK
        long MedicineID FK
        text Dosage
        long Quantity
        int Days
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryTodaySchedule | Select | Upcoming scheduled appointments |
| qryVisitBilling | Select | Visit bill split between insurance and patient |
| qryDoctorWorkload | Select | Appointments and revenue per doctor |
| qryPatientHistory | Select | Medical history per patient |
| qryPatientDemographics | Select | Patients by gender and age group |
| qryMedicineStockAlert | Select | Pharmacy stock with reorder alert |
| qryFollowUpsDue | Select | Patients needing follow-up |
| qryXT_VisitsBySpecialtyMonth | Crosstab | Crosstab: completed visits by specialty per month |
| qryPatientLookup | Parameter | Parameter: open a patient file |
| qryAction_MarkNoShows | Action | Action: past scheduled appointments become No-Show |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmPatients | Patients | Single |
| frmDoctors | Doctors | Continuous |
| frmSpecialties | Specialties | Continuous |
| frmAppointments | Appointments | Continuous |
| sfrmPrescriptions | Prescriptions | Continuous |
| frmVisits | Visits | Single + subform `sfrmPrescriptions` |
| frmMedicines | Medicines | Continuous |
| frmInsurancePlans | InsurancePlans | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptSchedule | qryTodaySchedule | DoctorName | - |
| rptVisitBilling | qryVisitBilling | PlanName | TotalBill,InsurancePays,PatientPays |
| rptDoctorWorkload | qryDoctorWorkload | - | Appointments,Completed,FeeRevenue |
| rptPatientHistory | qryPatientHistory | FullName | - |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
