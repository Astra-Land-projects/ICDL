# Library Management System

**سیستم مدیریت کتابخانه** — کتاب‌ها و نسخه‌ها، نویسندگان (رابطه چند به چند)، اعضا، امانت و بازگشت، دیرکرد و جریمه خودکار.

> Books and copies, authors (many-to-many), members, loans and returns, overdue tracking and automatic fines.

## نحوه راه‌اندازی

1. فایل `09_Library_Management.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Authors | 16 | Book authors |
| Genres | 8 | Genres |
| Books | 20 | Titles |
| BookAuthors | 21 | Junction: books <-> authors |
| Copies | 33 | Physical copies |
| Members | 30 | Library members |
| Loans | 90 | Borrowing transactions |
| FineRules | 4 | Fine per day by member type |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Genres ||--o{ Books : "GenreID"
    Books ||--o{ BookAuthors : "BookID"
    Authors ||--o{ BookAuthors : "AuthorID"
    Books ||--o{ Copies : "BookID"
    Copies ||--o{ Loans : "CopyID"
    Members ||--o{ Loans : "MemberID"
    Authors {
        pk AuthorID PK
        text AuthorName
        text Nationality
    }
    Genres {
        pk GenreID PK
        text GenreName
    }
    Books {
        pk BookID PK
        text ISBN
        text BookTitle
        long GenreID FK
        text Publisher
        int PubYear
        text ShelfLocation
    }
    BookAuthors {
        pk BookAuthorID PK
        long BookID FK
        long AuthorID FK
    }
    Copies {
        pk CopyID PK
        text Barcode
        long BookID FK
        text Condition
        date Acquired
    }
    Members {
        pk MemberID PK
        text CardNo
        text FullName
        text Email
        text Phone
        text MemberType
        date JoinDate
        bool IsActive
    }
    Loans {
        pk LoanID PK
        long CopyID FK
        long MemberID FK
        date LoanDate
        date DueDate
        date ReturnDate
        bool FinePaid
    }
    FineRules {
        pk FineRuleID PK
        text MemberType
        cur DailyFine
        int MaxLoans
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryCatalog | Select | Catalog with authors and genre |
| qryCurrentLoans | Select | Books currently on loan |
| qryOverdueLoans | Select | Overdue items with fine |
| qryUnpaidFines | Select | Outstanding fines per member |
| qryCopyAvailability | Select | Total vs available copies |
| qryPopularBooks | Select | Top 10 most borrowed titles |
| qryMemberActivity | Select | Loans per member |
| qryXT_LoansByGenreMonth | Crosstab | Crosstab: loans by genre per month |
| qrySearchByTitle | Parameter | Parameter: search catalog by title |
| qryAction_MarkFinesPaid | Action | Action: clear fine flag for on-time returns |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmBooks | Books | Single |
| frmAuthors | Authors | Continuous |
| frmBookAuthors | BookAuthors | Continuous |
| frmCopies | Copies | Continuous |
| sfrmLoans | Loans | Continuous |
| frmMembers | Members | Single + subform `sfrmLoans` |
| frmFineRules | FineRules | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptCatalog | qryCatalog | GenreName | - |
| rptOverdue | qryOverdueLoans | - | DaysLate,FineDue |
| rptUnpaidFines | qryUnpaidFines | MemberType | TotalFine |
| rptPopularBooks | qryPopularBooks | - | TimesBorrowed |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
