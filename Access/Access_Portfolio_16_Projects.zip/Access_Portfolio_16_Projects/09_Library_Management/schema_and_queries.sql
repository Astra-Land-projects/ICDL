-- Library Management System
-- Books and copies, authors (many-to-many), members, loans and returns, overdue tracking and automatic fines.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Authors (
    AuthorID COUNTER PRIMARY KEY,
    AuthorName TEXT(80) NOT NULL,
    Nationality TEXT(40)
);

CREATE TABLE Genres (
    GenreID COUNTER PRIMARY KEY,
    GenreName TEXT(40) NOT NULL UNIQUE
);

CREATE TABLE Books (
    BookID COUNTER PRIMARY KEY,
    ISBN TEXT(20) NOT NULL UNIQUE,
    BookTitle TEXT(150) NOT NULL,
    GenreID LONG,
    Publisher TEXT(60),
    PubYear INTEGER,
    ShelfLocation TEXT(10)
);

CREATE TABLE BookAuthors (
    BookAuthorID COUNTER PRIMARY KEY,
    BookID LONG NOT NULL,
    AuthorID LONG NOT NULL
);

CREATE TABLE Copies (
    CopyID COUNTER PRIMARY KEY,
    Barcode TEXT(20) NOT NULL UNIQUE,
    BookID LONG NOT NULL,
    Condition TEXT(20),
    Acquired DATETIME
);

CREATE TABLE Members (
    MemberID COUNTER PRIMARY KEY,
    CardNo TEXT(12) NOT NULL UNIQUE,
    FullName TEXT(60) NOT NULL,
    Email TEXT(100),
    Phone TEXT(30),
    MemberType TEXT(20),
    JoinDate DATETIME,
    IsActive YESNO
);

CREATE TABLE Loans (
    LoanID COUNTER PRIMARY KEY,
    CopyID LONG NOT NULL,
    MemberID LONG NOT NULL,
    LoanDate DATETIME,
    DueDate DATETIME,
    ReturnDate DATETIME,
    FinePaid YESNO
);

CREATE TABLE FineRules (
    FineRuleID COUNTER PRIMARY KEY,
    MemberType TEXT(20) NOT NULL UNIQUE,
    DailyFine CURRENCY,
    MaxLoans INTEGER
);

ALTER TABLE Books ADD CONSTRAINT FK_Books_GenreID FOREIGN KEY (GenreID) REFERENCES Genres (GenreID);
ALTER TABLE BookAuthors ADD CONSTRAINT FK_BookAuthors_BookID FOREIGN KEY (BookID) REFERENCES Books (BookID) ON DELETE CASCADE;
ALTER TABLE BookAuthors ADD CONSTRAINT FK_BookAuthors_AuthorID FOREIGN KEY (AuthorID) REFERENCES Authors (AuthorID);
ALTER TABLE Copies ADD CONSTRAINT FK_Copies_BookID FOREIGN KEY (BookID) REFERENCES Books (BookID) ON DELETE CASCADE;
ALTER TABLE Loans ADD CONSTRAINT FK_Loans_CopyID FOREIGN KEY (CopyID) REFERENCES Copies (CopyID);
ALTER TABLE Loans ADD CONSTRAINT FK_Loans_MemberID FOREIGN KEY (MemberID) REFERENCES Members (MemberID);

-- ===== Saved queries =====

-- qryCatalog  [Select]  Catalog with authors and genre
SELECT b.ISBN, b.BookTitle, a.AuthorName, g.GenreName, b.PubYear, b.ShelfLocation FROM ((Books AS b INNER JOIN BookAuthors AS ba ON b.BookID = ba.BookID) INNER JOIN Authors AS a ON ba.AuthorID = a.AuthorID) INNER JOIN Genres AS g ON b.GenreID = g.GenreID ORDER BY b.BookTitle;

-- qryCurrentLoans  [Select]  Books currently on loan
SELECT m.CardNo, m.FullName, b.BookTitle, c.Barcode, l.LoanDate, l.DueDate, IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0)) AS DaysLate, IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0))*fr.DailyFine AS FineDue FROM (((Loans AS l INNER JOIN Copies AS c ON l.CopyID = c.CopyID) INNER JOIN Books AS b ON c.BookID = b.BookID) INNER JOIN Members AS m ON l.MemberID = m.MemberID) INNER JOIN FineRules AS fr ON m.MemberType = fr.MemberType WHERE l.ReturnDate Is Null ORDER BY l.DueDate;

-- qryOverdueLoans  [Select]  Overdue items with fine
SELECT m.CardNo, m.FullName, m.Phone, b.BookTitle, l.DueDate, IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0)) AS DaysLate, IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0))*fr.DailyFine AS FineDue FROM (((Loans AS l INNER JOIN Copies AS c ON l.CopyID = c.CopyID) INNER JOIN Books AS b ON c.BookID = b.BookID) INNER JOIN Members AS m ON l.MemberID = m.MemberID) INNER JOIN FineRules AS fr ON m.MemberType = fr.MemberType WHERE l.ReturnDate Is Null AND l.DueDate < Date() ORDER BY l.DueDate;

-- qryUnpaidFines  [Select]  Outstanding fines per member
SELECT m.CardNo, m.FullName, m.MemberType, Count(l.LoanID) AS LateLoans, Sum(IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0))) AS TotalDaysLate, Sum(IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0))*fr.DailyFine) AS TotalFine FROM (((Loans AS l INNER JOIN Copies AS c ON l.CopyID = c.CopyID) INNER JOIN Books AS b ON c.BookID = b.BookID) INNER JOIN Members AS m ON l.MemberID = m.MemberID) INNER JOIN FineRules AS fr ON m.MemberType = fr.MemberType WHERE l.FinePaid = False AND IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0)) > 0 GROUP BY m.CardNo, m.FullName, m.MemberType ORDER BY Sum(IIf(l.ReturnDate Is Null, IIf(Date()>l.DueDate, DateDiff('d', l.DueDate, Date()), 0), IIf(l.ReturnDate>l.DueDate, DateDiff('d', l.DueDate, l.ReturnDate), 0))*fr.DailyFine) DESC;

-- qryCopyAvailability  [Select]  Total vs available copies
SELECT b.BookTitle, Count(c.CopyID) AS TotalCopies, Count(c.CopyID) - Nz((SELECT Count(*) FROM Loans AS x INNER JOIN Copies AS y ON x.CopyID = y.CopyID WHERE y.BookID = b.BookID AND x.ReturnDate Is Null),0) AS Available FROM Books AS b INNER JOIN Copies AS c ON b.BookID = c.BookID GROUP BY b.BookID, b.BookTitle ORDER BY b.BookTitle;

-- qryPopularBooks  [Select]  Top 10 most borrowed titles
SELECT TOP 10 b.BookTitle, g.GenreName, Count(l.LoanID) AS TimesBorrowed FROM ((Books AS b INNER JOIN Copies AS c ON b.BookID = c.BookID) INNER JOIN Loans AS l ON c.CopyID = l.CopyID) INNER JOIN Genres AS g ON b.GenreID = g.GenreID GROUP BY b.BookTitle, g.GenreName ORDER BY Count(l.LoanID) DESC;

-- qryMemberActivity  [Select]  Loans per member
SELECT m.CardNo, m.FullName, m.MemberType, Count(l.LoanID) AS TotalLoans, Max(l.LoanDate) AS LastVisit FROM Members AS m LEFT JOIN Loans AS l ON m.MemberID = l.MemberID GROUP BY m.CardNo, m.FullName, m.MemberType ORDER BY Count(l.LoanID) DESC;

-- qryXT_LoansByGenreMonth  [Crosstab]  Crosstab: loans by genre per month
TRANSFORM Count(l.LoanID) AS Loans SELECT g.GenreName FROM ((Loans AS l INNER JOIN Copies AS c ON l.CopyID = c.CopyID) INNER JOIN Books AS b ON c.BookID = b.BookID) INNER JOIN Genres AS g ON b.GenreID = g.GenreID GROUP BY g.GenreName PIVOT Format(l.LoanDate,'yyyy-mm');

-- qrySearchByTitle  [Parameter]  Parameter: search catalog by title
PARAMETERS [Title contains] Text ( 255 ); SELECT b.BookTitle, b.ISBN, b.ShelfLocation FROM Books AS b WHERE b.BookTitle Like '*' & [Title contains] & '*';

-- qryAction_MarkFinesPaid  [Action]  Action: clear fine flag for on-time returns
UPDATE Loans SET FinePaid = True WHERE ReturnDate Is Not Null AND ReturnDate <= DueDate;
