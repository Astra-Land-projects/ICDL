# Sales, Orders & Invoicing System

**سیستم فروش، سفارش و صدور فاکتور** — مدیریت مشتریان، محصولات، سفارش‌ها با جزئیات، پرداخت‌ها، فاکتورهای پرداخت‌نشده و تحلیل فروش.

> Customers, products, orders with line items, payments, outstanding invoices and sales analytics.

## نحوه راه‌اندازی

1. فایل `02_Sales_Invoicing_Orders.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Customers | 18 | Customer master |
| Categories | 6 | Product categories |
| Products | 14 | Product catalog |
| Orders | 60 | Order / invoice header |
| OrderDetails | 144 | Order line items |
| Payments | 52 | Customer payments |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Categories ||--o{ Products : "CategoryID"
    Customers ||--o{ Orders : "CustomerID"
    Orders ||--o{ OrderDetails : "OrderID"
    Products ||--o{ OrderDetails : "ProductID"
    Orders ||--o{ Payments : "OrderID"
    Customers {
        pk CustomerID PK
        text CompanyName
        text ContactName
        text Email
        text Phone
        text City
        text Country
        date CustomerSince
        cur CreditLimit
    }
    Categories {
        pk CategoryID PK
        text CategoryName
        text Notes
    }
    Products {
        pk ProductID PK
        text SKU
        text ProductName
        long CategoryID FK
        cur UnitPrice
        cur UnitCost
        bool Discontinued
    }
    Orders {
        pk OrderID PK
        text InvoiceNo
        long CustomerID FK
        date OrderDate
        date DueDate
        text SalesRep
        dbl TaxRate
        text OrderStatus
    }
    OrderDetails {
        pk DetailID PK
        long OrderID FK
        long ProductID FK
        long Quantity
        cur UnitPrice
        dbl Discount
    }
    Payments {
        pk PaymentID PK
        long OrderID FK
        date PaymentDate
        cur Amount
        text Method
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryOrderLines | Select | All invoice lines with totals |
| qryInvoiceTotals | Select | Invoice subtotal, tax and total |
| qryOutstandingInvoices | Select | Accounts receivable: unpaid balances and days overdue |
| qryMonthlySales | Select | Monthly revenue, cost and gross profit |
| qryTopProducts | Select | Top 10 products by revenue |
| qryCustomerRanking | Select | Customer revenue and loyalty tier |
| qryCustomersWithoutOrders | Select | Customers who never ordered |
| qryXT_CategoryByMonth | Crosstab | Crosstab: revenue per category per month |
| qryInvoiceByNumber | Parameter | Parameter: look up one invoice |
| qryAction_RaisePrices5pct | Action | Action: increase active product prices by 5% |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmCustomers | Customers | Single |
| frmCategories | Categories | Continuous |
| frmProducts | Products | Continuous |
| sfrmOrderDetails | OrderDetails | Continuous |
| frmOrders | Orders | Single + subform `sfrmOrderDetails` |
| frmPayments | Payments | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptInvoiceRegister | qryInvoiceTotals | OrderStatus | Subtotal,Tax,InvoiceTotal |
| rptOutstandingInvoices | qryOutstandingInvoices | - | InvoiceTotal,AmountPaid,BalanceDue |
| rptMonthlySales | qryMonthlySales | - | Units,Revenue,Cost,GrossProfit |
| rptCustomerRanking | qryCustomerRanking | Tier | Revenue |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
