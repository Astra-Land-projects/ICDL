-- Sales, Orders & Invoicing System
-- Customers, products, orders with line items, payments, outstanding invoices and sales analytics.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Customers (
    CustomerID COUNTER PRIMARY KEY,
    CompanyName TEXT(100) NOT NULL,
    ContactName TEXT(60),
    Email TEXT(100),
    Phone TEXT(30),
    City TEXT(50),
    Country TEXT(50),
    CustomerSince DATETIME,
    CreditLimit CURRENCY
);

CREATE TABLE Categories (
    CategoryID COUNTER PRIMARY KEY,
    CategoryName TEXT(50) NOT NULL UNIQUE,
    Notes TEXT(255)
);

CREATE TABLE Products (
    ProductID COUNTER PRIMARY KEY,
    SKU TEXT(20) NOT NULL UNIQUE,
    ProductName TEXT(100) NOT NULL,
    CategoryID LONG,
    UnitPrice CURRENCY,
    UnitCost CURRENCY,
    Discontinued YESNO
);

CREATE TABLE Orders (
    OrderID COUNTER PRIMARY KEY,
    InvoiceNo TEXT(20) NOT NULL UNIQUE,
    CustomerID LONG NOT NULL,
    OrderDate DATETIME NOT NULL,
    DueDate DATETIME,
    SalesRep TEXT(50),
    TaxRate DOUBLE,
    OrderStatus TEXT(20)
);

CREATE TABLE OrderDetails (
    DetailID COUNTER PRIMARY KEY,
    OrderID LONG NOT NULL,
    ProductID LONG NOT NULL,
    Quantity LONG,
    UnitPrice CURRENCY,
    Discount DOUBLE
);

CREATE TABLE Payments (
    PaymentID COUNTER PRIMARY KEY,
    OrderID LONG NOT NULL,
    PaymentDate DATETIME,
    Amount CURRENCY,
    Method TEXT(20)
);

ALTER TABLE Products ADD CONSTRAINT FK_Products_CategoryID FOREIGN KEY (CategoryID) REFERENCES Categories (CategoryID);
ALTER TABLE Orders ADD CONSTRAINT FK_Orders_CustomerID FOREIGN KEY (CustomerID) REFERENCES Customers (CustomerID);
ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_OrderID FOREIGN KEY (OrderID) REFERENCES Orders (OrderID) ON DELETE CASCADE;
ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_ProductID FOREIGN KEY (ProductID) REFERENCES Products (ProductID);
ALTER TABLE Payments ADD CONSTRAINT FK_Payments_OrderID FOREIGN KEY (OrderID) REFERENCES Orders (OrderID);

-- ===== Saved queries =====

-- qryOrderLines  [Select]  All invoice lines with totals
SELECT o.InvoiceNo, o.OrderDate, c.CompanyName, pr.ProductName, d.Quantity, d.UnitPrice, d.Discount, d.Quantity*d.UnitPrice*(1-d.Discount) AS LineTotal FROM ((Orders AS o INNER JOIN Customers AS c ON o.CustomerID = c.CustomerID) INNER JOIN OrderDetails AS d ON o.OrderID = d.OrderID) INNER JOIN Products AS pr ON d.ProductID = pr.ProductID ORDER BY o.OrderDate, o.InvoiceNo;

-- qryInvoiceTotals  [Select]  Invoice subtotal, tax and total
SELECT o.OrderID, o.InvoiceNo, o.OrderDate, o.DueDate, c.CompanyName, o.OrderStatus, Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) AS Subtotal, Round(Sum(d.Quantity*d.UnitPrice*(1-d.Discount))*o.TaxRate,2) AS Tax, Round(Sum(d.Quantity*d.UnitPrice*(1-d.Discount))*(1+o.TaxRate),2) AS InvoiceTotal FROM (Orders AS o INNER JOIN Customers AS c ON o.CustomerID = c.CustomerID) INNER JOIN OrderDetails AS d ON o.OrderID = d.OrderID GROUP BY o.OrderID, o.InvoiceNo, o.OrderDate, o.DueDate, c.CompanyName, o.OrderStatus, o.TaxRate ORDER BY o.OrderDate;

-- qryOutstandingInvoices  [Select]  Accounts receivable: unpaid balances and days overdue
SELECT o.InvoiceNo, c.CompanyName, o.OrderDate, o.DueDate, Round(Sum(d.Quantity*d.UnitPrice*(1-d.Discount))*(1+o.TaxRate),2) AS InvoiceTotal, Nz((SELECT Sum(pm.Amount) FROM Payments AS pm WHERE pm.OrderID = o.OrderID),0) AS AmountPaid, Round(Sum(d.Quantity*d.UnitPrice*(1-d.Discount))*(1+o.TaxRate),2) - Nz((SELECT Sum(pm.Amount) FROM Payments AS pm WHERE pm.OrderID = o.OrderID),0) AS BalanceDue, IIf(o.DueDate < Date(), DateDiff('d', o.DueDate, Date()), 0) AS DaysOverdue FROM (Orders AS o INNER JOIN Customers AS c ON o.CustomerID = c.CustomerID) INNER JOIN OrderDetails AS d ON o.OrderID = d.OrderID WHERE o.OrderStatus <> 'Cancelled' GROUP BY o.OrderID, o.InvoiceNo, c.CompanyName, o.OrderDate, o.DueDate, o.TaxRate HAVING Round(Sum(d.Quantity*d.UnitPrice*(1-d.Discount))*(1+o.TaxRate),2) - Nz((SELECT Sum(pm.Amount) FROM Payments AS pm WHERE pm.OrderID = o.OrderID),0) > 0.01 ORDER BY o.DueDate;

-- qryMonthlySales  [Select]  Monthly revenue, cost and gross profit
SELECT Format(o.OrderDate,'yyyy-mm') AS SalesMonth, Count(d.DetailID) AS LineItems, Sum(d.Quantity) AS Units, Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) AS Revenue, Sum(d.Quantity*pr.UnitCost) AS Cost, Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) - Sum(d.Quantity*pr.UnitCost) AS GrossProfit FROM (Orders AS o INNER JOIN OrderDetails AS d ON o.OrderID = d.OrderID) INNER JOIN Products AS pr ON d.ProductID = pr.ProductID WHERE o.OrderStatus <> 'Cancelled' GROUP BY Format(o.OrderDate,'yyyy-mm') ORDER BY Format(o.OrderDate,'yyyy-mm');

-- qryTopProducts  [Select]  Top 10 products by revenue
SELECT TOP 10 pr.SKU, pr.ProductName, cat.CategoryName, Sum(d.Quantity) AS UnitsSold, Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) AS Revenue FROM ((Products AS pr INNER JOIN Categories AS cat ON pr.CategoryID = cat.CategoryID) INNER JOIN OrderDetails AS d ON pr.ProductID = d.ProductID) INNER JOIN Orders AS o ON d.OrderID = o.OrderID WHERE o.OrderStatus <> 'Cancelled' GROUP BY pr.SKU, pr.ProductName, cat.CategoryName ORDER BY Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) DESC;

-- qryCustomerRanking  [Select]  Customer revenue and loyalty tier
SELECT c.CompanyName, c.Country, Count(o.OrderID) AS OrderLines, Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) AS Revenue, IIf(Sum(d.Quantity*d.UnitPrice*(1-d.Discount))>=20000,'Platinum',IIf(Sum(d.Quantity*d.UnitPrice*(1-d.Discount))>=8000,'Gold','Silver')) AS Tier FROM (Customers AS c INNER JOIN Orders AS o ON c.CustomerID = o.CustomerID) INNER JOIN OrderDetails AS d ON o.OrderID = d.OrderID WHERE o.OrderStatus <> 'Cancelled' GROUP BY c.CompanyName, c.Country ORDER BY Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) DESC;

-- qryCustomersWithoutOrders  [Select]  Customers who never ordered
SELECT c.CompanyName, c.City, c.Email FROM Customers AS c LEFT JOIN Orders AS o ON c.CustomerID = o.CustomerID WHERE o.OrderID Is Null;

-- qryXT_CategoryByMonth  [Crosstab]  Crosstab: revenue per category per month
TRANSFORM Sum(d.Quantity*d.UnitPrice*(1-d.Discount)) AS Revenue SELECT cat.CategoryName FROM ((Categories AS cat INNER JOIN Products AS pr ON cat.CategoryID = pr.CategoryID) INNER JOIN OrderDetails AS d ON pr.ProductID = d.ProductID) INNER JOIN Orders AS o ON d.OrderID = o.OrderID GROUP BY cat.CategoryName PIVOT Format(o.OrderDate,'yyyy-mm');

-- qryInvoiceByNumber  [Parameter]  Parameter: look up one invoice
PARAMETERS [Invoice number] Text ( 255 ); SELECT o.InvoiceNo, c.CompanyName, pr.ProductName, d.Quantity, d.UnitPrice, d.Discount FROM ((Orders AS o INNER JOIN Customers AS c ON o.CustomerID = c.CustomerID) INNER JOIN OrderDetails AS d ON o.OrderID = d.OrderID) INNER JOIN Products AS pr ON d.ProductID = pr.ProductID WHERE o.InvoiceNo = [Invoice number];

-- qryAction_RaisePrices5pct  [Action]  Action: increase active product prices by 5%
UPDATE Products SET UnitPrice = Round(UnitPrice*1.05,2) WHERE Discontinued = False;
