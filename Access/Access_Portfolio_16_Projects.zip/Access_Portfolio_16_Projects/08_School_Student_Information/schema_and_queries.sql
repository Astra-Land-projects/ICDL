-- School Student Information System
-- Students, teachers, courses, class sections, enrollments, weighted GPA, attendance and report cards.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Teachers (
    TeacherID COUNTER PRIMARY KEY,
    FirstName TEXT(40) NOT NULL,
    LastName TEXT(40) NOT NULL,
    Subject TEXT(50),
    Email TEXT(100),
    HireDate DATETIME
);

CREATE TABLE Courses (
    CourseID COUNTER PRIMARY KEY,
    CourseCode TEXT(10) NOT NULL UNIQUE,
    CourseTitle TEXT(100) NOT NULL,
    Credits INTEGER,
    Department TEXT(50)
);

CREATE TABLE Students (
    StudentID COUNTER PRIMARY KEY,
    StudentNo TEXT(12) NOT NULL UNIQUE,
    FirstName TEXT(40) NOT NULL,
    LastName TEXT(40) NOT NULL,
    BirthDate DATETIME,
    GradeLevel INTEGER,
    GuardianPhone TEXT(30),
    Email TEXT(100),
    EnrolledOn DATETIME
);

CREATE TABLE ClassSections (
    SectionID COUNTER PRIMARY KEY,
    SectionCode TEXT(20) NOT NULL UNIQUE,
    CourseID LONG NOT NULL,
    TeacherID LONG,
    Term TEXT(20),
    Room TEXT(10),
    MaxSeats INTEGER
);

CREATE TABLE Enrollments (
    EnrollmentID COUNTER PRIMARY KEY,
    StudentID LONG NOT NULL,
    SectionID LONG NOT NULL,
    MidtermScore DOUBLE,
    FinalScore DOUBLE,
    ProjectScore DOUBLE
);

CREATE TABLE AttendanceLog (
    AttendanceID COUNTER PRIMARY KEY,
    EnrollmentID LONG NOT NULL,
    ClassDate DATETIME,
    Present YESNO,
    Late YESNO
);

ALTER TABLE ClassSections ADD CONSTRAINT FK_ClassSections_CourseID FOREIGN KEY (CourseID) REFERENCES Courses (CourseID);
ALTER TABLE ClassSections ADD CONSTRAINT FK_ClassSections_TeacherID FOREIGN KEY (TeacherID) REFERENCES Teachers (TeacherID);
ALTER TABLE Enrollments ADD CONSTRAINT FK_Enrollments_StudentID FOREIGN KEY (StudentID) REFERENCES Students (StudentID) ON DELETE CASCADE;
ALTER TABLE Enrollments ADD CONSTRAINT FK_Enrollments_SectionID FOREIGN KEY (SectionID) REFERENCES ClassSections (SectionID);
ALTER TABLE AttendanceLog ADD CONSTRAINT FK_AttendanceLog_EnrollmentID FOREIGN KEY (EnrollmentID) REFERENCES Enrollments (EnrollmentID) ON DELETE CASCADE;

-- ===== Saved queries =====

-- qryGradebook  [Select]  Weighted score (30/50/20) and letter grade
SELECT s.StudentNo, s.FirstName & ' ' & s.LastName AS StudentName, c.CourseCode, c.CourseTitle, c.Credits, e.MidtermScore, e.FinalScore, e.ProjectScore, Round((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2),1) AS WeightedScore, IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=90,'A',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=80,'B',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=70,'C',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=60,'D','F')))) AS LetterGrade FROM ((Students AS s INNER JOIN Enrollments AS e ON s.StudentID = e.StudentID) INNER JOIN ClassSections AS cs ON e.SectionID = cs.SectionID) INNER JOIN Courses AS c ON cs.CourseID = c.CourseID ORDER BY s.LastName, c.CourseCode;

-- qryStudentGPA  [Select]  Credit-weighted GPA and academic standing
SELECT s.StudentNo, s.FirstName & ' ' & s.LastName AS StudentName, s.GradeLevel, Count(e.EnrollmentID) AS Courses, Sum(c.Credits) AS TotalCredits, Round(Sum(IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=90,4,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=80,3,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=70,2,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=60,1,0))))*c.Credits)/Sum(c.Credits),2) AS GPA, IIf((Sum(IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=90,4,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=80,3,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=70,2,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=60,1,0))))*c.Credits)/Sum(c.Credits)) >= 3.5, 'Honor Roll', IIf((Sum(IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=90,4,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=80,3,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=70,2,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=60,1,0))))*c.Credits)/Sum(c.Credits)) < 2, 'Academic Probation', 'Good Standing')) AS Standing FROM ((Students AS s INNER JOIN Enrollments AS e ON s.StudentID = e.StudentID) INNER JOIN ClassSections AS cs ON e.SectionID = cs.SectionID) INNER JOIN Courses AS c ON cs.CourseID = c.CourseID GROUP BY s.StudentNo, s.FirstName, s.LastName, s.GradeLevel ORDER BY Sum(IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=90,4,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=80,3,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=70,2,IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=60,1,0))))*c.Credits)/Sum(c.Credits) DESC;

-- qryClassStatistics  [Select]  Per-class averages, top and failing counts
SELECT c.CourseCode, c.CourseTitle, t.FirstName & ' ' & t.LastName AS Teacher, Count(e.EnrollmentID) AS Enrolled, Round(Avg((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)),1) AS AvgScore, Round(Max((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)),1) AS TopScore, Round(Min((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)),1) AS LowScore, Sum(IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)<60,1,0)) AS Failing FROM ((Courses AS c INNER JOIN ClassSections AS cs ON c.CourseID = cs.CourseID) INNER JOIN Teachers AS t ON cs.TeacherID = t.TeacherID) INNER JOIN Enrollments AS e ON cs.SectionID = e.SectionID GROUP BY c.CourseCode, c.CourseTitle, t.FirstName, t.LastName ORDER BY c.CourseCode;

-- qryAttendanceRate  [Select]  Attendance % per student (lowest first)
SELECT s.StudentNo, s.FirstName & ' ' & s.LastName AS StudentName, Count(a.AttendanceID) AS Sessions, Sum(IIf(a.Present,1,0)) AS Attended, Sum(IIf(a.Late,1,0)) AS LateCount, Sum(IIf(a.Present,1,0))/Count(a.AttendanceID) AS AttendanceRate FROM (Students AS s INNER JOIN Enrollments AS e ON s.StudentID = e.StudentID) INNER JOIN AttendanceLog AS a ON e.EnrollmentID = a.EnrollmentID GROUP BY s.StudentNo, s.FirstName, s.LastName ORDER BY Sum(IIf(a.Present,1,0))/Count(a.AttendanceID);

-- qryAtRiskStudents  [Select]  Students scoring below 65 or missing final
SELECT s.StudentNo, s.FirstName & ' ' & s.LastName AS StudentName, c.CourseTitle, Round((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2),1) AS WeightedScore, s.GuardianPhone FROM ((Students AS s INNER JOIN Enrollments AS e ON s.StudentID = e.StudentID) INNER JOIN ClassSections AS cs ON e.SectionID = cs.SectionID) INNER JOIN Courses AS c ON cs.CourseID = c.CourseID WHERE (e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2) < 65 OR e.FinalScore Is Null ORDER BY (e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2);

-- qryClassRoster  [Select]  Roster per class section
SELECT cs.SectionCode, c.CourseTitle, cs.Room, s.StudentNo, s.FirstName & ' ' & s.LastName AS StudentName, s.GradeLevel FROM ((ClassSections AS cs INNER JOIN Courses AS c ON cs.CourseID = c.CourseID) INNER JOIN Enrollments AS e ON cs.SectionID = e.SectionID) INNER JOIN Students AS s ON e.StudentID = s.StudentID ORDER BY cs.SectionCode, s.LastName;

-- qryXT_GradeDistribution  [Crosstab]  Crosstab: letter-grade distribution per course
TRANSFORM Count(e.EnrollmentID) AS Students SELECT c.CourseCode FROM (Enrollments AS e INNER JOIN ClassSections AS cs ON e.SectionID = cs.SectionID) INNER JOIN Courses AS c ON cs.CourseID = c.CourseID GROUP BY c.CourseCode PIVOT IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=90,'A',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=80,'B',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=70,'C',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=60,'D','F'))));

-- qryReportCard  [Parameter]  Parameter: one student's report card
PARAMETERS [Student number] Text ( 255 ); SELECT c.CourseTitle, c.Credits, Round((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2),1) AS WeightedScore, IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=90,'A',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=80,'B',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=70,'C',IIf((e.MidtermScore*0.3 + Nz(e.FinalScore,0)*0.5 + e.ProjectScore*0.2)>=60,'D','F')))) AS LetterGrade FROM ((Students AS s INNER JOIN Enrollments AS e ON s.StudentID = e.StudentID) INNER JOIN ClassSections AS cs ON e.SectionID = cs.SectionID) INNER JOIN Courses AS c ON cs.CourseID = c.CourseID WHERE s.StudentNo = [Student number];

-- qryAction_PromoteGradeLevel  [Action]  Action: end-of-year grade promotion
UPDATE Students SET GradeLevel = GradeLevel + 1 WHERE GradeLevel < 12;
