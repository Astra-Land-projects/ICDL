# School Student Information System

**سیستم اطلاعات دانش‌آموزان و مدرسه** — دانش‌آموزان، معلمان، دروس، کلاس‌ها، ثبت‌نام، نمرات با معدل وزنی (GPA)، حضور و غیاب و کارنامه.

> Students, teachers, courses, class sections, enrollments, weighted GPA, attendance and report cards.

## نحوه راه‌اندازی

1. فایل `08_School_Student_Information.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Teachers | 8 | Teaching staff |
| Courses | 10 | Course catalog |
| Students | 40 | Student records |
| ClassSections | 10 | Course offerings per term |
| Enrollments | 200 | Student in a section with scores |
| AttendanceLog | 1600 | Per-class attendance |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    Courses ||--o{ ClassSections : "CourseID"
    Teachers ||--o{ ClassSections : "TeacherID"
    Students ||--o{ Enrollments : "StudentID"
    ClassSections ||--o{ Enrollments : "SectionID"
    Enrollments ||--o{ AttendanceLog : "EnrollmentID"
    Teachers {
        pk TeacherID PK
        text FirstName
        text LastName
        text Subject
        text Email
        date HireDate
    }
    Courses {
        pk CourseID PK
        text CourseCode
        text CourseTitle
        int Credits
        text Department
    }
    Students {
        pk StudentID PK
        text StudentNo
        text FirstName
        text LastName
        date BirthDate
        int GradeLevel
        text GuardianPhone
        text Email
        date EnrolledOn
    }
    ClassSections {
        pk SectionID PK
        text SectionCode
        long CourseID FK
        long TeacherID FK
        text Term
        text Room
        int MaxSeats
    }
    Enrollments {
        pk EnrollmentID PK
        long StudentID FK
        long SectionID FK
        dbl MidtermScore
        dbl FinalScore
        dbl ProjectScore
    }
    AttendanceLog {
        pk AttendanceID PK
        long EnrollmentID FK
        date ClassDate
        bool Present
        bool Late
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryGradebook | Select | Weighted score (30/50/20) and letter grade |
| qryStudentGPA | Select | Credit-weighted GPA and academic standing |
| qryClassStatistics | Select | Per-class averages, top and failing counts |
| qryAttendanceRate | Select | Attendance % per student (lowest first) |
| qryAtRiskStudents | Select | Students scoring below 65 or missing final |
| qryClassRoster | Select | Roster per class section |
| qryXT_GradeDistribution | Crosstab | Crosstab: letter-grade distribution per course |
| qryReportCard | Parameter | Parameter: one student's report card |
| qryAction_PromoteGradeLevel | Action | Action: end-of-year grade promotion |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmStudents | Students | Single |
| frmTeachers | Teachers | Continuous |
| frmCourses | Courses | Continuous |
| sfrmEnrollments | Enrollments | Continuous |
| frmClassSections | ClassSections | Single + subform `sfrmEnrollments` |
| frmAttendanceLog | AttendanceLog | Continuous |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptGradebook | qryGradebook | StudentName | - |
| rptStudentGPA | qryStudentGPA | Standing | - |
| rptClassStatistics | qryClassStatistics | - | Enrolled,Failing |
| rptClassRoster | qryClassRoster | SectionCode | - |
| rptAtRisk | qryAtRiskStudents | CourseTitle | - |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
