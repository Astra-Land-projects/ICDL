-- Inventory & Warehouse Management
-- Multi-warehouse stock, suppliers, stock movements, live on-hand quantity, reorder alerts and purchase orders.
-- Microsoft Access (Jet/ACE) SQL. Tables, relationships and saved queries.

CREATE TABLE Suppliers (
    SupplierID COUNTER PRIMARY KEY,
    SupplierName TEXT(100) NOT NULL,
    ContactName TEXT(60),
    Email TEXT(100),
    Country TEXT(50),
    LeadTimeDays INTEGER
);

CREATE TABLE Warehouses (
    WarehouseID COUNTER PRIMARY KEY,
    WarehouseName TEXT(60) NOT NULL,
    City TEXT(50),
    Capacity LONG
);

CREATE TABLE ProductCategories (
    CategoryID COUNTER PRIMARY KEY,
    CategoryName TEXT(50) NOT NULL UNIQUE
);

CREATE TABLE Items (
    ItemID COUNTER PRIMARY KEY,
    SKU TEXT(20) NOT NULL UNIQUE,
    ItemName TEXT(100) NOT NULL,
    CategoryID LONG,
    SupplierID LONG,
    UnitCost CURRENCY,
    ReorderPoint LONG,
    ReorderQty LONG
);

CREATE TABLE StockMovements (
    MovementID COUNTER PRIMARY KEY,
    ItemID LONG NOT NULL,
    WarehouseID LONG NOT NULL,
    MoveDate DATETIME,
    MoveType TEXT(10),
    Quantity LONG,
    RefDoc TEXT(30)
);

CREATE TABLE PurchaseOrders (
    POID COUNTER PRIMARY KEY,
    PONumber TEXT(20) NOT NULL UNIQUE,
    SupplierID LONG NOT NULL,
    OrderDate DATETIME,
    ExpectedDate DATETIME,
    POStatus TEXT(20)
);

CREATE TABLE PODetails (
    PODetailID COUNTER PRIMARY KEY,
    POID LONG NOT NULL,
    ItemID LONG NOT NULL,
    QtyOrdered LONG,
    UnitCost CURRENCY
);

ALTER TABLE Items ADD CONSTRAINT FK_Items_CategoryID FOREIGN KEY (CategoryID) REFERENCES ProductCategories (CategoryID);
ALTER TABLE Items ADD CONSTRAINT FK_Items_SupplierID FOREIGN KEY (SupplierID) REFERENCES Suppliers (SupplierID);
ALTER TABLE StockMovements ADD CONSTRAINT FK_StockMovements_ItemID FOREIGN KEY (ItemID) REFERENCES Items (ItemID);
ALTER TABLE StockMovements ADD CONSTRAINT FK_StockMovements_WarehouseID FOREIGN KEY (WarehouseID) REFERENCES Warehouses (WarehouseID);
ALTER TABLE PurchaseOrders ADD CONSTRAINT FK_PurchaseOrders_SupplierID FOREIGN KEY (SupplierID) REFERENCES Suppliers (SupplierID);
ALTER TABLE PODetails ADD CONSTRAINT FK_PODetails_POID FOREIGN KEY (POID) REFERENCES PurchaseOrders (POID) ON DELETE CASCADE;
ALTER TABLE PODetails ADD CONSTRAINT FK_PODetails_ItemID FOREIGN KEY (ItemID) REFERENCES Items (ItemID);

-- ===== Saved queries =====

-- qryStockOnHand  [Select]  Live on-hand quantity, value and status
SELECT i.SKU, i.ItemName, c.CategoryName, Sum(m.Quantity) AS OnHand, i.ReorderPoint, i.UnitCost, Sum(m.Quantity)*i.UnitCost AS StockValue, IIf(Sum(m.Quantity)<=0,'OUT OF STOCK',IIf(Sum(m.Quantity)<=i.ReorderPoint,'REORDER','OK')) AS StockStatus FROM (Items AS i INNER JOIN ProductCategories AS c ON i.CategoryID = c.CategoryID) INNER JOIN StockMovements AS m ON i.ItemID = m.ItemID GROUP BY i.SKU, i.ItemName, c.CategoryName, i.ReorderPoint, i.UnitCost ORDER BY i.SKU;

-- qryStockByWarehouse  [Select]  Stock per warehouse
SELECT w.WarehouseName, i.SKU, i.ItemName, Sum(m.Quantity) AS OnHand, Sum(m.Quantity)*i.UnitCost AS StockValue FROM (StockMovements AS m INNER JOIN Items AS i ON m.ItemID = i.ItemID) INNER JOIN Warehouses AS w ON m.WarehouseID = w.WarehouseID GROUP BY w.WarehouseName, i.SKU, i.ItemName, i.UnitCost ORDER BY w.WarehouseName, i.SKU;

-- qryReorderList  [Select]  Items at or below reorder point
SELECT i.SKU, i.ItemName, s.SupplierName, s.LeadTimeDays, Sum(m.Quantity) AS OnHand, i.ReorderPoint, i.ReorderQty, i.ReorderQty*i.UnitCost AS OrderCost FROM (Items AS i INNER JOIN Suppliers AS s ON i.SupplierID = s.SupplierID) INNER JOIN StockMovements AS m ON i.ItemID = m.ItemID GROUP BY i.SKU, i.ItemName, s.SupplierName, s.LeadTimeDays, i.ReorderPoint, i.ReorderQty, i.UnitCost HAVING Sum(m.Quantity) <= i.ReorderPoint ORDER BY s.SupplierName;

-- qryMovementHistory  [Select]  Full movement log
SELECT m.MoveDate, m.MoveType, i.SKU, i.ItemName, w.WarehouseName, m.Quantity, m.RefDoc FROM (StockMovements AS m INNER JOIN Items AS i ON m.ItemID = i.ItemID) INNER JOIN Warehouses AS w ON m.WarehouseID = w.WarehouseID ORDER BY m.MoveDate DESC;

-- qryMonthlyConsumption  [Select]  Units received vs shipped per month
SELECT Format(m.MoveDate,'yyyy-mm') AS MoveMonth, Sum(IIf(m.MoveType='IN', m.Quantity, 0)) AS UnitsIn, -Sum(IIf(m.MoveType='OUT', m.Quantity, 0)) AS UnitsOut FROM StockMovements AS m GROUP BY Format(m.MoveDate,'yyyy-mm') ORDER BY Format(m.MoveDate,'yyyy-mm');

-- qryOpenPurchaseOrders  [Select]  Purchase orders not yet received
SELECT po.PONumber, s.SupplierName, po.OrderDate, po.ExpectedDate, po.POStatus, Sum(d.QtyOrdered*d.UnitCost) AS POValue, IIf(po.ExpectedDate < Date(), 'LATE', 'On time') AS DeliveryFlag FROM (PurchaseOrders AS po INNER JOIN Suppliers AS s ON po.SupplierID = s.SupplierID) INNER JOIN PODetails AS d ON po.POID = d.POID WHERE po.POStatus <> 'Received' GROUP BY po.PONumber, s.SupplierName, po.OrderDate, po.ExpectedDate, po.POStatus ORDER BY po.ExpectedDate;

-- qryValueByCategory  [Select]  Inventory value by category
SELECT c.CategoryName, Count(i.ItemID) AS Movements, Sum(m.Quantity*i.UnitCost) AS StockValue FROM (ProductCategories AS c INNER JOIN Items AS i ON c.CategoryID = i.CategoryID) INNER JOIN StockMovements AS m ON i.ItemID = m.ItemID GROUP BY c.CategoryName ORDER BY Sum(m.Quantity*i.UnitCost) DESC;

-- qryXT_StockItemByWarehouse  [Crosstab]  Crosstab: on-hand per item and warehouse
TRANSFORM Sum(m.Quantity) AS OnHand SELECT i.ItemName FROM (StockMovements AS m INNER JOIN Items AS i ON m.ItemID = i.ItemID) INNER JOIN Warehouses AS w ON m.WarehouseID = w.WarehouseID GROUP BY i.ItemName PIVOT w.WarehouseName;

-- qryItemCard  [Parameter]  Parameter: stock card for one SKU
PARAMETERS [SKU] Text ( 255 ); SELECT m.MoveDate, m.MoveType, w.WarehouseName, m.Quantity, m.RefDoc FROM (StockMovements AS m INNER JOIN Items AS i ON m.ItemID = i.ItemID) INNER JOIN Warehouses AS w ON m.WarehouseID = w.WarehouseID WHERE i.SKU = [SKU] ORDER BY m.MoveDate;

-- qryAction_MarkLatePOs  [Action]  Action: flag overdue purchase orders
UPDATE PurchaseOrders SET POStatus = 'Late' WHERE ExpectedDate < Date() AND POStatus = 'Ordered';
