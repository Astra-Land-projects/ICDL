# Inventory & Warehouse Management

**سیستم مدیریت انبار و موجودی** — چند انبار، تأمین‌کنندگان، ورود و خروج کالا، موجودی لحظه‌ای، هشدار سفارش مجدد و سفارش خرید.

> Multi-warehouse stock, suppliers, stock movements, live on-hand quantity, reorder alerts and purchase orders.

## نحوه راه‌اندازی

1. فایل `05_Inventory_Warehouse.accdb` را در Microsoft Access باز کنید (در صورت نمایش هشدار امنیتی، روی **Enable Content** کلیک کنید).
2. با `Alt+F11` وارد ویرایشگر VBA شوید و از منوی **File › Import File** فایل `AccessAutoBuilder.bas` (در پوشه اصلی زیپ) را وارد کنید.
3. مکان‌نما را داخل `BuildApplication` بگذارید و `F5` را بزنید. همه کوئری‌ها، فرم‌ها، گزارش‌ها و منوی اصلی ساخته می‌شوند و از این به بعد منوی اصلی هنگام باز کردن فایل نمایش داده می‌شود.

## جداول (Tables)

| Table | Records | Description |
|---|---|---|
| Suppliers | 5 | Vendors |
| Warehouses | 3 | Storage locations |
| ProductCategories | 6 | Item categories |
| Items | 18 | Stock-keeping units |
| StockMovements | 177 | Every stock in/out transaction |
| PurchaseOrders | 8 | Purchase orders |
| PODetails | 15 | Purchase order lines |

## نمودار رابطه‌ها (ER Diagram)

```mermaid
erDiagram
    ProductCategories ||--o{ Items : "CategoryID"
    Suppliers ||--o{ Items : "SupplierID"
    Items ||--o{ StockMovements : "ItemID"
    Warehouses ||--o{ StockMovements : "WarehouseID"
    Suppliers ||--o{ PurchaseOrders : "SupplierID"
    PurchaseOrders ||--o{ PODetails : "POID"
    Items ||--o{ PODetails : "ItemID"
    Suppliers {
        pk SupplierID PK
        text SupplierName
        text ContactName
        text Email
        text Country
        int LeadTimeDays
    }
    Warehouses {
        pk WarehouseID PK
        text WarehouseName
        text City
        long Capacity
    }
    ProductCategories {
        pk CategoryID PK
        text CategoryName
    }
    Items {
        pk ItemID PK
        text SKU
        text ItemName
        long CategoryID FK
        long SupplierID FK
        cur UnitCost
        long ReorderPoint
        long ReorderQty
    }
    StockMovements {
        pk MovementID PK
        long ItemID FK
        long WarehouseID FK
        date MoveDate
        text MoveType
        long Quantity
        text RefDoc
    }
    PurchaseOrders {
        pk POID PK
        text PONumber
        long SupplierID FK
        date OrderDate
        date ExpectedDate
        text POStatus
    }
    PODetails {
        pk PODetailID PK
        long POID FK
        long ItemID FK
        long QtyOrdered
        cur UnitCost
    }
```

## کوئری‌ها (Saved Queries)

| Query | Type | Purpose |
|---|---|---|
| qryStockOnHand | Select | Live on-hand quantity, value and status |
| qryStockByWarehouse | Select | Stock per warehouse |
| qryReorderList | Select | Items at or below reorder point |
| qryMovementHistory | Select | Full movement log |
| qryMonthlyConsumption | Select | Units received vs shipped per month |
| qryOpenPurchaseOrders | Select | Purchase orders not yet received |
| qryValueByCategory | Select | Inventory value by category |
| qryXT_StockItemByWarehouse | Crosstab | Crosstab: on-hand per item and warehouse |
| qryItemCard | Parameter | Parameter: stock card for one SKU |
| qryAction_MarkLatePOs | Action | Action: flag overdue purchase orders |

## فرم‌ها (Forms)

| Form | Source | View |
|---|---|---|
| frmSuppliers | Suppliers | Continuous |
| frmWarehouses | Warehouses | Continuous |
| frmItems | Items | Continuous |
| frmStockMovements | StockMovements | Continuous |
| sfrmPODetails | PODetails | Continuous |
| frmPurchaseOrders | PurchaseOrders | Single + subform `sfrmPODetails` |

## گزارش‌ها (Reports)

| Report | Source | Grouping | Totals |
|---|---|---|---|
| rptStockOnHand | qryStockOnHand | StockStatus | OnHand,StockValue |
| rptReorderList | qryReorderList | SupplierName | ReorderQty,OrderCost |
| rptStockByWarehouse | qryStockByWarehouse | WarehouseName | OnHand,StockValue |
| rptOpenPOs | qryOpenPurchaseOrders | - | POValue |

## مهارت‌های نمایش‌داده‌شده

- طراحی پایگاه داده رابطه‌ای نرمال (کلید اصلی، کلید خارجی، یکپارچگی ارجاعی و Cascade)
- قوانین اعتبارسنجی (Validation Rules)، مقادیر پیش‌فرض و فیلدهای Lookup
- کوئری‌های Select، Aggregate، Crosstab، Parameter و Action (Update/Delete)
- فرم‌های ورود داده با Combo Box و Subform، گزارش‌های گروه‌بندی‌شده با جمع کل
- اتوماسیون با VBA (ساخت خودکار اپلیکیشن و منوی اصلی)
