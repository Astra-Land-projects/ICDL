# پورتفولیو Microsoft Access — ۱۶ پروژه دیتابیس رابطه‌ای

۱۶ اپلیکیشن کامل Access در حوزه‌های مختلف (مالی، فروش، منابع انسانی، CRM، انبار، مدیریت پروژه، IT، آموزش، کتابخانه، درمان، هتل، رستوران، املاک، اجاره خودرو، باشگاه ورزشی، شغل و مهاجرت).

هر دیتابیس شامل این موارد است:

- **جداول نرمال‌شده** با کلید اصلی AutoNumber، فیلدهای Required و Unique، نوع داده درست (Currency، Date/Time، Yes/No، Memo)
- **روابط (Relationships)** با Referential Integrity، Cascade Update و در جای مناسب Cascade Delete
- **قوانین اعتبارسنجی** (Validation Rule)، مقادیر پیش‌فرض، Format و توضیح فیلدها
- **Lookup** روی همه کلیدهای خارجی (کمبوباکس با نمایش نام به جای عدد)
- **داده نمونه واقع‌گرایانه** (در مجموع بیش از ۸۵۰۰ رکورد)
- **کوئری‌ها**: Select با Join چندگانه، Aggregate/Group By، Subquery، Crosstab (TRANSFORM/PIVOT)، Parameter و Action (UPDATE/DELETE)
- **فرم‌ها**: فرم ورود داده Single و Continuous، فرم اصلی + زیرفرم (Master/Detail)
- **گزارش‌ها**: گروه‌بندی، جمع گروه و جمع کل، شماره صفحه، تاریخ چاپ
- **منوی اصلی (Main Menu / Switchboard)** که هنگام باز شدن فایل خودکار نمایش داده می‌شود

## راه‌اندازی (یک بار برای هر فایل، حدود ۳۰ ثانیه)

Access روی لینوکس قابل اجرا نیست، پس جداول، روابط و داده مستقیم داخل فایل `.accdb` ساخته شده‌اند و تعریف کوئری‌ها، فرم‌ها و گزارش‌ها در جداول مخفی `USys*` ذخیره شده است. ماژول `AccessAutoBuilder.bas` آن‌ها را داخل خود Access می‌سازد:

1. فایل `.accdb` پروژه را در Microsoft Access (نسخه 2010 به بعد / Microsoft 365) باز کنید و روی **Enable Content** کلیک کنید.
2. `Alt+F11` را بزنید تا ویرایشگر VBA باز شود.
3. از منوی **File › Import File…** فایل `AccessAutoBuilder.bas` را از همین پوشه انتخاب کنید.
4. در صورت نیاز از **Tools › References** گزینه *Microsoft Office xx.x Access database engine Object Library* (DAO) را فعال کنید (معمولاً به صورت پیش‌فرض فعال است).
5. مکان‌نما را داخل `Sub BuildApplication` بگذارید و `F5` را بزنید.
6. فایل را ذخیره کنید. از این به بعد با باز کردن فایل، منوی اصلی نمایش داده می‌شود.

> ساخت مجدد در هر زمان امن است؛ اشیای قبلی حذف و دوباره ساخته می‌شوند. برای دیدن جداول مخفی USys: File › Options › Current Database › Navigation Options › Show System Objects.

## فهرست پروژه‌ها

| # | پروژه | جداول | رکوردها | کوئری | فرم | گزارش | پوشه |
|---|---|---|---|---|---|---|---|
| 01 | **سیستم حسابداری و دفتر کل**<br>Accounting & General Ledger System | 5 | 293 | 10 | 5 | 5 | `01_Accounting_General_Ledger/` |
| 02 | **سیستم فروش، سفارش و صدور فاکتور**<br>Sales, Orders & Invoicing System | 6 | 294 | 10 | 6 | 4 | `02_Sales_Invoicing_Orders/` |
| 03 | **سیستم منابع انسانی و حقوق و دستمزد**<br>HR & Payroll Management System | 6 | 628 | 10 | 6 | 4 | `03_HR_Payroll_Management/` |
| 04 | **سیستم مدیریت ارتباط با مشتری (CRM)**<br>CRM - Customer Relationship Management | 5 | 187 | 9 | 5 | 4 | `04_CRM_Customer_Relationship/` |
| 05 | **سیستم مدیریت انبار و موجودی**<br>Inventory & Warehouse Management | 7 | 232 | 10 | 6 | 4 | `05_Inventory_Warehouse/` |
| 06 | **سیستم مدیریت پروژه و تایم‌شیت**<br>Project Management & Timesheets | 6 | 207 | 9 | 6 | 4 | `06_Project_Management_Timesheets/` |
| 07 | **سیستم هلپ‌دسک و مدیریت دارایی‌های IT**<br>IT Helpdesk & Asset Management | 6 | 155 | 9 | 6 | 4 | `07_IT_Helpdesk_Asset_Management/` |
| 08 | **سیستم اطلاعات دانش‌آموزان و مدرسه**<br>School Student Information System | 6 | 1868 | 9 | 6 | 5 | `08_School_Student_Information/` |
| 09 | **سیستم مدیریت کتابخانه**<br>Library Management System | 8 | 222 | 10 | 7 | 4 | `09_Library_Management/` |
| 10 | **سیستم مدیریت مطب و بیماران**<br>Clinic & Patient Management System | 8 | 371 | 10 | 8 | 4 | `10_Clinic_Patient_Management/` |
| 11 | **سیستم رزرو هتل**<br>Hotel Reservation & Booking System | 6 | 336 | 10 | 6 | 4 | `11_Hotel_Reservation/` |
| 12 | **سیستم فروش رستوران (POS) و آشپزخانه**<br>Restaurant POS & Kitchen Management | 8 | 969 | 10 | 8 | 4 | `12_Restaurant_POS/` |
| 13 | **سیستم مدیریت مشاور املاک**<br>Real Estate Agency Management | 6 | 224 | 10 | 6 | 4 | `13_Real_Estate_Agency/` |
| 14 | **سیستم اجاره خودرو و مدیریت ناوگان**<br>Car Rental & Fleet Management | 6 | 276 | 10 | 7 | 4 | `14_Car_Rental_Fleet/` |
| 15 | **سیستم مدیریت باشگاه ورزشی و عضویت**<br>Gym Membership & Fitness Club | 7 | 2347 | 11 | 7 | 5 | `15_Gym_Membership_Fitness/` |
| 16 | **سیستم پیگیری شغل، مهاجرت و پورتفولیو**<br>Career, Immigration & Portfolio Tracker | 8 | 158 | 12 | 8 | 5 | `16_Career_Immigration_Portfolio/` |

## محتوای هر پوشه

- `XX_Name.accdb` — دیتابیس Access
- `README.md` — توضیح پروژه، نمودار ER (Mermaid)، فهرست جداول، کوئری‌ها، فرم‌ها و گزارش‌ها
- `schema_and_queries.sql` — اسکریپت کامل ساختار و همه کوئری‌ها (برای GitHub و مستندسازی)

## نکات

- همه داده‌ها نمونه و ساختگی هستند. اطلاعات برندها (Astra، AG9، Mahomeh، کهکشان، Zenix) و آدرس‌های GitHub در پروژه ۱۶ نمونه است؛ `YOUR-USERNAME` را با نام کاربری خودتان جایگزین کنید.
- کوئری‌های Select روی موتور UCanAccess تست شده و همه نتیجه برمی‌گردانند؛ کوئری‌های Crosstab، Parameter و Action با سینتکس استاندارد Access SQL نوشته شده‌اند.
- کوئری‌هایی که از `Date()` استفاده می‌کنند (سررسید، تأخیر، تمدید) بر اساس تاریخ روز اجرا محاسبه می‌شوند.
