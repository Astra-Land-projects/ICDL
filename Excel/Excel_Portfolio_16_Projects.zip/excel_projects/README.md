# ۱۶ پروژه اکسل حرفه‌ای (پورتفولیو)

همه فایل‌ها با فرمول‌های زنده ساخته شده‌اند؛ سلول‌های آبی ورودی/فرض هستند و قابل تغییرند. داده‌ها نمونه‌اند — اطلاعات واقعی خودتان را جایگزین کنید.

| # | فایل | نکات کلیدی |
|---|------|-----------|
| 01 | Financial_Management_Dashboard | SUMIFS ماهانه، سود خالص، حاشیه سود، نمودار |
| 02 | Budget_Forecasting_Variance_Analysis | انحراف بودجه، وضعیت خودکار، پیش‌بینی رشد ماهانه |
| 03 | Automated_Invoice_Generator | لیست کشویی محصول، VLOOKUP، تخفیف، مالیات |
| 04 | HR_Payroll_System | اضافه‌کار، مالیات پلکانی (VLOOKUP تقریبی)، خلاصه دپارتمان |
| 05 | CRM_Sales_Pipeline | احتمال مرحله، ارزش وزنی، نرخ برد |
| 06 | BI_KPI_Dashboard | کاربران فعال، MRR، ARPU، Churn، رشد ماهانه |
| 07 | Web_Analytics_SEO_Dashboard | CTR، نرخ تبدیل، اقدام پیشنهادی، ردیاب کلمات کلیدی |
| 08 | Agile_Project_Gantt | WORKDAY، گانت با قالب‌بندی شرطی، خلاصه اسپرینت |
| 09 | Project_Risk_Management | نمره ریسک، نقشه حرارتی ۵×۵ با COUNTIFS |
| 10 | Inventory_Warehouse_Control | هشدار REORDER / OUT OF STOCK، ارزش انبار |
| 11 | IT_Asset_License_Management | روزهای باقی‌مانده تا تمدید، هشدار انقضا |
| 12 | Team_Performance_Appraisal | امتیاز وزنی، رتبه، شرایط ارتقا / PIP |
| 13 | Global_Job_Search_Relocation_Tracker | تبدیل ارز با XLOOKUP، پیگیری فالوآپ |
| 14 | GitHub_Projects_Skills_Portfolio | Astra، AG9، Mahomeh، کهکشان، Zenix + ماتریس مهارت |
| 15 | Academic_Skill_Development_Tracker | پیشرفت از روی Study Log، ساعت لازم در هفته |
| 16 | Advanced_Excel_Formula_Lab | XLOOKUP، VLOOKUP، INDEX/MATCH، IFS، توابع متنی و تاریخ |
